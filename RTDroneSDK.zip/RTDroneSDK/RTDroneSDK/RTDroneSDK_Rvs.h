//
//  RTDroneSDK_Rvs.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RTDroneSDK_Rvs_Pro.h"


@interface RTDroneSDK_Rvs : NSObject
{
    //id<RTDroneSDK_Rvs_Pro> delegate;
}

@property(nonatomic,weak)id<RTDroneSDK_Rvs_Pro> delegate;

//链接
-(int)RTSDKRvs_connect:(char *)ip andPort:(int)port;

//链接成功后开始发送飞控指令，比如说前后左右的油门值
-(int)RTSDKRvs_SendUAVData:(unsigned char *)data andLength:(int)length;

//断掉链接
-(int)RTSDKRvs_DisConnect;

//要接收设备端的数据，必须要创建订阅线程，这个动作不需要RTSDKRvs_connect
//可以单独运行，手柄按键拍照，录像，透传数据，就会在这里回调，不可以重复订阅
-(int)RTSDKRvs_CreateSubscribeDataThread;

//创建订阅线程后，要记得关闭，以免内存泄露
-(int)RTSDKRvs_DestorySubscribeDataThread;

//订阅，主要针对透传数据，其他数据不需要订阅，比如手柄按键拍照，录像相应
//这个订阅必须要connect
-(int)RTSDKRvs_Subscribe:(int) state;


@end
