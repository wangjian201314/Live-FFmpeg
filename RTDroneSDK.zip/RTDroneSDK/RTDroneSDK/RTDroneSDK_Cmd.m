//
//  RTDroneSDK_Cmd.m
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import "RTDroneSDK_Cmd.h"
#import "Rt_drone_cmd_sonix.h"

@class GCDAsyncSocket;

#define TAG_VIDEO 0x23
#define TAG_IMAGE 0x24

@implementation RTDroneSDK_Cmd{
    
    //标志数据是否为第一次返回，因为数据是分段返回的，所以必须要有一个标志
    int returnCount;
    
    //视频列表返回的总长度
    int fileTotalSize;
    
    //视频列表接收到的总长度
    int recvFileSize;
    
    //保存视频列表文本的路径
    NSString *indexVideoListPath;
    NSString *indexPicListPath;
    
    //下载视频要保存的全路径
    NSString *saveVideoPath;
    
    //下载图片要保存的全路径
    NSString *savePicPath;
    
    //要下载的文件名
    NSString *downLoadFileName;
    
    //保存到文本
    NSFileHandle *fileHandle;
    //输入流
    NSInputStream *inputStream;
    
    //标志是否正在下载文件,区别于是否为内部实现的下载方法
    BOOL isDownLoading;
    //标志是否下载视频
    BOOL isDownVideo;
    //标志是否下载图片
    BOOL isDownImage;
    
    @private
    GCDAsyncSocket *asyncSocket;
    
    @private
    NSTimer *connectTimer;//计时器，发送心跳包
    
    
    
}
@synthesize delegate;

//单利模式
+(RTDroneSDK_Cmd*)sharedInstance{
    static RTDroneSDK_Cmd *sharedInstace = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        sharedInstace = [[self alloc] init];
    });
    return sharedInstace;
}


#pragma mark GCDAsyncSocket链接成功的回调
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port
{
    NSLog(@"[SDK_Cmd] Socket:DidConnectToHost: %@ Port: %hu", host, port);
    
    if(port == 8080){
        
        NSString *josnString = @"{\"type\":	\"didConnectToHost\"}";
        NSData *jsonData = [josnString dataUsingEncoding:NSUTF8StringEncoding];
        NSError *tempErr;
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&tempErr];
        if(!tempErr){
            if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
                [[self delegate]RTSDKCmd_MsgCallBack:dic];
            }
        }else{
            NSLog(@"disConnectToHost josn error");
        }
        
    }else{
        
        
        
        
    }
    
    //发送心跳包
    //connectTimer = [NSTimer scheduledTimerWithTimeInterval:30 target:self selector:@selector(RTSDKCmd_SendHeartByte) userInfo:nil repeats:YES];
    
}



#pragma mark GCDAsyncSocket链接失败的回调
- (void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err
{
    NSLog(@"[SDK_Cmd] SocketDidDisconnect:WithError: %@", err);
    
    NSString *josnString = @"{\"type\":	\"disConnectToHost\"}";
    NSData *jsonData = [josnString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *tempErr;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&tempErr];
    
    if(!tempErr){
        if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
        [[self delegate]RTSDKCmd_MsgCallBack:dic];
        }
    }else{
        NSLog(@"disConnectToHost josn error");
    }
    
    if(connectTimer != nil){
        //停止定时器
        [connectTimer invalidate];
    }

}

#pragma mark
- (void)socketDidSecure:(GCDAsyncSocket *)sock
{
    NSLog(@"[SDK_Cmd] socketDidSecure:%p", sock);
}


- (void)socket:(GCDAsyncSocket *)sock didWriteDataWithTag:(long)tag
{
    NSLog(@"[SDK_Cmd] socket:%p didWriteDataWithTag:%ld", sock, tag);
}

#pragma mark 获取保存到本地的视频列表文本路径
- (NSString *)getVideoListPath{
    
    //先创建文件夹
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir = FALSE;
    BOOL isDirExist = [fileManager fileExistsAtPath:path isDirectory:&isDir];
    if(!(isDirExist && isDir))
    {
        BOOL bCreateDir = [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
        if(!bCreateDir){
            NSLog(@"create Floder Error");
            
        }
        NSLog(@"Create Floder Success %@",path);
    }
    
    NSString *recordpath = [NSString stringWithFormat:@"%@/%@",path,@"index_video_list.txt"];
    
    
#ifdef RT_DEBUG
    NSLog(@"recordpath %@",recordpath);
#endif
    
    return  recordpath;
}

#pragma mark 获取保存到本地的图片列表文本路径
- (NSString *)getPicListPath{
    
    //先创建文件夹
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir = FALSE;
    BOOL isDirExist = [fileManager fileExistsAtPath:path isDirectory:&isDir];
    if(!(isDirExist && isDir))
    {
        BOOL bCreateDir = [fileManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
        if(!bCreateDir){
            NSLog(@"create Floder Error");
            
        }
        NSLog(@"Create Floder Success %@",path);
    }
    
    NSString *recordpath = [NSString stringWithFormat:@"%@/%@",path,@"index_pic_list.txt"];
    
    
#ifdef RT_DEBUG
    NSLog(@"recordpath %@",recordpath);
#endif
    
    return  recordpath;
}


#pragma mark 通过输入流获取图片列表
-(void)makePicList{
    
    uint8_t recBuf[64000];
    NSInteger num = 0;
    num = [inputStream read:recBuf maxLength:64000];
    NSLog(@"num = %ld",num);
    
    if(num <=0){
        return;
    }
    
    int offset = 0;
    if(returnCount == 0){
        returnCount ++;
        fileTotalSize = 0;
        recvFileSize = 0;
        offset = 0;
        if(num >= 4){
            for(int i = 0; i < 4 ;i++){
                int value = recBuf[i];
                if(value < 0){
                    value += 256;
                }
                fileTotalSize += (value * pow(256, (3-i)));
            }
        }
        if(fileTotalSize == 0){
            NSLog(@"fileTotalSize = 0");
            returnCount =0;
            return;
        }
        
        if(num == 4){
            offset = 0;
            NSLog(@"num == 4");
            return;
        }else{
            offset = 4;
        }
    }
    
#ifdef RT_DEBUG
    //打印接收到的数据，这里可以不打印出来
    for(int i = 0 ;i <num ;i++){
        printf("%c",recBuf[i]);
    }
#endif
    
    NSData *temp = [NSData dataWithBytes:(recBuf+offset) length:(num -offset)];
    if(indexPicListPath == nil){
        //获取保存文本的路径
        indexPicListPath = [self getPicListPath];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:indexPicListPath]){
            [fileManager removeItemAtPath:indexPicListPath error:nil];
        }
        //这里为为了创建该文件
        [@"" writeToFile:indexPicListPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
        fileHandle =[NSFileHandle fileHandleForUpdatingAtPath:indexPicListPath];
        
    }
    
    [fileHandle seekToEndOfFile];
    
    //将视频列表以文本的方式保存起来
    [fileHandle writeData:temp];
    
    recvFileSize += (num-offset);
    
    NSLog(@"recvFileSize =%d ,fileTotalSize =%d",recvFileSize,fileTotalSize);
    
    if(recvFileSize >= fileTotalSize){
        NSLog(@" recFile end ");
        
        //将文件内容全部读取出来
        //NSData *fileData = [fileHandle readDataToEndOfFile];
        
        //关闭保存文件
        [fileHandle closeFile];
        fileHandle = NULL;
        
        NSString *fileList = [NSString stringWithContentsOfFile:indexPicListPath encoding:NSUTF8StringEncoding error:nil];
        
        indexPicListPath = nil;
        
        NSArray *array = [fileList componentsSeparatedByString:@"\n"];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
                
                NSDictionary *newDic = [NSDictionary dictionaryWithObjectsAndKeys:array,@"list",@"picList",@"type",nil];
                
                [[self delegate]RTSDKCmd_MsgCallBack:newDic];
                
                //关闭下载
                [self RTSDKCmd_DownLoadFileFinsh:@"filelist.txt" FileType:7 Tag:7];
                
            }
        });
        
    }

}

#pragma mark 通过输入流保存文件
-(void)saveFileByInputStream:(NSInputStream *)stream path:(NSString *)saveFilePath Tag:(int)tag{
    if(saveFilePath == nil){
        NSLog(@"saveFilePath == nil");
        return;
    }
    
    uint8_t recBuf[124*1024];
    NSInteger num = 0;
    num = [stream read:recBuf maxLength:(124*1024)];
    //NSLog(@"num = %ld",num);
    if(num <=0){
        return;
    }
    int offset = 0;
    if(returnCount == 0){
        returnCount ++;
        fileTotalSize = 0;
        recvFileSize = 0;
        offset = 0;
        if(num >= 4){
            for(int i = 0; i < 4 ;i++){
                int value = recBuf[i];
                if(value < 0){
                    value += 256;
                }
                fileTotalSize += (value * pow(256, (3-i)));
            }
        }
        if(fileTotalSize == 0){
            NSLog(@"fileTotalSize = 0");
            returnCount =0;
            return;
        }
        
        //初始化好文件管理器，如果文件存在了，删除
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:saveFilePath]){
            [fileManager removeItemAtPath:saveFilePath error:nil];
        }
        
        //创建文件
        [fileManager createFileAtPath:saveFilePath contents:nil attributes:nil];
        
        //初始化好文件handle
        fileHandle =[NSFileHandle fileHandleForUpdatingAtPath:saveFilePath];
        
        if(num == 4){
            offset = 0;
            NSLog(@"num == 4");
            return;
        }else{
            offset = 4;
        }
        
    }
    
    NSData *temp = [NSData dataWithBytes:(recBuf+offset) length:(num -offset)];
    
    [fileHandle seekToEndOfFile];
    
    //将视频列表以文本的方式保存起来
    [fileHandle writeData:temp];
    
    recvFileSize += (num-offset);
    
    //NSLog(@"recvFileSize =%d ,fileTotalSize =%d",recvFileSize,fileTotalSize);
    
    if(recvFileSize >= fileTotalSize){
        NSLog(@" recFile end ");
        //关闭保存文件
        [fileHandle closeFile];
        fileHandle = NULL;
        
        //下载文件结束
        isDownLoading = false;
        //关闭下载
        [self RTSDKCmd_DownLoadFileFinsh:downLoadFileName FileType:0 Tag:tag];
        
        
        if(tag == TAG_IMAGE){
            isDownImage = FALSE;
        }
        
        if(tag == TAG_VIDEO){
            isDownVideo = FALSE;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
            
            NSDictionary *newDic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt: recvFileSize],@"recvFileSize",
                [NSNumber numberWithInt: fileTotalSize],@"fileTotalSize"
                                    ,@"position",@"type",
                                    nil];
            
            [[self delegate]RTSDKCmd_MsgCallBack:newDic];
            
        }
    });
    
}


#pragma mark 输入流回调
- (void)stream:(NSStream *)aStream handleEvent:(NSStreamEvent)eventCode{
    switch (eventCode) {
        case NSStreamEventOpenCompleted:
            NSLog(@"inputStream 输入输出流打开完成 %d", [NSThread isMainThread]);
            
            break;
        case NSStreamEventHasBytesAvailable:
        {
            
#ifdef RT_DEBGU
            NSLog(@"inputStream 有字节可读");
#endif
            if(isDownVideo){
                
                if(saveVideoPath == nil){
                    NSLog(@"saveVideoPath == nil");
                    return;
                }
                [self saveFileByInputStream:inputStream path:saveVideoPath Tag:TAG_VIDEO];
                
            }else if(isDownImage){
                
                if(savePicPath == nil){
                    NSLog(@"savePicPath == nil");
                    return;
                }
                [self saveFileByInputStream:inputStream path:savePicPath Tag:TAG_IMAGE];
                
            }
            else{
                [self makePicList];
            }
        }
            break;
        case NSStreamEventHasSpaceAvailable:
            NSLog(@"inputStream 可以发送字节");
            
            
            break;
        case NSStreamEventErrorOccurred:
            NSLog(@"inputStream 连接出现错误");
            
            isDownLoading = FALSE;
            isDownImage = FALSE;
            isDownVideo = FALSE;
            
            //关闭输入输出流
            [inputStream close];
            
            //从主循环移除
            [inputStream removeFromRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
            
            
            break;
        case NSStreamEventEndEncountered:
            NSLog(@"inputStream 连接结束");
            
            if(fileHandle!=NULL){
                //关闭保存文件
                [fileHandle closeFile];
                fileHandle = nil;
                indexPicListPath = nil;
            }
            
            isDownLoading = FALSE;
            isDownImage = FALSE;
            isDownVideo = FALSE;
            
            //关闭输入输出流
            [inputStream close];
            
            //从主循环移除
            [inputStream removeFromRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
            
            break;
            
        default:
            break;
    }
}


#pragma mark 打开图片列表流
-(void) openPicListStream:(int )port{
    
    CFReadStreamRef readStream;
    
    CFStreamCreatePairWithSocketToHost(NULL, (__bridge CFStringRef)@"192.168.99.1", port, &readStream, NULL);
    
#if RT_DEBUG
    
    NSLog(@"SocketToHost ip = 192.168.99.1 port =%d",port);
    
#endif
    
    //转换为输入流
    inputStream = (__bridge NSInputStream*)readStream;
    
    //设置代理
    inputStream.delegate = self;
    
    //不添加到主运行循环，代理又可能不工作
    [inputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
    //需要重制一些参数
    indexPicListPath = nil;
    returnCount = 0;
    if(fileHandle!=NULL){
        [fileHandle closeFile];
        fileHandle = NULL;
    }
    
    
    //打开输入输出流
    [inputStream open];
    
}

#pragma mark 打开视频输入流
-(void)openVideoStream:(int) port{
    
    CFReadStreamRef readStream;
    
    CFStreamCreatePairWithSocketToHost(NULL, (__bridge CFStringRef)@"192.168.99.1", port, &readStream, NULL);
    
#if RT_DEBUG
    
    NSLog(@"SocketToHost ip = 192.168.99.1 port =%d",port);
    
#endif
    
    //转换为输入流
    inputStream = (__bridge NSInputStream*)readStream;
    
    //设置代理
    inputStream.delegate = self;
    
    //不添加到主运行循环，代理又可能不工作
    [inputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
    //打开输入输出流
    [inputStream open];
    
    //标志是否真正下载文件，为了防止多个文件同时下载
    isDownLoading = TRUE;
    
}

#pragma mark 打开图片输入流
-(void)openPicStream:(int) port{
    
    [self openVideoStream:port];
}



#pragma mark 整理视频列表
-(void) makeVideoList:(NSData *)data{
    //如果是视频类型，这里将字节流转为文件列表的方式封装在这里
    
    char *tempData = (char*)[data bytes];
    
#ifdef RT_DEBUG
    //打印接收到的数据，这里可以不打印出来
    NSUInteger length = data.length;
    for(int i = 0 ;i <length ;i++){
        printf("%c",tempData[i]);
    }
    
#endif
    
    if(returnCount == 0){
        
        returnCount++;
        
        fileTotalSize = 0;
        recvFileSize = 0;
        
        if(data.length < 4){
            returnCount=0;
            NSLog(@"data.length =%d < 4",(int)(data.length));
            return;
        }
        
        //读取前面四个字节，这个四个字节包含了文件的总长度
        for(int i = 0; i< 4 ;i++){
            int value = tempData[i];
            if(value <0){
                value +=256;
            }
            
            fileTotalSize += (value * pow(256,3-i));
        }
        
        //接收到的总长度
        recvFileSize += (data.length -4);
        
        NSLog(@"fileTotalSize = %d  recvFileSize =%d \n",fileTotalSize,recvFileSize);
        
        //tempData+4:是指从第四个字节开始拷贝
        NSData *temp = [NSData dataWithBytes:(tempData+4) length:(data.length -4)];
        
        //获取保存文本的路径
        indexVideoListPath = [self getVideoListPath];
        
        if(indexVideoListPath != nil){
            
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if([fileManager fileExistsAtPath:indexVideoListPath]){
                [fileManager removeItemAtPath:indexVideoListPath error:nil];
            }
            
            if(fileHandle!=NULL){
                [fileHandle closeFile];
            }
            fileHandle =[NSFileHandle fileHandleForUpdatingAtPath:indexVideoListPath];
            
            //将视频列表以文本的方式保存起来
            [temp writeToFile:indexVideoListPath atomically:YES];
            
        }
        
        //如果一次行返回
        if(fileTotalSize == recvFileSize){
            
            NSLog(@"数据接收完毕 returnCount =%d\n",returnCount);
            returnCount = 0;
            
            if(fileHandle!=NULL){
                [fileHandle closeFile];
            }
            
            
            if(indexVideoListPath != nil){
                NSString *fileList = [NSString stringWithContentsOfFile:indexVideoListPath encoding:NSUTF8StringEncoding error:nil];
                
                NSArray *array = [fileList componentsSeparatedByString:@"\n"];
                
                
                dispatch_async(dispatch_get_main_queue(), ^{
                
                    if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
                        
                        NSDictionary *newDic = [NSDictionary dictionaryWithObjectsAndKeys:array,@"list",@"videoList",@"type",nil];
                        
                        [[self delegate]RTSDKCmd_MsgCallBack:newDic];
                        
                        //关闭下载
                        [self RTSDKCmd_DownLoadFileFinsh:@"filelist.txt" FileType:7 Tag:7];
                        
                        
                        
                    }
                });
                
            }
            
        }
        
    }else{
        
        returnCount++;
        
        recvFileSize += (data.length);
        
        if(fileHandle!=NULL){
            [fileHandle writeData:data];
        }
        
        if(recvFileSize >= fileTotalSize){
            
            NSLog(@"数据接收完毕 returnCount =%d\n",returnCount);
            
            returnCount = 0;
            
            if(fileHandle!=NULL){
                [fileHandle closeFile];
            }
            
            if(indexVideoListPath != nil){
                NSString *fileList = [NSString stringWithContentsOfFile:indexVideoListPath encoding:NSUTF8StringEncoding error:nil];
                
                NSArray *array = [fileList componentsSeparatedByString:@"\n"];
                
                dispatch_async(dispatch_get_main_queue(), ^{

                    if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
                        
                        NSDictionary *newDic = [NSDictionary dictionaryWithObjectsAndKeys:array,@"list",@"videoList",@"type",nil];
                        
                        [[self delegate]RTSDKCmd_MsgCallBack:newDic];
                    
                    
                        //关闭下载
                        [self RTSDKCmd_DownLoadFileFinsh:@"filelist.txt" FileType:7 Tag:7];
                        
                    }
                    
                });
                
            }
            
        }
    }
    
}


#pragma mark 接收到消息
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    
    //NSLog(@"[SDK_Cmd] socket:%p didReadData:withTag:%ld", sock, tag);
    
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    
    //如果转换为json成功
    if(!err){
        
#ifdef RT_DEBUG
        NSLog(@"[SDK_Cmd] tag=%ld NSDictionary=%@",tag,dic);
#endif
        
        NSString *type = [dic objectForKey:@"type"];
        
        //如果不是图片
        
        if([[self delegate] respondsToSelector:@selector(RTSDKCmd_MsgCallBack:)]){
            
            [[self delegate]RTSDKCmd_MsgCallBack:dic];
            
        }
        
        //获取图片index
        if([type isEqualToString:@"getindexfile_res"]){
           
            NSLog(@"========get image list=======");
            
            int port = [[dic valueForKey:@"port"] intValue];
            if(port!=0){
                returnCount = 0;
                [self openPicListStream:port];
            }else{
                NSLog(@"error port == 0 \n");
            }
            
        }else if([type isEqualToString:@"downloadfile_res"]){
            int port = [[dic valueForKey:@"port"] intValue];
            int tag = [[dic valueForKey:@"tag"] intValue];
            returnCount = 0;
            
            if(port!=0){
                if(isDownVideo && tag == TAG_VIDEO){
                    NSLog(@"========get image stream=======");
                    
                    [self openVideoStream:port];
                }else if(isDownImage && tag == TAG_IMAGE){
                    NSLog(@"========get image stream=======");
                    [self openPicStream:port];
                }
            }else{
                isDownVideo = FALSE;
                isDownImage = FALSE;
                isDownLoading = FALSE;
                NSLog(@"error port == 0 \n");
            }
        }
        
    }else{
        NSLog(@"========get video list=======");
        //如果转换为json不成功，说明是视频列表数据返回
        //视频列表
        [self makeVideoList:data];
      
    }
    
   
}


#pragma mark 链接
-(void)RTSDKCmd_Connect:(NSString*)host andPort:(int)port{
    
    if(asyncSocket == nil){
        asyncSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    }
    
#ifdef RT_DEBUG
    NSLog(@"[SDK_Cmd] connecting: id=%@ port=%d\n", host,port);
#endif
    
    NSError *error = nil;
    
    if(![asyncSocket isConnected]){
        //两秒超时
        if (![asyncSocket connectToHost:host onPort:port withTimeout:2 error:&error])
        {
            NSLog(@"[SDK_Cmd] Error connecting: %@", error);
        }
    }else{
        NSLog(@"[SDK_Cmd] is connected dou not need to conne again\n");
    }
}


-(void)RTSDKCmd_SendJsonToDrone:(char *)aszJson andTag:(long)tag{
    if(aszJson== nil){
        NSLog(@"[SDK_Cmd] aszJson== nil\n");
        return;
    }
    
    NSData *json =[NSData dataWithBytes:aszJson length:strlen(aszJson)];
    
#ifdef RT_DEBUG
    NSLog(@"[SDK_Cmd] tag=%ld aszJSON=%@",tag,[[NSString alloc] initWithData:json encoding:NSASCIIStringEncoding]);
#endif
    
    if([asyncSocket isConnected]){
        [asyncSocket writeData:json withTimeout:-1 tag:tag];
        [asyncSocket readDataWithTimeout:-1 tag:tag];
    }else{
        NSLog(@"[SDK_Cmd] no connected, send json faile\n");
    }
    
}



#pragma mark 端开链接
-(void)RTSDKCmd_disConnect{
    if(asyncSocket != nil){
        [asyncSocket disconnect];
        NSLog(@"[SDK_Cmd] disconnect ok\n");
    }
}

#pragma mark 获取当前链接状态
-(BOOL)RTSDKCmd_GetConnectStatue{
    return [asyncSocket isConnected];
}

#pragma mark 获取视频参数
-(void)RTSDKCmd_GetVideoStatue
{
    char aszJson[128];
    DeviceCommand_Sonix_GetVideoStatus(aszJson);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:1];
}


#pragma mark 如果是180度翻转，同开同关
-(void)RTSDKCmd_SetMirror:(int)mirrorStatue
{
    char aszJson[128];
    DeviceCommand_Sonix_SetMIRROR(aszJson,mirrorStatue);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:2];
}


-(void)RTSDKCmd_SetFlip:(int)filpStatue
{
    char aszJson[128];
    DeviceCommand_Sonix_SetFLIP(aszJson,filpStatue);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:2];
}



-(void)RTSDKCmd_SetMirrorAndFilp:(int)statue;
{
    char aszJson[128];
    DeviceCommand_Sonix_SetMIRROR(aszJson,statue);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:3];
    
    memset(aszJson, 0, sizeof(aszJson));
    DeviceCommand_Sonix_SetFLIP(aszJson,statue);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:3];
    
}



//设备拍照命令
-(void)RTSDKCmd_TakePicure:(int)picNum{
    
    char aszJson[128];
    DeviceCommand_Sonix_TakePicture(aszJson,picNum);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:4];

}



//同步时间，这里设备端录像或者拍照命名才会正确
-(void)RTSDKCmd_SyncTime:(int)year andMonth:(int)month andDay:(int)day andHour:(int)hour andMin:(int)min andSec:(int)sec andTimeZone:(char*)timeZone{
    char aszJson[128];
    DeviceCommand_Sonix_SyncTime(aszJson, year, month, day, hour, min, sec, timeZone);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:5];
}



//获取视频列表
-(void)RTSDKCmd_GetVideoList{
    returnCount = 0;
    char aszJson[128];
    DeviceCommand_Sonix_GetVideoList(aszJson);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:6];
}




//开始视频播放流，这个会返回关键值
-(void)RTSDKCmd_StreamVideo:(char*)fileName andMode:(int)mode andFileType:(int)fileType{
    char aszJson[256];
    DeviceCommand_Sonix_StreamVideo(aszJson, fileName, mode, fileType,"j7Wl6WI");
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:7];
}


//结束视频流
-(void)RTSDKCmd_StreamVideoFinish:(char *)fileName{
    char aszJson[256];
    DeviceCommand_Sonix_StreamVideoFinish(aszJson, fileName,"j7Wl6WI");
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:8];
}



//客户编号校验
-(void)RTSDKCmd_StreamChek:(double)key1 andKey2:(double)key2 andCustomerId:(char*)customerId{
    char aszJson[128];
    DeviceCommand_Sonix_StreamCheck(aszJson,key1,key2,customerId);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:9];
}



//设置录像状态
-(void)RTSDKCmd_SetRecordStatus:(int)statue{
    char aszJson[128];
    DeviceCommand_Sonix_SetRecordStatus(aszJson,statue);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:10];
}

//发送心跳包
-(void)RTSDKCmd_SendHeartByte{
    char aszJson[128];
    DeviceCommand_Sonix_getHeartBeatByte(aszJson);
    if([asyncSocket isConnected]){
        NSData *json =[NSData dataWithBytes:aszJson length:strlen(aszJson)];
        [asyncSocket writeData:json withTimeout:-1 tag:11];
    }else{
        NSLog(@"[SDK_Cmd] no connected, send json faile\n");
    }
}

//获取图片列表
-(void)RTSDKCmd_GetPicList{
    char aszJson[128];
    DeviceCommand_Sonix_GetIndexFile(aszJson,1);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:12];
}


//下载文件
-(void)RTSDKCmd_DownLoadFile:(NSString *)fileName FileType:(int)type Tag:(int)tag{
    
    if(fileName == nil){
         NSLog(@"[SDK_Cmd] fileName == nil\n");
        return;
    }
    
    char aszJson[256];
    DeviceCommand_Sonix_DownloadFile(aszJson,[fileName UTF8String], 0, type,tag);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:13];
}


//下载视频
-(void)RTSDKCmd_DownLoadVideo:(NSString *)fileName SavePath:(NSString*)savePath{
    if(isDownLoading){
        NSLog(@"有文件正在下载,请等代下载完后");
        return;
    }
    downLoadFileName = fileName;
    saveVideoPath = savePath;
    isDownVideo = TRUE;
    [self RTSDKCmd_DownLoadFile:fileName FileType:0 Tag:TAG_VIDEO];
}

//下载图片
-(void)RTSDKCmd_DownLoadPic:(NSString*)fileName SavePath:(NSString*)savePath{
    if(isDownLoading){
        NSLog(@"有文件正在下载,请等代下载完后");
        return;
    }
    downLoadFileName = fileName;
    savePicPath = savePath;
    isDownImage = TRUE;
    [self RTSDKCmd_DownLoadFile:fileName FileType:2 Tag:TAG_IMAGE];
}


//下载文件后，要记得关闭
-(void)RTSDKCmd_DownLoadFileFinsh:(NSString *)fileName FileType:(int)type Tag:(int)tag{

    if(fileName == nil){
        NSLog(@"[SDK_Cmd] fileName == nil\n");
        return;
    }
    
    char aszJson[256];
    DeviceCommand_Sonix_DownloadFileFinish(aszJson,[fileName UTF8String], type,tag);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:14];
    
}


//删除文件
-(void)RTSDKCmd_DeleteFile:(NSString*)fileName FileType:(int)type{
    if(fileName == nil){
        NSLog(@"[SDK_Cmd] fileName == nil\n");
        return;
    }
    
    char aszJson[256];
    DeviceCommand_Sonix_DeleteFile(aszJson,[fileName UTF8String], type);
    [self RTSDKCmd_SendJsonToDrone:aszJson andTag:15];
}



@end
