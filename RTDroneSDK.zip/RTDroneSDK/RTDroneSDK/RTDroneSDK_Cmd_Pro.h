//
//  RTDroneSDK_Cmd_Pro.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/22.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RTDroneSDK_Cmd_Pro <NSObject>

@required
-(void)RTSDKCmd_MsgCallBack:(NSDictionary*)jsonMsg;
@end
