//
//  RTDroneSDK_Rvs_Pro.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum _RT_DRONE_RVS_MSG_TYPE_{
    RT_DRONE_RVS_MES_REC,//连续
    RT_DRONE_RVS_MSG_SNAP,//拍照
    RT_DRONE_RVS_MSG_TRANSINFO//透传数据，gps等
}RT_DRONE_RVS_MSG_TYPE;


@protocol RTDroneSDK_Rvs_Pro <NSObject>

@required
-(void) RTSDKRvs_MsgCallBack:(int)msgType andData:(char*)data;

@end
