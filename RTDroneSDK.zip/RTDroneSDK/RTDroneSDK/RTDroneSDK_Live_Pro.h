//
//  RTDroneSDK_Live_Pro.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>

//消息类型
typedef enum _RT_DRONE_MSG_TYPE_
{
    /*
     视频开始显示
     */
    RT_DRONE_MSG_TYPE_SHOW = 0x60,
    
    /*
     视频分辨率
     */
    RT_DRONE_MSG_TYPE_RESOLUTION,
    
    /*
     文件打开状态
     */
    RT_DRONE_MSG_TYPE_FILE_OPNE_STATE,
    
    /*
     总的视频长度（时间）
     */
    RT_DRONE_MSG_TYPE_TOTAL_PTS,
    
    /*
     视频拖动播放的状态
     */
    RT_DRONE_MSG_TYPE_SEEK_STATE,
    
    /*
     音频开启的状态
     */
    RT_DRONE_MSG_TYPE_AUIDO_OPEN_STATE,
    
    /*
     视频直播中断了
     */
    RT_DRONE_MSG_TYPE_LIVE_PLAY_INTERRUPT,
    
    /*
     视频播放结束
     */
    RT_DRONE_MSG_TYPE_LIVE_PLAY_END,
    
}RT_DRONE_MSG_TYPE;

typedef enum _RT_DRONE_SDCARD_MSG_TYPE_
{
    /*
     sd卡的状态，有无sd卡
     */
    RT_DRONE_SDCARD_MSG_TYPE_sd_status,
    
    /*
     是否正在录像
     */
    RT_DRONE_SDCARD_MSG_TYPE_sd_recStatue,
    
    /*
     sd容量
     */
    RT_DRONE_SDCARD_MSG_TYPE_sd_capacity,
    
    /*
     sd格式化
     */
    RT_DRONE_SDCARD_MSG_TYPE_sd_format,
    
    /*
     sd拍照
     */
    RT_DRONE_SDCARD_MSG_TYPE_sd_snap,
}RT_DRONE_SDCARD_MSG_TYPE;


@protocol RTDroneSDK_Live_Pro <NSObject>

@required
-(void)RTSDKLive_UIImageCallBack:(UIImage*)img width:(int)w height:(int)h;

@required
-(void)RTSDKLive_VideoMsgCallBack:(int)msgType msg:(int)state;

@required
-(void)RTSDKLive_SDCardMsgCallBack:(int)msgType msg:(int)msg;


@end
