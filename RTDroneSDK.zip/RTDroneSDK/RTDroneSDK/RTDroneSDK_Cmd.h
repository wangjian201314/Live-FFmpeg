//
//  RTDroneSDK_Cmd.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GCDAsyncSocket.h"
#import "RTDroneSDK_Cmd_Pro.h"

@interface RTDroneSDK_Cmd : NSObject<GCDAsyncSocketDelegate,NSStreamDelegate>{
    //id<RTDroneSDK_Cmd_Pro> delegate;
}

+(RTDroneSDK_Cmd*)sharedInstance;

@property(nonatomic,weak)id<RTDroneSDK_Cmd_Pro> delegate;

//链接
-(void)RTSDKCmd_Connect:(NSString*)ip andPort:(int)port;

//端开链接
-(void)RTSDKCmd_disConnect;

//获取链接状态
-(BOOL)RTSDKCmd_GetConnectStatue;

//获取视频参数
-(void)RTSDKCmd_GetVideoStatue;

//如果是180度翻转，同开同关
-(void)RTSDKCmd_SetMirror:(int)mirrorStatue;
-(void)RTSDKCmd_SetFlip:(int)filpStatue;
-(void)RTSDKCmd_SetMirrorAndFilp:(int)statue;

//设备拍照命令
-(void)RTSDKCmd_TakePicure:(int)picNum;

//同步时间，这里设备端录像或者拍照命名才会正确
-(void)RTSDKCmd_SyncTime:(int)year andMonth:(int)month andDay:(int)day andHour:(int)hour andMin:(int)min andSec:(int)sec andTimeZone:(char*)timeZone;

//获取视频列表
-(void)RTSDKCmd_GetVideoList;

//开始视频播放流，这个会返回关键值
-(void)RTSDKCmd_StreamVideo:(char*)fileName andMode:(int)mode andFileType:(int)fileType;

//结束视频流
-(void)RTSDKCmd_StreamVideoFinish:(char *)fileName;

//客户编号校验
-(void)RTSDKCmd_StreamChek:(double)key1 andKey2:(double)key2 andCustomerId:(char*)customerId;

//设置录像状态
-(void)RTSDKCmd_SetRecordStatus:(int)statue;

//获取图片列表
-(void)RTSDKCmd_GetPicList;

//根据这个方法，可以自己实现RTSDKCmd_DownLoadVideo，RTSDKCmd_DownLoadPic
-(void)RTSDKCmd_DownLoadFile:(NSString *)fileName FileType:(int)type Tag:(int)tag;

//下载视频
-(void)RTSDKCmd_DownLoadVideo:(NSString *)fileName SavePath:(NSString*)savePath;

//下载图片
-(void)RTSDKCmd_DownLoadPic:(NSString*)fileName SavePath:(NSString*)savePath;

//下载文件后要记得关闭
-(void)RTSDKCmd_DownLoadFileFinsh:(NSString *)fileName FileType:(int)type Tag:(int)tag;

//删除文件
-(void)RTSDKCmd_DeleteFile:(NSString*)fileName FileType:(int)type;



@end
