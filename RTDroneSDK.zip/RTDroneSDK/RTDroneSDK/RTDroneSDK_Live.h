//
//  RTDroneSDK_Live.h
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "RTDroneSDK_Live_Pro.h"
@interface RTDroneSDK_Live : NSObject
{
    //id<RTDroneSDK_Live_Pro> delegate;
}

@property(nonatomic,weak)id<RTDroneSDK_Live_Pro> delegate;

-(int)RTSDKLive_Init;
-(int)RTSDKLive_Start:(NSString *)rtspName;
-(int)RTSDKLive_Stop;
-(int)RTSDKLive_Exit;


-(int)RTSDKLive_StartRecMp4:(NSString*)filename andFps:(int)fps;
-(int)RTSDKLive_StopRecMp4;


-(int)RTSDKLive_GetSaveFrameCount;

@end
