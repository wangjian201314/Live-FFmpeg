//
//  RTDroneSDK_Live.m
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import "RTDroneSDK_Live.h"
#import "Rt_pub_def.h"

@implementation RTDroneSDK_Live

/*
 tf卡是否存在的状态
 */
static int gl_sd_status   = -1;

/*
 分辨率
 */
static int gl_resolution  = 0;

/*
 tf录像状态
 */
static int gl_rec_running = -1;

/*
 tf满
 */
static int gl_sd_capacity = -1;

/*
 格式化
 */
static int gl_sd_fromat= -1;

/*
 抓拍
 */
static int gl_sd_snap = 0;

@synthesize delegate;
static RTDroneSDK_Live *rtDroneLiveSDK;

static int *hppPlayerHandler;


static int RTSDK_scaleDataReturnCallBack(void *userData,RT_PICTURE *pstPicture)
{
    if(rtDroneLiveSDK!=nil){
        
        AVFrame *decodeFrame = pstPicture->pDecodeFrame;
        
        int width = pstPicture->s32Width;
        int height = pstPicture->s32Height;
        
        CGBitmapInfo bitmapInfo = kCGBitmapByteOrderDefault;
        CFDataRef data = CFDataCreate(kCFAllocatorDefault, decodeFrame->data[0], decodeFrame->linesize[0] * height);
        
        CGDataProviderRef provider = CGDataProviderCreateWithCFData(data);
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGImageRef cgImage = CGImageCreate(width,
                                           height,
                                           8,
                                           24,
                                           decodeFrame->linesize[0],
                                           colorSpace,
                                           bitmapInfo,
                                           provider,
                                           NULL,
                                           NO,
                                           kCGRenderingIntentDefault);
        UIImage *image =[UIImage imageWithCGImage:cgImage];
        CGImageRelease(cgImage);
        CGColorSpaceRelease(colorSpace);
        CGDataProviderRelease(provider);
        CFRelease(data);
        
        //这里先判断delegate是否已经实现RTDroneUIImageCallBack方法
        //如果没有实现直接调用会crash
        if([[rtDroneLiveSDK delegate] respondsToSelector:@selector(RTSDKLive_UIImageCallBack:width:height:)]  ){
            
            [[rtDroneLiveSDK delegate] RTSDKLive_UIImageCallBack:image width:width height:height];
            
        }
        
    }
    return 0;
}


static int RTSDK_VideoMsgReturnCallBack(void *userData,const char *uid, RT_MSG_TYPE msgType,int msg){
    
    //这里先判断delegate是否已经实现RTDroneUIImageCallBack方法
    //如果没有实现直接调用会crash
    if([[rtDroneLiveSDK delegate] respondsToSelector:@selector(RTSDKLive_VideoMsgCallBack:msg:)]){

        [[rtDroneLiveSDK delegate] RTSDKLive_VideoMsgCallBack:msgType msg:msg];
        
    }
    return 0;
}


/*
 将全局变量设置为默认值
 */
static void init_gl_data(){
    gl_sd_status   = -1;
    gl_resolution  = 0;
    gl_rec_running = -1;
    gl_sd_capacity = -1;
    gl_sd_fromat   = -1;
    gl_sd_snap = -1;
}

/*
将获取到的h264数据回调出去，返回值>=0 则数据将会被内部存储,即会拿去解码并显示，<0 内部则会将数据抛弃，默认可以不设置数据都会被内部存储，这个函数主要是针对飞控，比如判断是I帧后面的8个字节，比如判断该帧是否花屏等，由用户自己扩展，这个方法，使用ffmpeg获取数据的时候才会有效
 

 检查i帧后面8个字节
 byte 8:0x53
 byte 7:0x4e
 byte 6:
 第0位:sd card 状态
 第1位:sd card 是否正在录像，每次取反
 第2位:sd card 是否已满
 第3位:sd card 是否在格式
 第4位:sd card 是否在拍照(瞬间)，每次取反
 第5位:未使用
 第6位:未使用
 第7位:未使用
 
 */

static int RTSDK_H264DataReturnCallBack(void *userData,const char *uid, AVPacket *pkt){
    
    if(pkt->flags){
        
        int frameSize = pkt->size;
        uint8_t *buf = pkt->data;
        
        //LOGD("-----------A---------");
        //LOG_PRINT_HEX(buf,0,60);
        //int temp =frameSize-16;
        //int temp2 = frameSize;
        //LOG_PRINT_HEX(buf,temp,temp2);
        
        if(buf[frameSize-8]==0x53){
            
            if(buf[frameSize-7]==0x4e){
                
                if(gl_sd_status!=(buf[frameSize-6]&0x01)){
                    
                    gl_sd_status=(buf[frameSize-6]&0x01);
                    
                    if([rtDroneLiveSDK.delegate respondsToSelector:@selector(RTSDKLive_SDCardMsgCallBack:msg:)]){
                        
                        [rtDroneLiveSDK.delegate RTSDKLive_SDCardMsgCallBack:RT_DRONE_SDCARD_MSG_TYPE_sd_status msg:gl_sd_status];
                    }
                   
                    LOGE("[%s   %d] JNI_NOTIFY_SD_STATUS =%d ",__FUNCTION__,__LINE__,gl_sd_status);
                }
                if(gl_sd_status==1){
                    if(gl_rec_running!=((buf[frameSize-6]>>1)&0x01)){
                        
                        gl_rec_running=((buf[frameSize-6]>>1)&0x01);
                        
                        if([rtDroneLiveSDK.delegate respondsToSelector:@selector(RTSDKLive_SDCardMsgCallBack:msg:)]){
                            
                            [rtDroneLiveSDK.delegate RTSDKLive_SDCardMsgCallBack:RT_DRONE_SDCARD_MSG_TYPE_sd_recStatue msg:gl_rec_running];
                        }
                        
                        LOGE("[%s   %d] JNI_NOTIFY_REC_RUNNING =%d ",__FUNCTION__,__LINE__,gl_rec_running);
                    }
                    
                    if(gl_sd_capacity!=((buf[frameSize-6]>>2)&0x01)){
                        
                        gl_sd_capacity=((buf[frameSize-6]>>2)&0x01);
                        if(gl_sd_status==1){
                            
                            if([rtDroneLiveSDK.delegate respondsToSelector:@selector(RTSDKLive_SDCardMsgCallBack:msg:)]){
                                
                                [rtDroneLiveSDK.delegate RTSDKLive_SDCardMsgCallBack:RT_DRONE_SDCARD_MSG_TYPE_sd_capacity msg:gl_sd_capacity];
                            }
                            
                        }
                        LOGE("[%s   %d] JNI_NOTIFY_SD_CAPACITY =%d ",__FUNCTION__,__LINE__,gl_sd_capacity);
                        
                    }
                    if(gl_sd_fromat!=((buf[frameSize-6]>>3)&0x01)){
                        
                        gl_sd_fromat=((buf[frameSize-6]>>3)&0x01);
                        if(gl_sd_status==1){
                            
                            if([rtDroneLiveSDK.delegate respondsToSelector:@selector(RTSDKLive_SDCardMsgCallBack:msg:)]){
                                
                                [rtDroneLiveSDK.delegate RTSDKLive_SDCardMsgCallBack:RT_DRONE_SDCARD_MSG_TYPE_sd_format msg:gl_sd_fromat];
                            }

                            
                        }
                        LOGE("[%s   %d] JNI_NOTIFY_SD_FORMAT =%d ",__FUNCTION__,__LINE__,gl_sd_fromat);
                        
                    }
                    if(gl_sd_snap !=((buf[frameSize-6]>>4)&0x01 )){
                        
                        if(gl_sd_status==1 && gl_sd_snap !=-1){
                            
                            if([rtDroneLiveSDK.delegate respondsToSelector:@selector(RTSDKLive_SDCardMsgCallBack:msg:)]){
                                
                                [rtDroneLiveSDK.delegate RTSDKLive_SDCardMsgCallBack:RT_DRONE_SDCARD_MSG_TYPE_sd_snap msg:gl_sd_snap];
                            }
                            
                        }
                        
                        gl_sd_snap = (buf[frameSize-6]>>4)&0x01;
                        LOGE("[%s   %d] JNI_NOTIFY_SD_SNAP =%d ",__FUNCTION__,__LINE__,gl_sd_snap);
                        
                    }
                    
                }else{
                    gl_sd_capacity=0;
                    gl_sd_fromat=1;
                    gl_rec_running=-1;
                }
                
            }
        }
        
    }
    
    return 0;
}


-(int)RTSDKLive_Init{
    init_gl_data();
    
    if(0 != rt_pub_init(&hppPlayerHandler, RT_GET_DATA_FROME_FFMPEG, RT_INIT_VIDEO)){
        hppPlayerHandler = NULL;
        return -1;
    }
    
    return 0;
}


-(int)RTSDKLive_Start:(NSString *)rtspName{
    RT_PARAMS *stRtParams = (RT_PARAMS *)malloc(sizeof(RT_PARAMS));
    if(stRtParams == NULL){
        LOGE("[SDK_Live]  malloc RT_PARAMS faile\n");
        return -1;
    }
    memset(stRtParams, 0, sizeof(RT_PARAMS));
    
    stRtParams->s32BlockScaleData =1;
    stRtParams->s32BlockAudioDecodeData = 0;
    stRtParams->s32BlockVideoDecodeData = 0;
    stRtParams->enAVPixelFormat = AV_PIX_FMT_RGB24;
    
    stRtParams->enRtLiveType = RT_LIVE_TYPE_LIVE;
    stRtParams->enRtSocketType = RT_SOCKET_TCP;
    
    stRtParams->funScaleDataReturnCallBack = RTSDK_scaleDataReturnCallBack;
    stRtParams->funVideoMsgReturnCallBack = RTSDK_VideoMsgReturnCallBack;
    stRtParams->funH264DataReturnCallBack = RTSDK_H264DataReturnCallBack;
    
    RT_PARAMS_EXTRA *stRtParamsExtra = (RT_PARAMS_EXTRA *)malloc(sizeof(RT_PARAMS_EXTRA));
    memset(stRtParamsExtra, 0, sizeof(RT_PARAMS_EXTRA));
    
    stRtParamsExtra->s32CacheFrameNum = 2;
    stRtParamsExtra->s8IsFilterBadFrame = 1;
    stRtParamsExtra->s8IsFilterBadPacket = 1;
    
    stRtParams->stRtParmasExtra = stRtParamsExtra;
    
    if(!rtspName){
        LOGE("[SDK_Live] rtspName == NULL \n");
        return -1;
    }
    
    rt_pub_add_rtsp_ipcam(hppPlayerHandler,stRtParams, [rtspName UTF8String]);
    int rec = rt_pub_start(hppPlayerHandler);
    
    return rec;
}

-(instancetype)init{
    
    rtDroneLiveSDK = self;
   
    return self;
}

-(int)RTSDKLive_Stop{
    int rec = rt_pub_stop(hppPlayerHandler);
    return rec;
}
-(int)RTSDKLive_Exit{
    int rec = rt_pub_exit(hppPlayerHandler);
    hppPlayerHandler = NULL;
    return rec;
}


-(int)RTSDKLive_StartRecMp4:(NSString*)filePath andFps:(int)fps{
    
    if(!filePath){
        LOGE("[SDK_Live] filePath = NULL\n");
        return -1;
    }
    
    return rt_pub_start_rec(hppPlayerHandler, RT_DEFAUT_UID, [filePath UTF8String], fps, 0);
    
}
-(int)RTSDKLive_StopRecMp4{
    int rec = rt_pub_stop_rec(hppPlayerHandler, RT_DEFAUT_UID);
    return rec;
}


-(int)RTSDKLive_GetSaveFrameCount{
    RT_NORMAL_PARAMS stRtNormalParams;
    memset(&stRtNormalParams, 0, sizeof(RT_NORMAL_PARAMS));
    
    int rec = 0;
    rec = rt_pub_get_normal_params(hppPlayerHandler, RT_DEFAUT_UID, &stRtNormalParams);
    rec = stRtNormalParams.s32RevFrameCount;
    return rec;
}

@end

