#include "rvs_inc.h"
#include "rvs_protocol.h"
#include "rvs_pub.h"
#include "rvs_client.h"
#include "rvs_pub_client.h"
#include "rvs_client.h"
static volatile RVS_RUN_FLAG_E RVST_RecvAckThread_State= 0;
static volatile RVS_RUN_FLAG_E RVST_RecvUartThread_State= 0;

static void *RVST_RecvAckThread(void *pstAckCbInfo)
{
	//RVS_ERR_PRINT("--------LOGD_RVS-------E---");

    RVST_RET Ret = RVS_EFAILED;
    RVS_CMD_CB *pstAckCbInfoTmp = NULL;
    RVST_SSIZE s32RecvLen = 0;
    RVST_SOCKET_CFG *pstSocketInfo = NULL;
    RVST_BYTE *AckData = (RVST_BYTE *)malloc(sizeof(RVST_BYTE)*RVS_SOCKET_MAX_DATA_SIZE);

    pstAckCbInfoTmp = (RVS_CMD_CB *)(pstAckCbInfo);    
    if(!pstAckCbInfo || !pstAckCbInfoTmp->RVS_CmdCbFunc|| !pstAckCbInfoTmp->RvsHandle)
    {
        RVS_ERR_PRINT("param err!!pstAckCbInfo[%p]RVS_CmdCbFunc[%p]RvsHandle[%p]\n",
            pstAckCbInfo,pstAckCbInfoTmp->RVS_CmdCbFunc,pstAckCbInfoTmp->RvsHandle);
        goto EXIT;
    }
    pstSocketInfo = (RVST_SOCKET_CFG *)pstAckCbInfoTmp->RvsHandle;
    
    pstAckCbInfoTmp->pcRecvData = AckData;
    pstAckCbInfoTmp->s16OneCmdHeaderLen = sizeof(RVS_PROTOCOL_HEADER);
    pstAckCbInfoTmp->u8CheckSumOnOff = 0;

    while(*(pstAckCbInfoTmp->penRunningFlag) == RVS_RUN_RUNNING)
    {
        RVS_INFO_PRINT("call RVST_RecvSocketData [%s]!\n",pstAckCbInfoTmp->UserData);
        pstSocketInfo->s32Timeout_sec = ((~0UL)>>1);
        Ret = RVST_RecvSocketData(pstSocketInfo, AckData, &(pstAckCbInfoTmp->s32RecvDataLen));
        if(RVS_SUCCESS == Ret && pstAckCbInfoTmp->s32RecvDataLen > 0)//�̻߳���������������ٺ�
        {
        	//RVS_ERR_PRINT("--------LOGD_RVS-------F---");
            RVST_Depacket(pstAckCbInfoTmp);
            memset(AckData,0,s32RecvLen);
        }
        else if(RVS_EFAILED== Ret)
        {
            RVS_ERR_PRINT("RVST_RecvSocketData err!!\n");
            break;
        }
    }

	//RVS_ERR_PRINT("--------LOGD_RVS-------EFFFF---");
EXIT:
    
    if(RVST_WORK_CLIENT_SUBSCRIBE == pstAckCbInfoTmp->enWorkMode )
    {
        free(pstAckCbInfoTmp->RvsHandle);//�ͷ���RVST_CreatRecvAckThread��������Դ
    }
    free(pstAckCbInfo);//�ͷ���RVST_CreatRecvAckThread��������Դ

    if(AckData)
    {
        free(AckData);
    }
        
    return NULL;

}

RVST_RET RVST_CreatRecvAckThread(RVST_INT *RvsHandle,
    RVS_CmdProcess AckCbFunc,void *UserData)
{
    RVS_CMD_CB *pstAckCbInfo = NULL;
    pthread_t RecvAckPid;
    if(NULL == RvsHandle || NULL == AckCbFunc)
    {
        RVS_ERR_PRINT("param err!!\n");
        return RVS_EPARA;
    }

    //malloc ����Դ��RVST_RecvAckThread�ͷ�
    pstAckCbInfo = (RVS_CMD_CB *)malloc(sizeof(RVS_CMD_CB));
    if(NULL == pstAckCbInfo)
    {
        RVS_ERR_PRINT("malloc err!!\n");
        return RVS_EFAILED;
    }

    memset(pstAckCbInfo,0,sizeof(RVS_CMD_CB));
    pstAckCbInfo->RvsHandle = RvsHandle;
    pstAckCbInfo->RVS_CmdCbFunc = AckCbFunc;
    pstAckCbInfo->UserData = UserData;
    pstAckCbInfo->enWorkMode = RVST_WORK_CLIENT_ACK;
    pstAckCbInfo->penRunningFlag = &RVST_RecvAckThread_State;

    RVST_RecvAckThread_State = RVS_RUN_RUNNING;
    
    pthread_create(&RecvAckPid,NULL,RVST_RecvAckThread,pstAckCbInfo);
    pthread_detach(RecvAckPid);

    return RVS_SUCCESS;

}


RVST_RET RVST_DestoryRecvAckThread()
{
    RVST_RecvAckThread_State = RVS_RUN_STOP;
    //pthread_cancel(pstAckCbInfo->RecvAckPid);
    //kill(pstAckCbInfo->RecvAckPid, SIGABRT); 
    //pthread_kill(pstAckCbInfo->RecvAckPid, SIGQUIT);
    //pthread_join(pstAckCbInfo->RecvAckPid,NULL);
    
    return RVS_SUCCESS;
}

RVST_RET RVST_CreatSubscribeDataThread(RVST_INT **ppSubscribeHandle,
    RVS_CmdProcess AckCbFunc,void *UserData)
{
    RVS_CMD_CB *pstAckCbInfo = NULL;
    RVST_SOCKET_CFG *pstSocketCfg = NULL;
    RVST_INT32 s32Ret;
    pthread_t RecvAckPid;
    
    if(NULL == AckCbFunc || !ppSubscribeHandle )
    {
        RVS_ERR_PRINT("param err!!\n");
        return RVS_EPARA;
    }

    //malloc ����Դ��RVST_RecvAckThread�ͷ�
    pstAckCbInfo = (RVS_CMD_CB *)malloc(sizeof(RVS_CMD_CB));
    pstSocketCfg = (RVST_SOCKET_CFG *)malloc(sizeof(RVST_SOCKET_CFG));
    if(NULL == pstAckCbInfo || !pstSocketCfg )
    {
        RVS_ERR_PRINT("malloc err!!\n");
        goto ERR_EXIT;
    }

    memset(pstAckCbInfo,0,sizeof(RVS_CMD_CB));
    memset(pstSocketCfg,0,sizeof(RVST_SOCKET_CFG));
    pstSocketCfg->s32ServerPort = RVST_IPC_MSG_PORT;
    pstSocketCfg->enSocketType = RVS_SOCKET_UDP;
    pstSocketCfg->u32ServerAddr = inet_addr(RVS_BIND_AND_LISTEN_PORT_ADDR);

    s32Ret = RVST_ClientOpenUdp(pstSocketCfg);
    if(RVS_EFAILED == s32Ret)
    {
        RVS_ERR_PRINT("RVST_ServerUdpInit err!!\n");
        goto ERR_EXIT;
    }

    memset(pstAckCbInfo,0,sizeof(RVS_CMD_CB));
    pstAckCbInfo->RvsHandle = (RVST_INT *)pstSocketCfg;
    pstAckCbInfo->RVS_CmdCbFunc = AckCbFunc;
    pstAckCbInfo->UserData = UserData;
    pstAckCbInfo->enWorkMode = RVST_WORK_CLIENT_SUBSCRIBE;
    pstAckCbInfo->penRunningFlag = &RVST_RecvUartThread_State;
    RVST_RecvUartThread_State = RVS_RUN_RUNNING;

	
    pthread_create(&RecvAckPid,NULL,RVST_RecvAckThread,pstAckCbInfo);
    pthread_detach(RecvAckPid);

    *ppSubscribeHandle = (RVST_INT *)pstSocketCfg;

    return RVS_SUCCESS;
    
ERR_EXIT:
    if(pstAckCbInfo)
    {
        free(pstAckCbInfo);
    }
    if(pstSocketCfg)
    {
        free(pstSocketCfg);
    }
    return RVS_EFAILED;

}

RVST_RET RVST_DestoryRecvSubscribeDataThread(RVST_INT *pSubscribeHandle)
{
    if(NULL == pSubscribeHandle)
    {
        RVS_ERR_PRINT("param err!!\n");
        return RVS_EPARA;
    }
    RVST_SOCKET_CFG *pstSocketCfg = (RVST_SOCKET_CFG *)pSubscribeHandle;
    shutdown(pstSocketCfg->s32SocketFd, SHUT_RDWR);
	close(pstSocketCfg->s32SocketFd);
    RVST_RecvUartThread_State = RVS_RUN_STOP;
    
    return RVS_SUCCESS;
}


