#ifndef _RVS_CLIENT_H_
#define _RVS_CLIENT_H_

#include <pthread.h>
#include "rvs_def.h"
#include "rvs_pub.h"

#ifdef __cplusplus
 #if __cplusplus
extern "C" {
 #endif
#endif /* __cplusplus */

RVST_RET RVST_CreatRecvAckThread(RVST_INT *RvsHandle,RVS_CmdProcess AckCbFunc,void *UserData);

RVST_RET RVST_DestoryRecvAckThread();

RVST_RET RVST_CreatSubscribeDataThread(RVST_INT **ppSubscribeHandle,
    RVS_CmdProcess AckCbFunc,void *UserData);

RVST_RET RVST_DestoryRecvSubscribeDataThread(RVST_INT *pSubscribeHandle);

#ifdef __cplusplus
 #if __cplusplus
}
 #endif
#endif /* __cplusplus */


#endif /*_RVS_CLIENT_H_*/

