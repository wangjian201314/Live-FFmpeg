#ifndef __RVS_PROTOCOL_H__
#define __RVS_PROTOCOL_H__

//RVS meas Real Video/Audio Streming
#include "rvs_def.h"

#ifdef __cplusplus
 #if __cplusplus
extern "C" {
 #endif
#endif /* __cplusplus */

#define RVS_MAGIC 0x3E74525B 
    
typedef struct _RVS_PROTOCOL_HEADER_
{
#if (BYTE_ORDER == LITTLE_ENDIAN)
#elif (BYTE_ORDER == BIG_ENDIAN)
#else    
#endif
    
    RVST_INT32    RVSH_Magic;
    
    RVST_UINT16   RVSH_Length;
    RVST_UBYTE    RVSH_Ver;
    RVST_UBYTE    RVSH_SN;
    
    RVST_UINT16   RVSH_CMD;
    RVST_UINT8    RVSH_CHECKSUM;//校验和
    RVST_UINT8    RVSH_RESV2;
}RVS_PROTOCOL_HEADER;

typedef struct _RVS_PROTOCOL_PACKET_
{
    RVST_INT    RVSD_Total_Len;
    RVST_UINT8*  RVSD_Buf;
}RVS_PROTOCOL_PACKET;


    
#ifdef __cplusplus
 #if __cplusplus
}
 #endif
#endif /* __cplusplus */


#endif
