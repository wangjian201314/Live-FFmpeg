/******************************************************************************
File Name     : rvs_pub_client.h
Description   : 
******************************************************************************/
#ifndef RVS_PUB_CLIENT_H
#define RVS_PUB_CLIENT_H

#include "rvs_def.h"
#include "rvs_pub.h"
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#define RVS_BROADCAST_ADDR "239.255.255.255"
#define RVS_BIND_AND_LISTEN_PORT_ADDR "127.0.0.1"
//server_addr ������ip������
//port ���Ϊ0, ����Ĭ�϶˿ں�
//����:hpRvsHandle,���ڷ��Ͳ����ľ��
    
RVST_RET RVST_Connect(RVST_CHAR* pcServerAddr, RVST_INT s32Port,
    RVST_INT s32Timeout, RVST_INT **hppRvsHandle, RVS_SOCKET_TYPE SocketType);
    
RVST_RET RVST_ClientOpenUdp(RVST_SOCKET_CFG *pstSocketCfg);

RVST_RET RVST_DisConnect(RVST_INT *pRvsHandle);

RVST_RET RVST_SendCmdData(RVST_INT *RvstHandle, RVST_UINT16 u16Cmd, RVST_BYTE *pPayloadBuf,
    RVST_UINT16 s16PayloadLen);

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#endif/*RVS_PUB_CLIENT_H*/

