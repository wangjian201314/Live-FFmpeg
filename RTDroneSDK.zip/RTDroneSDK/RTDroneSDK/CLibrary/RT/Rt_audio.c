//
//  Rt_audio.c
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/17.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#include "Rt_audio.h"

//音频解码
static int audioDecodeFrame(RT_AUDIO *stRtAudio,uint8_t *audio_buf ,double *pts_ptr){
    
    if(audio_buf == NULL){
        LOGE("[%s   %d] audio_buf == NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    AVPacket packet;
    AVFrame *pframe;
    
    int dst_sample_fmt;
    
    uint64_t dst_channel_layout;
    int dst_nb_sample;
    int convert_len;
    SwrContext *swr_ctx = NULL;
    
    int data_size;
	int decoded_data_size;
	int wanted_nb_samples, resampled_data_size, n;
    int64_t dec_channel_layout;
	double pts;
	
    if(!stRtAudio->pstAudioPacketQueue){
        LOGE("[%s   %d] pstAudioPacketQueue is null \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    if(stRtAudio->pstAudioPacketQueue->nb_packets <= 0){
        //LOGE("[%s   %d] nb_packets is <=0 \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    if(rt_queue_get( stRtAudio->pstAudioPacketQueue, &packet,0) <=0)
    {
        LOGE("[%s   %d] queue get faile \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    int s32Rec = 0;
    
    pframe = av_frame_alloc();
    if(!pframe){
        LOGE("[%s   %d] av_frame_alloc faile \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
#if 0
    
    int s32FrameFinished;
    
    s32Rec = avcodec_decode_audio4(stRtAudio->pAudioCodecCtx, pframe, &s32FrameFinished,&packet);
    
    if(s32Rec <0){
        LOG_PRINT_HEX(packet.data, 0, 30);
        LOGE("[%s   %d] avcodec_decode_audio4 error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
#else
    
    s32Rec = avcodec_send_packet(stRtAudio->pAudioCodecCtx,&packet);
    if(s32Rec != 0){
        LOGE("[%s   %d] avcodec_send_packet error \n",__FUNCTION__,__LINE__);
        LOG_PRINT_HEX(packet.data, 0, 30);
        goto ERR_EXIT;
    }
    s32Rec = avcodec_receive_frame(stRtAudio->pAudioCodecCtx,pframe);
    if(s32Rec != 0){
        LOGE("[%s   %d] avcodec_receive_frame error \n",__FUNCTION__,__LINE__);
        LOG_PRINT_HEX(packet.data, 0, 30);
        goto ERR_EXIT;
    }
    
#endif
	
#if 1
	
    if(pframe->channels>0 && pframe->channel_layout == 0){
        pframe->channel_layout = av_get_default_channel_layout(pframe->channels);
    }else if(pframe->channels ==0 && pframe->channel_layout > 0){
        pframe->channels = av_get_channel_layout_nb_channels(pframe->channel_layout);
    }

	
    dst_sample_fmt = AV_SAMPLE_FMT_S16;
    dst_channel_layout = av_get_default_channel_layout(pframe->channels);
    
    swr_ctx = swr_alloc();
    swr_ctx = swr_alloc_set_opts(swr_ctx, dst_channel_layout, dst_sample_fmt, pframe->sample_rate, pframe->channel_layout, pframe->format, pframe->sample_rate, 0, NULL);
    
    if(swr_ctx == NULL || swr_init(swr_ctx)< 0){
        goto ERR_EXIT;
    }
    
    dst_nb_sample = av_rescale_rnd(swr_get_delay(swr_ctx, pframe->sample_rate)+pframe->nb_samples, pframe->sample_rate, pframe->sample_rate, AV_ROUND_INF);
    
    convert_len = swr_convert(swr_ctx, &audio_buf, dst_nb_sample, (const uint8_t **)pframe->data, pframe->nb_samples);
    
    resampled_data_size = convert_len * pframe->channels * av_get_bytes_per_sample(dst_sample_fmt);
	
#if 1
	
	*pts_ptr = stRtAudio->s64AudioClock;

	double s64Pts = 0;
	s64Pts  = (pframe->pts == AV_NOPTS_VALUE) ? NAN : packet.pts * av_q2d((AVRational){1, stRtAudio->pAudioCodecCtx->sample_rate});
	
	//LOGD("[%s   %d] s64Pts=%f  pkt_pts=%lld  pts=%lld\n",__FUNCTION__,__LINE__,s64Pts,packet.pts,pframe->pts);
	
	if(!isnan(s64Pts)){
		
		//每秒钟音频播放的字节数 sample_rate * channels * sample_format(一个sample占用的字节数)
		//乘以2是因为sample format是16位的无符号整型，占用2个字节。
		n = 2 * stRtAudio->pAudioCodecCtx->channels;
		stRtAudio->s64AudioClock += (double)resampled_data_size /(double)(n * stRtAudio->pAudioCodecCtx->sample_rate);
		
		/*if(stRtAudio->s64FirstStartPts == -1){
			stRtAudio->s64FirstStartPts = stRtAudio->s64AudioClock;
			stRtAudio->s64FirstStartPts = 0;
			LOGD("[%s   %d] s64FirstStartPts =%f\n",__FUNCTION__,__LINE__,stRtAudio->s64FirstStartPts);
		}
		
		//让计时从0开始
		stRtAudio->s64AudioClock = stRtAudio->s64AudioClock - stRtAudio->s64FirstStartPts;*/
		
		//LOGD("[%s   %d] stRtAudio->s64AudioClock =%f \n",__FUNCTION__,__LINE__,stRtAudio->s64AudioClock);
		
	}else{
		stRtAudio->s64AudioClock = NAN;
	}
	
#else
	
	 pts = stRtAudio->s64AudioClock;
     *pts_ptr = pts;
     n = 2 * stRtAudio->pAudioCodecCtx->channels;
     stRtAudio->s64AudioClock += (double)resampled_data_size /(double)(n * stRtAudio->pAudioCodecCtx->sample_rate);
	 if(stRtAudio->s64FirstStartPts == -1){
		stRtAudio->s64FirstStartPts = stRtAudio->s64AudioClock;
	 }
	 stRtAudio->s64AudioClock = stRtAudio->s64AudioClock - stRtAudio->s64FirstStartPts;
	 
#endif
	
	av_frame_free(&pframe);
    swr_free(&swr_ctx);
    
    if(packet.size>0){
        av_packet_unref(&packet);
    }

#else
	

 	/* 计算解码出来的桢需要的缓冲大小 */
	decoded_data_size = av_samples_get_buffer_size(NULL,
			pframe->channels, pframe->nb_samples,
			pframe->format, 1);

	dec_channel_layout =(pframe->channel_layout && pframe->channels 
							== av_get_channel_layout_nb_channels(pframe->channel_layout)) ?
								pframe->channel_layout :av_get_default_channel_layout(pframe->channels);

	wanted_nb_samples = pframe->nb_samples;

    if (pframe->format != stRtAudio->enAudioSrcFmt
		   || dec_channel_layout != stRtAudio->u64AudioSrcChannelLayout
		   || pframe->sample_rate != stRtAudio->s32AudioSrcFreq 
		   || (wanted_nb_samples != pframe->nb_samples
				   && !stRtAudio->stpSwsCtx)) {
	   	if (stRtAudio->stpSwsCtx){
		   swr_free(&stRtAudio->stpSwsCtx);
		   LOGD("[%s   %d] stpSwsCtx not null and free swr_free \n",__FUNCTION__,__LINE__);
	   	}
		
		dst_sample_fmt = AV_SAMPLE_FMT_S16;
    	dst_channel_layout = av_get_default_channel_layout(pframe->channels);
	   	
	   	stRtAudio->stpSwsCtx = swr_alloc_set_opts(NULL,
			   dst_channel_layout, dst_sample_fmt,
			   pframe->sample_rate, dec_channel_layout,
			   pframe->format, pframe->sample_rate,
			   0, NULL);
	   	if (!stRtAudio->stpSwsCtx || swr_init(stRtAudio->stpSwsCtx) < 0) {
		   	LOGE("[%s   %d] swr_init() failed \n",__FUNCTION__,__LINE__);
		   	return;
	   	}
		
	   	stRtAudio->u64AudioSrcChannelLayout= dec_channel_layout;
	   	stRtAudio->s32AudioSrcChannels= stRtAudio->pAudioCodecCtx->channels;
	   	stRtAudio->s32AudioSrcFreq = stRtAudio->pAudioCodecCtx->sample_rate;
	   	stRtAudio->enAudioSrcFmt = stRtAudio->pAudioCodecCtx->sample_fmt;
		LOGD("[%s   %d] swr_init success \n",__FUNCTION__,__LINE__);
    }

	
	/* 这里我们可以对采样数进行调整，增加或者减少，一般可以用来做声画同步 */
    if (is->swr_ctx) {
	   const uint8_t **in =
			   (const uint8_t **) pframe->extended_data;
	   uint8_t *out[] = { audio_buf2 };
	   if (wanted_nb_samples != pframe->nb_samples) {
		   if (swr_set_compensation(stRtAudio->stpSwsCtx ,
		   				(wanted_nb_samples - pframe->nb_samples) * 
		   				stRtAudio->s32AudioSrcFreq /
		   				pframe->sample_rate,wanted_nb_samples * stRtAudio->s32AudioSrcFreq / pframe->sample_rate) < 0) {
			   LOGE("[%s   %d] swr_set_compensation() failed\n",__FUNCTION__,__LINE__);
			   return;
		   }
	   }
	   
	   len2 = swr_convert(is->swr_ctx, out,sizeof(audio_buf2) / stRtAudio->s32AudioSrcChannels
					   / av_get_bytes_per_sample(is->audio_tgt_fmt),
			   in, is->audio_frame->nb_samples);
	   if (len2 < 0) {
		   fprintf(stderr, "swr_convert() failed\n");
		   break;
	   }
	   if (len2
			   == sizeof(is->audio_buf2) / is->audio_tgt_channels
					   / av_get_bytes_per_sample(is->audio_tgt_fmt)) {
		   fprintf(stderr,
				   "warning: audio buffer is probably too small\n");
		   swr_init(is->swr_ctx);
	   }
	   audio_buf = audio_buf2;
	   resampled_data_size = len2 * is->audio_tgt_channels
			   * av_get_bytes_per_sample(is->audio_tgt_fmt);
    } else {
	   resampled_data_size = decoded_data_size;
	   audio_buf = is->audio_frame->data[0];
    }
	
#endif
	
    
    //保存音频参数,用于mp4v2保存音频
    if(stRtAudio->stRtAudioParams){
        if(stRtAudio->stRtAudioParams->s32Channel != stRtAudio->pAudioCodecCtx->channels){
            stRtAudio->stRtAudioParams->s32Channel = stRtAudio->pAudioCodecCtx->channels;
            LOGD("[%s   %d] s32Channel =%d \n",__FUNCTION__,__LINE__,stRtAudio->pAudioCodecCtx->channels);
        }
		
        if(stRtAudio->stRtAudioParams->s32Profile != stRtAudio->pAudioCodecCtx->profile){
            stRtAudio->stRtAudioParams->s32Profile = stRtAudio->pAudioCodecCtx->profile;
            LOGD("[%s   %d] profile =%d \n",__FUNCTION__,__LINE__,stRtAudio->pAudioCodecCtx->profile);
        }
        
        if(stRtAudio->stRtAudioParams->s32Sample_rate != stRtAudio->pAudioCodecCtx->sample_rate){
            stRtAudio->stRtAudioParams->s32Sample_rate = stRtAudio->pAudioCodecCtx->sample_rate;
            LOGD("[%s   %d] s32Sample_rate =%d \n",__FUNCTION__,__LINE__,stRtAudio->pAudioCodecCtx->sample_rate);
        }
    }

	
    return resampled_data_size;
    
ERR_EXIT:
    
    if(packet.size>0){
        av_packet_unref(&packet);
    }
    
    if(pframe){
        av_frame_free(&pframe);
    }
    
    if(swr_ctx){
        swr_free(&swr_ctx);
    }
    
    return -1;
}


int rt_audio_init(RT_AUDIO *stRtAudio,enum AVCodecID avCodecID,AVCodecParameters *par){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    stRtAudio->s32AudioStreamIndex = 0;
    stRtAudio->s64AudioClock = 0;
    stRtAudio->s32OpenAudio = 0;
	stRtAudio->u32AudioBufIndex = 0;
	stRtAudio->s64FirstStartPts = -1;
	stRtAudio->s64FirstAudioTimestamp = -1;
	stRtAudio->s34FrameCount = 0;
	stRtAudio->enRtAudioType = RT_AUDIO_TYPE_AAC;
    
    rt_audio_relase(stRtAudio);
    
    stRtAudio->pstAudioPacketQueue = (RtQueue *)malloc(sizeof(RtQueue));
    memset(stRtAudio->pstAudioPacketQueue, 0, sizeof(RtQueue));
    
    rt_queue_init(stRtAudio->pstAudioPacketQueue);
    
    //解码来播放
    stRtAudio->pAudioCodec = avcodec_find_decoder(avCodecID);
    
    if(NULL == stRtAudio->pAudioCodec){
        LOGE("[%s    %d] cannot find audio \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    
    stRtAudio->pAudioCodecCtx = avcodec_alloc_context3(stRtAudio->pAudioCodec);
    
    if(NULL == stRtAudio->pAudioCodecCtx){
        LOGE("[%s    %d] avcodec_alloc_context3  error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    if(par){
        
        if(avcodec_parameters_to_context(stRtAudio->pAudioCodecCtx,par)<0){
            LOGE("[%s   %d]can't copy decoder context \n",__FUNCTION__,__LINE__);
            goto ERR_EXIT;
        }else{        
            av_codec_set_pkt_timebase(stRtAudio->pAudioCodecCtx, stRtAudio->pAudioStream->time_base);
            LOGD("[%s   %d]copy decoder context success\n",__FUNCTION__,__LINE__);
        }
		
		if(par->format == 1){
        	LOGD("[%s    %d] find audio decoder success format = AV_SAMPLE_FMT_S16 \n",__FUNCTION__,__LINE__);
		}else{
			LOGD("[%s    %d] find audio decoder success format =%d \n",__FUNCTION__,__LINE__,par->format);
		}
		
		if(par->codec_id == AV_CODEC_ID_AAC){
			stRtAudio->enRtAudioType = RT_AUDIO_TYPE_AAC;
			LOGD("[%s    %d] codec_id = AV_CODEC_ID_AAC \n",__FUNCTION__,__LINE__);
		}else if(par->codec_id == AV_CODEC_ID_PCM_ALAW){
			stRtAudio->enRtAudioType = RT_AUDIO_TYPE_OTHER;
			LOGD("[%s	 %d] codec_id = AV_CODEC_ID_PCM_ALAW \n",__FUNCTION__,__LINE__);
		}else{
			stRtAudio->enRtAudioType = RT_AUDIO_TYPE_OTHER;
			LOGD("[%s	 %d] codec_id = %d \n",__FUNCTION__,__LINE__,par->codec_id);
		}

		if(par && stRtAudio->stRtAudioParams){
        	stRtAudio->stRtAudioParams->s32Sample_rate = stRtAudio->pAudioCodecCtx->sample_rate;
        	stRtAudio->stRtAudioParams->s32Channel = stRtAudio->pAudioCodecCtx->channels;
        	stRtAudio->stRtAudioParams->s32Profile = stRtAudio->pAudioCodecCtx->profile;

			/*
			 profile:
			 #define FF_PROFILE_UNKNOWN -99
		  	 #define FF_PROFILE_RESERVED -100
		     #define FF_PROFILE_AAC_MAIN 0
		     #define FF_PROFILE_AAC_LOW  1
		     #define FF_PROFILE_AAC_SSR  2
		     #define FF_PROFILE_AAC_LTP  3
		     #define FF_PROFILE_AAC_HE   4
		     #define FF_PROFILE_AAC_HE_V2 28
		  	 #define FF_PROFILE_AAC_LD   22
		  	 #define FF_PROFILE_AAC_ELD  38
			*/
			if(par->profile == FF_PROFILE_AAC_LOW){
				LOGD("[%s	%d] sample_rate=%d channels=%d bit_rate=%lld profile=FF_PROFILE_AAC_LOW channel_layout=%lld level=%d\n",__FUNCTION__,__LINE__,par->sample_rate,par->channels,par->bit_rate,par->channel_layout,par->level);
			}else{
				LOGD("[%s	%d] sample_rate=%d channels=%d bit_rate=%lld profile=%d channel_layout=%lld level=%d\n",__FUNCTION__,__LINE__,par->sample_rate,par->channels,par->bit_rate,par->profile,par->channel_layout,par->level);
			}

			//根据采样率，信道等信息确认pcm要转为aac所需要的buf长度(即多长的pcm数据可以转成一帧aac，用来存储mp4)
			stRtAudio->s32PcmToAacSize = av_samples_get_buffer_size(NULL,stRtAudio->stRtAudioParams->s32Channel,1024,AV_SAMPLE_FMT_S16,1);
			
    	}
		
    }else{
        stRtAudio->pAudioCodecCtx->codec_type = AVMEDIA_TYPE_AUDIO;
    }
    
    if(avcodec_open2(stRtAudio->pAudioCodecCtx, stRtAudio->pAudioCodec, NULL) < 0){
        LOGE("[%s    %d] avcodec_open2  error\n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    //新建音频参数结构体
   /* stRtAudio->stRtAudioParams = (RT_AUDIO_PARAMS *)malloc(sizeof(RT_AUDIO_PARAMS));
    if(!stRtAudio->stRtAudioParams){
        LOGE("[%s   %d] malloc stRtAudioParams faile \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }*/
    
    stRtAudio->pAudioBuf = (uint8_t *)malloc(RT_AUDIO_INBUF_SIZE + AV_INPUT_BUFFER_PADDING_SIZE);
    if(!stRtAudio->pAudioBuf){
        LOGE("[%s   %d] malloc pAudioBuf faile \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
	
    return 0;
ERR_EXIT:
    
    if(stRtAudio->pAudioCodecCtx){
        avcodec_free_context(&stRtAudio->pAudioCodecCtx);
        stRtAudio->pAudioCodecCtx = NULL;
    }
    
    if(stRtAudio->pAudioBuf){
        free(stRtAudio->pAudioBuf);
        stRtAudio->pAudioBuf = NULL;
    }

	if(stRtAudio->stRtAudioParams){
        //free(stRtAudio->stRtAudioParams);
        stRtAudio->stRtAudioParams = NULL;
    }
    
    return -1;
}




//获取视频的时钟，将用于视频同步到音频
int rt_audio_decode(RT_AUDIO *stRtAudio,uint8_t *buf,double *pts_ptr){

	/**
	*如果是pcm的数据这里就不需要解码了，直接进行拷贝即可
	*如果是aac或者adbpcm就需要进行转码
	*/
    if(stRtAudio->enRtAudioType == RT_AUDIO_TYPE_PCM){
        AVPacket packet;
        
        if(!stRtAudio->pstAudioPacketQueue){
            LOGE("[%s   %d] pstAudioPacketQueue is null \n",__FUNCTION__,__LINE__);
            return -1;
        }
        
        if(stRtAudio->pstAudioPacketQueue->nb_packets <= 0){
            //LOGE("[%s   %d] nb_packets is <=0 \n",__FUNCTION__,__LINE__);
            return -1;
        }
        
        if(rt_queue_get( stRtAudio->pstAudioPacketQueue, &packet,0) <=0)
        {
            LOGE("[%s   %d] queue get faile \n",__FUNCTION__,__LINE__);
            return -1;
        }
        
        int size = packet.size;
        memcpy(buf, packet.data, size);
        if(packet.size>0){
            av_packet_unref(&packet);
        }

		//通过采样率，信道，播放的长度来累计音频播放的时长
		int n = 2 * stRtAudio->stRtAudioParams->s32Channel;
		stRtAudio->s64AudioClock += (double)size/(double)(n * stRtAudio->stRtAudioParams->s32Sample_rate);
		
        return size;
        
    }else{
        return audioDecodeFrame(stRtAudio, buf,pts_ptr);
    }
}


int rt_audio_relase(RT_AUDIO *stRtAudio){
    
    if(stRtAudio->pAudioCodecCtx){
        avcodec_free_context(&stRtAudio->pAudioCodecCtx);
        stRtAudio->pAudioCodecCtx = NULL;
        LOGD("[%s    %d] free pAudioCodecCtx success \n",__FUNCTION__,__LINE__);
    }
    
    
    if(stRtAudio->pAudioBuf){
        free(stRtAudio->pAudioBuf);
        stRtAudio->pAudioBuf = NULL;
        LOGD("[%s   %d] free pAudioBuf \n",__FUNCTION__,__LINE__);
    }

    
    /*if(stRtAudio->stRtAudioParams){
        //free(stRtAudio->stRtAudioParams);
        stRtAudio->stRtAudioParams = NULL;
        LOGD("[%s   %d] free stRtAudioParams \n",__FUNCTION__,__LINE__);
    }*/
    
    if(stRtAudio->pstAudioPacketQueue){
        rt_queue_destroy(stRtAudio->pstAudioPacketQueue);
        free(stRtAudio->pstAudioPacketQueue);
        stRtAudio->pstAudioPacketQueue = NULL;
    }
    
    
    return 0;
}
