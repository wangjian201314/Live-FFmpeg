#include <stdio.h>
#include <stdlib.h>
#include "Rt_pub_def.h"


static int RTSDK_scaleDataReturnCallBack(void*userData,RT_PICTURE *pstPicture){
	return 0;
}


static int RTSDK_VideoMsgReturnCallBack(void*userData,const char *uid, RT_MSG_TYPE msgType,int msg){

	LOGD("[%s   %d]  uid =%s  msgType =%d msg =%d \n",__FUNCTION__,__LINE__,uid,msgType,msg);
    switch (msgType) {
        case RT_MSG_TYPE_SHOW:
            //视频开始显出
						
            break;
            
        case RT_MSG_TYPE_RESOLUTION:
			
		break;
		case RT_MSG_TYPE_FILE_OPNE_STATE:
		//打开文件失败(成功与否)
		
		break;
		case RT_MSG_TYPE_TOTAL_PTS:
		//文件的总时长

		break;
		case RT_MSG_TYPE_SEEK_STATE:
		//快进的状态(成功与否)

		break;
		case RT_MSG_TYPE_AUIDO_OPEN_STATE:
		//音频打开状态(成功与否)

		break;
		
        default:
            break;
    }
    
    return 0;
}


static int RTSDK_audioDecodeDataReturnCallBack(void*userData,const char *uid,uint8_t *data,int len){
	
	return 0;
}


#if 1
int testMain(int arg,char *argv[]){


#ifdef LOCAL//使用ffmpeg的方式去获取数据
	
	int *pPlayerHandle;
	
	rt_pub_init(&pPlayerHandle,RT_GET_DATA_FROME_FFMPEG,RT_INIT_VIDEO);
	
	RT_PARAMS *stRtParams = (RT_PARAMS *)malloc(sizeof(RT_PARAMS));
    if(NULL== stRtParams){
        LOGE("[%s   %d] malloc RT_PARAMS faile \n",__FUNCTION__,__LINE__);
        return -1;
    };

	memset(stRtParams,0,sizeof(RT_PARAMS));//这个不能缺少

	stRtParams->s32BlockVideoDecodeData = 0;
  	stRtParams->s32BlockScaleData = 1;
	stRtParams->s32BlockAudioDecodeData = 1;
  	stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
	stRtParams->enRtOpenAudioState = RT_AUDIO_ENABLE;
    stRtParams->enRtSocketType = RT_SOCKET_NONE;
    stRtParams->avCodecID = AV_CODEC_ID_H264;

	// RT_LIVE_TYPE_NONE = -1,
    //RT_LIVE_TYPE_LOCAL =0,   //本地回放
    //RT_LIVE_TYPE_LIVE,       //直播
    //RT_LIVE_TYPE_REMOTE,     //远程回放
	stRtParams->enRtLiveType = RT_LIVE_TYPE_LOCAL;
	stRtParams->funScaleDataReturnCallBack = RTSDK_scaleDataReturnCallBack;
	stRtParams->funVideoMsgReturnCallBack = RTSDK_VideoMsgReturnCallBack;
	stRtParams->funAudioDecodeDataReturnCallBack= RTSDK_audioDecodeDataReturnCallBack;
	strcpy(stRtParams.acDid,RT_DEFAUT_UID);

	/***添加ipc，并开始播放***/
	rt_pub_add_local_ipcam(pPlayerHandle,stRtParams,"test.mp4");
	rt_pub_start(pPlayerHandle);
	
	
	/***录像**/
	//rt_pub_start_rec(pPlayerHandle,pDid,const char * pFileName,int fps,int s32SynTime)
	//rt_pub_stop_rec(pPlayerHandle,pDid);
	
	/***开始播放音频***/
	//rt_pub_audio_open(pPlayerHandle,pDid,int openState);

	
	/***退出***/
	rt_pub_stop(pPlayerHandle);
	rt_pub_exit(pPlayerHandle);
	pPlayerHandle = NULL;
#elif P2P //通过p2p的方式获取数据，数据源由外部添加
	
	int *pPlayerHandle;
	const char* pDid ="PPCN_xxx";
	
	rt_pub_init(&pPlayerHandle,RT_GET_DATA_FROME_OTHER,RT_INIT_ALL);

	RT_PARAMS *stRtParams = (RT_PARAMS *)malloc(sizeof(RT_PARAMS));
    if(NULL== stRtParams){
        LOGE("[%s   %d] malloc RT_PARAMS faile \n",__FUNCTION__,__LINE__);
        return -1;
    };

	memset(stRtParams,0,sizeof(RT_PARAMS));//这个不能缺少
	
	stRtParams->s32BlockVideoDecodeData = 0;
  	stRtParams->s32BlockScaleData = 1;
	stRtParams->s32BlockAudioDecodeData = 1;
  	stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
	stRtParams->enRtOpenAudioState = RT_AUDIO_ENABLE;
    stRtParams->enRtSocketType = RT_SOCKET_NONE;
    stRtParams->avCodecID = AV_CODEC_ID_H264;
	stRtParams->enRtAudioType = RT_AUDIO_TYPE_PCM;
	
	stRtParams->enRtLiveType = RT_LIVE_TYPE_LIVE;// RT_LIVE_TYPE_NONE = -1,RT_LIVE_TYPE_LOCAL =0, 本地回放RT_LIVE_TYPE_LIVE, //直播RT_LIVE_TYPE_REMOTE,//远程回放
	stRtParams->funScaleDataReturnCallBack = RTSDK_scaleDataReturnCallBack;
	stRtParams->funVideoMsgReturnCallBack = RTSDK_VideoMsgReturnCallBack;
	stRtParams->funAudioDecodeDataReturnCallBack= RTSDK_audioDecodeDataReturnCallBack;
	strcpy(stRtParams->acDid,pDid);
	
	//如果音频是pcm，必须要预设值要，因为内部无法获取相应的信息
	if(stRtParams->enRtAudioType == RT_AUDIO_TYPE_PCM){
		stRtParams->stRtAudioParams.s32Channel = 1;
		stRtParams->stRtAudioParams.s32Profile = FF_PROFILE_AAC_LOW;
		stRtParams->stRtAudioParams.s32Sample_rate = 8000;
	}
	
	
	/***添加ipc，并开始播放***/
	rt_pub_add_p2p_ipcam(pPlayerHandle,stRtParams);
	rt_pub_start(pPlayerHandle);
	
	/***添加数据***/
	//rt_pub_add_video_h264(pPlayerHandle,pDid,unsigned char * data,int len,double time,int keyFrame);
	//rt_pub_add_video_h265(pPlayerHandle,const char * pDid,unsigned char * data,int len,double time,int keyFrame);
	//rt_pub_add_audio_aac(pPlayerHandle,pDid,unsigned char * data,int len,double time);
	//rt_pub_add_audio_pcm(pPlayerHandle,pDid,unsigned char * data,int len,double time);
	
	
	/***录像**/
	//rt_pub_start_rec(pPlayerHandle,pDid,const char * pFileName,int fps,int s32SynTime);
	//rt_pub_stop_rec(pPlayerHandle,pDid);

	
	/***开始播放音频***/
	//rt_pub_audio_open(pPlayerHandle,pDid,int openState);

	
	/***退出***/
	rt_pub_stop(pPlayerHandle);
	rt_pub_exit(pPlayerHandle);
	pPlayerHandle = NULL;
	
#elif RTSP
	
	static int *hppPlayerHandler;
	if(0 != rt_pub_init(&hppPlayerHandler,RT_GET_DATA_FROME_FFMPEG,RT_INIT_VIDEO)){
		hppPlayerHandler = NULL;
		return -1;
	}
	
	RT_PARAMS *stRtParams = (RT_PARAMS *)malloc(sizeof(RT_PARAMS));
	if(NULL== stRtParams){
		LOGE("[%s	%d] malloc RT_PARAMS faile \n",__FUNCTION__,__LINE__);
		return -1;
	};
	memset(stRtParams,0,sizeof(RT_PARAMS));//这个不能缺少
	
	stRtParams->s32BlockVideoDecodeData = 0;
	stRtParams->s32BlockScaleData = 1;
	stRtParams->s32BlockAudioDecodeData = 0;
	stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
	stRtParams->enRtOpenAudioState = RT_AUDIO_DISENABLE;
	stRtParams->enRtSocketType =  RT_SOCKET_TCP 
	stRtParams->avCodecID = AV_CODEC_ID_H264;
	stRtParams->enRtLiveType = RT_LIVE_TYPE_LIVE;
	stRtParams->funScaleDataReturnCallBack = RTSDK_scaleDataReturnCallBack;
	stRtParams->funVideoMsgReturnCallBack = RTSDK_VideoMsgReturnCallBack;
	
	/*高级设置*/
	/*
	RT_PARAMS_EXTRA *stRtParmasExtra =(RT_PARAMS_EXTRA *)malloc(sizeof(RT_PARAMS_EXTRA));
	memset(stRtParmasExtra,0,sizeof(RT_PARAMS_EXTRA));
	stRtParams->stRtParmasExtra = stRtParmasExtra;
	stRtParams->stRtParmasExtra->s32CacheFrameNum = 1;//设置缓存的个数
	*/
	
	
	int rec = rt_pub_add_rtsp_ipcam(hppPlayerHandler, stRtParams,"rtsp://192.168.99.1/12");
	if(rec <0){
		return -1;
	}
	
	rec = rt_pub_start(hppPlayerHandler);
	if(rec <0){
		return -1;
	}

	
	//运行中********


	/*
	运行退出后
	*/
	rt_pub_stop(hppPlayerHandler);
	rt_pub_exit(hppPlayerHandler);
	pPlayerHandle = NULL;
	
#endif
	
	return 0;
}

#endif
