//
//  Rt_queue.c
//  RunTopSDK
//
//  Created by 杨青远 on 2017/4/12.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#include "Rt_queue.h"
#include "Rt_app_log.h"


int rt_queue_init(RtQueue *queue)
{
    
    /*if(queue->last_pkt){
     av_free(queue->last_pkt);
     queue->last_pkt	 = NULL;
     }
     
     //≥ı ºªØ÷Æ«∞»∑±£œ» Õ∑≈
     if(queue->first_pkt){
     av_free(queue->first_pkt);
     queue->first_pkt = NULL;
     }
     
     queue->nb_packets = 0;
     queue->size		  = 0;
     */
    
    memset(queue, 0, sizeof(RtQueue));
    
    if(queue->mutex){
        SDL_UnlockMutex(queue->mutex);
        SDL_DestroyMutex(queue->mutex);
        queue->mutex = NULL;
    }
    
    if(queue->cond){
        //SDL_CondSignal(queue->cond);
        SDL_DestroyCond(queue->cond);
        queue->cond = NULL;
    }
    
    
    queue->mutex = SDL_CreateMutex();
    queue->cond	 = SDL_CreateCond();
    
    return 0;
}


int rt_queue_put(RtQueue *queue,AVPacket *pkt)
{
    
    if(!queue->mutex){
        LOGD("[%s    %d] mutex==NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    AVPacketList *pkt_list;
    
    if(av_dup_packet(pkt) < 0){
        return -1;
    }
    
    pkt_list = (AVPacketList *)av_malloc(sizeof(AVPacketList));
    if(pkt_list	== NULL){
        return -1;
    }
    
    /*
    av_init_packet(&pkt_list->pkt);
    if(av_packet_ref(&pkt_list->pkt,pkt)<0){
        return -1;
    }*/
    
    pkt_list->pkt = *pkt;
    pkt_list->next = NULL;
   
    SDL_LockMutex(queue->mutex);
    
    if(queue->last_pkt == NULL){
        queue->first_pkt = pkt_list;
    }
    else{
        queue->last_pkt->next = pkt_list;
    }
    
    queue->last_pkt = pkt_list;
    queue->nb_packets++;
    queue->size += pkt->size;
    
    SDL_CondSignal(queue->cond);
    SDL_UnlockMutex(queue->mutex);
    
    return 0;
}


int rt_queue_get(RtQueue *queue,AVPacket *pkt,int block){
    
    if(queue == NULL || !queue->mutex ){
        LOGD("[%s    %d] mutex==NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    AVPacketList *pkt_list = NULL;
    int ret = 0;
    
    SDL_LockMutex(queue->mutex);
    
    while(1)
    {
        pkt_list = queue->first_pkt;
        if(pkt_list != NULL){
            //queue->first_pkt =queue->first_pkt->next;
            queue->first_pkt =pkt_list->next;
            if(queue->first_pkt == NULL){
                queue->last_pkt = NULL;
            }
            
            queue->nb_packets--;
            queue->size -= pkt_list->pkt.size;
            *pkt = pkt_list->pkt;
            
            /*if(av_packet_ref(pkt,&pkt_list->pkt)<0){
                break;
            }
            av_packet_unref(&pkt_list->pkt);*/
            
            av_free(pkt_list);
            
            ret = 1;
            break;
        }
        else if(block ==0){
            ret = 0;
            break;
        }
        else{
            SDL_CondWait(queue->cond,queue->mutex);
        }
        
    }
    
    SDL_UnlockMutex(queue->mutex);
    
    return ret;
}


//ΩˆΩˆ«Âø’∂”¡–
int rt_queue_clear(RtQueue *queue){
    
    
    if(queue == NULL || NULL == queue->mutex ){
        LOGD("[%s    %d] mutex==NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
    LOGD("[%s   %d] nb_packets=%d \n",__FUNCTION__,__LINE__,queue->nb_packets);
    
    
#if 0
    SDL_LockMutex(queue->mutex);
    
    while(1)
    {
        AVPacketList *pkt_list = NULL;
        pkt_list = queue->first_pkt;
        if(pkt_list != NULL){
            
            queue->first_pkt = pkt_list->next;
            if(queue->first_pkt == NULL){
                queue->last_pkt = NULL;
            }
            
            queue->nb_packets--;
            queue->size -= pkt_list->pkt.size;
            
            av_free(pkt_list);
            
            pkt_list = NULL;
            
        }else{
            break;
        }
        
    }
    SDL_UnlockMutex(queue->mutex);
#else
    
    AVPacketList *pkt, *pkt1;
    
    SDL_LockMutex(queue->mutex);
    
    for(pkt = queue->first_pkt; pkt != NULL; pkt = pkt1) {
        pkt1 = pkt->next;
        //av_free_packet(&pkt->pkt);
        av_packet_unref(&pkt->pkt);
        av_freep(&pkt);
    }
    
    queue->last_pkt = NULL;
    queue->first_pkt = NULL;
    queue->nb_packets = 0;
    queue->size = 0;
    SDL_UnlockMutex(queue->mutex);
    
    
#endif
    LOGD("[%s   %d] end\n",__FUNCTION__,__LINE__);
    return 0;
}


int rt_queue_clear_pframe(RtQueue *queue){
    
    LOGD("[%s   %d] nb_packets=%d \n",__FUNCTION__,__LINE__,queue->nb_packets);
    
    if(queue == NULL || NULL == queue->mutex ){
        LOGD("[%s    %d] mutex==NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    int isBreak = 0;
    
    AVPacketList *pkt_list = NULL;
    
    SDL_LockMutex(queue->mutex);
    
    while(1)
    {	
        
        pkt_list = queue->first_pkt;
        if(pkt_list != NULL){
            
            queue->first_pkt = pkt_list->next;
            if(queue->first_pkt == NULL){
                queue->last_pkt = NULL;
            }
            
            
            if(pkt_list->pkt.flags){
                isBreak = 1;
            }
            
            queue->nb_packets--;
            queue->size -= pkt_list->pkt.size;
            
            //av_free_packet(&pkt_list->pkt);
            av_packet_unref(&pkt_list->pkt);
            av_free(pkt_list);
            
            if(isBreak){
                break;
            }
            
        }else{
            break;
        }
        
    }
    SDL_UnlockMutex(queue->mutex);
    
    LOGD("[%s   %d] end\n",__FUNCTION__,__LINE__);
    return 0;
}


//«Â≥˝ ˝æ›≤¢«“œ˙ªŸÀ¯◊ ‘¥
int rt_queue_destroy(RtQueue *queue){
    
    rt_queue_clear(queue);
    
    if(queue->mutex){
        SDL_UnlockMutex(queue->mutex);
        SDL_DestroyMutex(queue->mutex);
        queue->mutex = NULL;
    }
    
    if(queue->cond){
        SDL_DestroyCond(queue->cond);
        queue->cond = NULL;
    }
    return 0;
}


