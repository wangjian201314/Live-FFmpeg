//
//  Rt_video.c
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/17.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#include "Rt_video.h"


int rt_video_init(RT_VIDEO *stRtVideo,enum AVCodecID avCodeID,RT_LIVE_TYPE enRtLiveType,enum AVPixelFormat enAVPixelFormat,AVCodecParameters *par){
    
    stRtVideo->s32DecodeTraffic = 0;
    stRtVideo->s32Fps = 0;
    stRtVideo->s32ReceiveTraffic = 0;
    stRtVideo->s32TotalFramePts = 0;
    stRtVideo->s32VideoStreamIndex = -1;
    stRtVideo->s64CurrentPts = 0;
    stRtVideo->enAVPixelFormat = enAVPixelFormat;
    stRtVideo->s32PixelW = 0;
    stRtVideo->s32PixelH = 0;
    stRtVideo->enLiveType = enRtLiveType;
	stRtVideo->s64FirstStartPts = -1;
	stRtVideo->s64VideoClock = 0;
	stRtVideo->s64FirstVideoTimestamp = -1;
	stRtVideo->s64FrameTimer = 0;
	stRtVideo->s32DisplayTraffic = 0;
	stRtVideo->s8IsFilterBadPacket = 0;
	stRtVideo->s8IsFilterBadFrame = 0;

    
    //尝试缓存的个数，-1：不缓存  ≥0 会尝试缓存指定的值，同时会照成延迟问题
    stRtVideo->s32CacheFrameNum = -1;
    
    rt_video_relase(stRtVideo,RT_GET_DATA_FROME_OTHER);
    
    LOGD("[%s   %d]  avCodeID =%d  AV_CODEC_ID_H264 =%d\n",__FUNCTION__,__LINE__,avCodeID,AV_CODEC_ID_H264);

    stRtVideo->pVideoPacketQueue = (RtQueue*)malloc(sizeof(RtQueue));
    memset(stRtVideo->pVideoPacketQueue, 0, sizeof(RtQueue));
    
    rt_queue_init(stRtVideo->pVideoPacketQueue);
    
    //根据类型查找解码器
    stRtVideo->pVideoCodec = avcodec_find_decoder(avCodeID);
    if(NULL == stRtVideo->pVideoCodec){
        LOGE("[%s   %d] find decoder error\n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    //根据解码器新建一个context
    stRtVideo->pVideoCodecCtx = avcodec_alloc_context3(stRtVideo->pVideoCodec);
    //stRtVideo->pVideoCodecCtx = avcodec_alloc_context3(NULL);
    if(NULL == stRtVideo->pVideoCodecCtx){
        LOGE("[%s   %d] avcodec_alloc_context3 error\n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    if(par){
        //拷贝参数到新建立的pVideoCodecCtx，这个步骤少不了，特别是播放本地视频的时候
        if(avcodec_parameters_to_context(stRtVideo->pVideoCodecCtx,par)<0){
            LOGE("[%s   %d]can't copy decoder context\n",__FUNCTION__,__LINE__);
            goto ERR_EXIT;
        }else{
            LOGE("[%s   %d]copy decoder context success\n",__FUNCTION__,__LINE__);
        }
    }
    
    //打开解码器
    if(avcodec_open2(stRtVideo->pVideoCodecCtx, stRtVideo->pVideoCodec, NULL) < 0){
        LOGE("[%s   %d] avcodec_open2 error\n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    stRtVideo->pDecodePacket = av_packet_alloc();
    
    if(NULL == stRtVideo->pDecodePacket){
        LOGE("[%s   %d] pDecodePacket alloc error\n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    LOGD("[%s   %d] init success\n",__FUNCTION__,__LINE__);
    
    return 0;
    
ERR_EXIT:
    
    LOGE("[%s   %d] error\n",__FUNCTION__,__LINE__);
    if(stRtVideo->pVideoCodecCtx){
        avcodec_free_context(&stRtVideo->pVideoCodecCtx);
        stRtVideo->pVideoCodecCtx = NULL;
    }
    
    return -1;
}


//视频显示，这里没有写任何的显示相关的代码
int rt_video_display(RT_VIDEO *stRtVideo,RT_PICTURE *stRtPicture){
    //显示
    float aspect_ratio;
    
    if(stRtPicture->pDecodeFrame){
        if(stRtVideo->pVideoCodecCtx->sample_aspect_ratio.num == 0){
            aspect_ratio = 0;
        }else{
            aspect_ratio = av_q2d(stRtVideo->pVideoCodecCtx->sample_aspect_ratio)*
            stRtVideo->pVideoCodecCtx->width / stRtVideo->pVideoCodecCtx->height;
        }
        
        if(aspect_ratio <= 0.0){
            aspect_ratio = (float) stRtVideo->pVideoCodecCtx->width / stRtVideo->pVideoCodecCtx->height;
        }
        
        
        return aspect_ratio;
    }
    
    return -1;
}




//视频解码
double rt_video_decode(RT_VIDEO *stRtVideo,char *pDid,AVFrame *pDecodeFrame,int *packetSize){
    
    static int s32MissPacketCount = 0;
    double s64Pts = 0;
    
    if(NULL == stRtVideo){
        LOGE("[%s   %d] stRtVideo == NULL \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    //LOGD("[%s   %d] pDid =%s \n",__FUNCTION__,__LINE__,pDid);

	if(!stRtVideo->pVideoPacketQueue || !stRtVideo->pDecodePacket  || !stRtVideo->pVideoCodecCtx){
		goto ERR_EXIT;
	}
    
    if(stRtVideo->pVideoPacketQueue->nb_packets <=0 )
    {	
    	//方便查看log
        s32MissPacketCount ++;
        if(s32MissPacketCount % 30 == 0 ){
            LOGE("[%s   %d] did = %s packets is 0  miss = %d  \n",__FUNCTION__,__LINE__,pDid,s32MissPacketCount);
		}
        
        goto ERR_EXIT;
        
    }else{
        
        s32MissPacketCount = 0;
        
        int ret = rt_queue_get(stRtVideo->pVideoPacketQueue,stRtVideo->pDecodePacket, 0);
        
        if(ret <=0 ){
            LOGE("[%s   %d] get video packet error \n",__FUNCTION__,__LINE__);
            goto ERR_EXIT;
        }else{
            
            if(stRtVideo->pDecodePacket->data == NULL || stRtVideo->pDecodePacket->size <=0 || !stRtVideo->pVideoCodecCtx){
                LOGE("[%s   %d] decodePacket NULL \n",__FUNCTION__,__LINE__);
                goto ERR_EXIT;
            }
            
            int s32Rec = 0;
            int s32FrameFinished = 1;
            
#if 0
            //旧api的解码方式
            s32Rec = avcodec_decode_video2(stRtVideo->pVideoCodecCtx, pDecodeFrame, &s32FrameFinished, stRtVideo->pDecodePacket);
            if(s32Rec < 0){
                LOGE("[%s   %d] avcodec_decode_video2 error did =%s \n",__FUNCTION__,__LINE__,pDid);
                SDL_Delay(10);
                goto ERR_EXIT;
            }
            
#else
            
            //LOG_PRINT_HEX(stRtVideo->pDecodePacket->data, 0, 40);
            //LOGD("[%s   %d] did = %s  pakcet=%p\n",__FUNCTION__,__LINE__,pDid,stRtVideo->pDecodePacket);
            //LOG_PRINT_HEX(stRtVideo->pDecodePacket->data, 0, 60);

            //新的解码方式
            s32Rec = avcodec_send_packet(stRtVideo->pVideoCodecCtx,stRtVideo->pDecodePacket);
            if(s32Rec != 0){
                LOGE("[%s   %d] avcodec_send_packet error did =%s \n",__FUNCTION__,__LINE__,pDid);
                
                if(stRtVideo->pDecodePacket->size < 60){
                    LOG_PRINT_HEX(stRtVideo->pDecodePacket->data, 0, stRtVideo->pDecodePacket->size);
                }else{
                    LOG_PRINT_HEX(stRtVideo->pDecodePacket->data, 0, 60);
                }
                
                goto ERR_EXIT;
            }
            s32Rec = avcodec_receive_frame(stRtVideo->pVideoCodecCtx,pDecodeFrame);
            if(s32Rec != 0){
                LOGE("[%s   %d] avcodec_receive_frame error did =%s \n",__FUNCTION__,__LINE__,pDid);
                goto ERR_EXIT;
            }
            
#endif
            
			//对每次解码后的宽高进行比较，做到的动态的获取分辨率
			if(stRtVideo->s32PixelW != stRtVideo->pVideoCodecCtx->width
			   || stRtVideo->s32PixelH != stRtVideo->pVideoCodecCtx->height){
				
				int s32PixelW = stRtVideo->pVideoCodecCtx->width;
				int s32PixelH = stRtVideo->pVideoCodecCtx->height;
				stRtVideo->s32PixelW = s32PixelW;
				stRtVideo->s32PixelH = s32PixelH;
				
				RT_RESOLUTION_TYPE resolution = RT_RESOLUTION_640;
				
				if(stRtVideo->s32PixelW ==640){
					resolution = RT_RESOLUTION_640;
				}else if(stRtVideo->s32PixelW == 1280){
					resolution = RT_RESOLUTION_720;
				}else if(stRtVideo->s32PixelW == 1920){
					resolution = RT_RESOLUTION_1080;
				}
				
				//将分辨率回调回去
				if(stRtVideo->funVideoMsgReturnCallBack){
					stRtVideo->funVideoMsgReturnCallBack(stRtVideo->userData,pDid,RT_MSG_TYPE_RESOLUTION,resolution);
				}
				
				if(stRtVideo->stpSwsCtx){
					sws_freeContext(stRtVideo->stpSwsCtx);
					stRtVideo->stpSwsCtx = NULL;
					LOGD("[%s	%d] sws_freeContext \n",__FUNCTION__,__LINE__);
				}
				
				//stRtVideo->pVideoCodecCtx->pix_fmt;
				
				LOGD("[%s	%d] src_fmt =%d  dst_fmt=%d \n",__FUNCTION__,__LINE__,stRtVideo->pVideoCodecCtx->pix_fmt,stRtVideo->enAVPixelFormat);
				
				enum AVPixelFormat pix_fmt;
				switch (stRtVideo->pVideoCodecCtx->pix_fmt) {
					case AV_PIX_FMT_YUVJ420P:
						pix_fmt = AV_PIX_FMT_YUV420P;
						LOGD("[%s	%d] src_fmt = AV_PIX_FMT_YUVJ420P set sws_format to AV_PIX_FMT_YUV420P\n",__FUNCTION__,__LINE__);
						break;
					case AV_PIX_FMT_YUVJ422P:
						pix_fmt = AV_PIX_FMT_YUV422P;
						LOGD("[%s	%d] src_fmt = AV_PIX_FMT_YUVJ422P set sws_format to AV_PIX_FMT_YUV422P\n",__FUNCTION__,__LINE__);
						break;
					case AV_PIX_FMT_YUVJ440P:
						pix_fmt = AV_PIX_FMT_YUV440P;
						LOGD("[%s	%d] src_fmt = AV_PIX_FMT_YUVJ440P set sws_format to AV_PIX_FMT_YUV440P\n",__FUNCTION__,__LINE__);
						break;
					case AV_PIX_FMT_YUVJ444P:
						pix_fmt = AV_PIX_FMT_YUV444P;
						LOGD("[%s	%d] src_fmt = AV_PIX_FMT_YUVJ444P set sws_format to AV_PIX_FMT_YUV444P\n",__FUNCTION__,__LINE__);
						break;
					default:
						pix_fmt =stRtVideo->pVideoCodecCtx->pix_fmt;
						break;
				}
				stRtVideo->stpSwsCtx = sws_getContext(s32PixelW,s32PixelH,
													  pix_fmt,
													  s32PixelW, s32PixelH,
													  stRtVideo->enAVPixelFormat,
													  SWS_FAST_BILINEAR,
													  NULL, NULL, NULL);
				
				
				LOGD("[%s	%d] width = %d height =%d \n",
					 __FUNCTION__,__LINE__,s32PixelW,s32PixelH);
				
				//出图回调
				if(stRtVideo->funVideoMsgReturnCallBack){
					stRtVideo->funVideoMsgReturnCallBack(stRtVideo->userData,pDid,RT_MSG_TYPE_SHOW,1);
				}
				
			}
            
            if(s32FrameFinished){
                
                s64Pts = av_frame_get_best_effort_timestamp(pDecodeFrame);
                
                if(s64Pts == AV_NOPTS_VALUE){
                    s64Pts = 0.0;
                }
				
                if(stRtVideo->pVideoStream){
					s64Pts *= av_q2d(stRtVideo->pVideoStream->time_base);
				}else{
					//pVideoStream->time_base 其实默认就是1/90000
					s64Pts *= av_q2d((AVRational){1, 90000});
				}

				//LOGD("[%s   %d] s64Pts= %f\n",__FUNCTION__,__LINE__,s64Pts);
				
                if(s64Pts != 0){
                    stRtVideo->s64VideoClock = s64Pts;
                }else{
                	//当获取不到正确的pts时候，将会上一帧预测好的值作为pts
                    s64Pts = stRtVideo->s64VideoClock;
                }
                
               	
				/*
				pVideoCodecCtx->time_base = 1/ost->frame_rate
				(即 １/fps ，比如25帧的时候，那就是1/25)
				*/
				double s64FrameDelay;
                s64FrameDelay = av_q2d(stRtVideo->pVideoCodecCtx->time_base);
				if(s64FrameDelay == 0){
					if(stRtVideo->s32Fps != 0){
						s64FrameDelay = av_q2d((AVRational){1, stRtVideo->s32Fps});
					}else if(stRtVideo->s32CountFps !=0 ){
						//如果外部设置的fps为0，则使用内部统计的fps作为计算的值
						s64FrameDelay = av_q2d((AVRational){1, stRtVideo->s32CountFps});
					}else{

						/*
						本地文件通过这样的方式获取
						*/
						if(stRtVideo->pVideoStream){
							
							AVStream *stream=stRtVideo->pVideoStream;
							
							if(stream->avg_frame_rate.den != 0){
								int frame_rate=stream->avg_frame_rate.num/stream->avg_frame_rate.den;//每秒多少帧  
								s64FrameDelay = av_q2d((AVRational){1, frame_rate});
								//LOGD("[%s   %d] s64FrameDelay= %f frame_rate=%d\n",__FUNCTION__,__LINE__,s64FrameDelay,frame_rate);
							}else{
								//LOGD("[%s   %d] stream->avg_frame_rate.den == 0\n",__FUNCTION__,__LINE__);
							}
						}
					}
				}
				
				/*
				延迟的时间计算方式为extra_delay = repeat_pict / (2*fps) = repeat_pict * 0.5 *(1/fps)
				repeat_pict :pDecodeFrame->repeat_pict
				(1/fps):av_q2d(stRtVideo->pVideoCodecCtx->time_base)
				所以才有了下面的计算方式
				*/
                s64FrameDelay += pDecodeFrame->repeat_pict *(s64FrameDelay * 0.5);

				
                /*
                为了让pts从0开始计算，这里我做了如下处理
                */
                if(stRtVideo->s64FirstStartPts == -1){
                    stRtVideo->s64FirstStartPts = stRtVideo->s64VideoClock;
                }
                stRtVideo->s64VideoClock = stRtVideo->s64VideoClock - stRtVideo->s64FirstStartPts;

				
                /*
                该帧在视频中的时间位置(秒为单位)，
                这个就是下一帧要显示的位置，即预测帧
				*/
                stRtVideo->s64VideoClock += s64FrameDelay;

				//LOGD("[%s   %d] s64VideoClock= %f\n",__FUNCTION__,__LINE__,stRtVideo->s64VideoClock);

				/*
				保存解码后好的数据的长度
				*/
				*packetSize = stRtVideo->pDecodePacket->size;

				//记录解码后的数据长度
				stRtVideo->s32DecodeTraffic+=stRtVideo->pDecodePacket->size;
                av_packet_unref(stRtVideo->pDecodePacket);
                
            }else{
                LOGE("[%s   %d] decode faile \n",__FUNCTION__,__LINE__);
                goto ERR_EXIT;
            }
            
        }
        
    }
    
    
    return s64Pts;
    
ERR_EXIT:
    //SDL_Delay(10);
    if(stRtVideo->pDecodePacket){
    	//解码后要释放资源
    	av_packet_unref(stRtVideo->pDecodePacket);
    }

	*packetSize = 0;
	
    return -1;
}

int rt_video_relase(RT_VIDEO *stRtVideo,RT_GET_DATA_TYPE getDataType){
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    //NOSUPPORT_S("\n");
    if(stRtVideo){
        
        if(NULL != stRtVideo->pVideoPacketQueue){
            rt_queue_destroy(stRtVideo->pVideoPacketQueue);
            free(stRtVideo->pVideoPacketQueue);
            stRtVideo->pVideoPacketQueue = NULL;
        }
        
        if(NULL != stRtVideo->stpSwsCtx){
            sws_freeContext(stRtVideo->stpSwsCtx);
            stRtVideo->stpSwsCtx = NULL;
            LOGD("[%s   %d] free stpSwsCtx success \n",__FUNCTION__,__LINE__);
        }
        
        if(NULL != stRtVideo->pVideoCodecCtx){
            
            //这里需要注意一点，只有数据来源于其它才关闭，要不回avformat_close_input回出错
            avcodec_free_context(&stRtVideo->pVideoCodecCtx);
            stRtVideo->pVideoCodecCtx = NULL;
            LOGD("[%s   %d] free pVideoCodecCtx success \n",__FUNCTION__,__LINE__);
            
        }
        
        if(NULL != stRtVideo->pDecodePacket){
            //av_packet_unref(stRtVideo->pDecodePacket);
            av_packet_free(&stRtVideo->pDecodePacket);
            stRtVideo->pDecodePacket = NULL;
            LOGD("[%s   %d] free pDecodePacket success \n",__FUNCTION__,__LINE__);
        }
    }else{
        LOGE("[%s   %d] stRtVideo is NULL\n",__FUNCTION__,__LINE__);
    }
    
    return 0;
}

