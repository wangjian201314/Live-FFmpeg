//
//  Rt_pub_def.c
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/16.
//  Copyright © 2017年 杨青远. All rights reserved.
//

/*
 * 整个视频播放，对外部提供的接口，外部所有对视频的操作都是通过这里的接口进行操作
 */

#include "Rt_audio.h"
#include "Rt_video.h"
#include "Rt_stream_in.h"
#include "Rt_stream_out.h"
#include "Rt_pub_def.h"


/*
全局变量，所以的操作其实都是对这个进行操作
*/
static RT_PLAYER gs_stRtPlayer;

/*
标志是否开启了事件监听的线程
*/
static int gs_s32StartEventListenerTag = 0;

/*
标志是否开启了SDL音频回调
*/
static int gs_s32StartSDLAudioCallBackTag = 0;

/*
初始化的模块记录
*/
static Uint8 gs_SubsystemRefCount[ 32 ];


static void ffmepgLogoutPut(void*ptr , int level, const char *fmt,va_list vl){
    
#if 0
    
    if(strstr(fmt,"missed")||
       strstr(fmt,"concealing")||
       strstr(fmt,"Invalid")||
       strstr(fmt,"dquant")||
       strstr(fmt,"corrupted")||
       strstr(fmt,"negative")||
       strstr(fmt,"mb_type")||
       strstr(fmt,"cbp too large")||
       strstr(fmt,"Cannot use previous")||
       strstr(fmt,"Cannot use next picture")||
       strstr(fmt,"out of range intra")||
       strstr(fmt,"top block unavailable")||
       strstr(fmt,"left block unavailable")||
       strstr(fmt,"Using")||
       strstr(fmt,"unknown SEI")||
       strstr(fmt,"error while decoding"))
    {
        
        LOGE(fmt, vl);
        
    }
    
#else
    if(!strstr(fmt,"nal_unit_type") && !strstr(fmt,"ret")){
        //LOGD("[%s   %d] ffmpeg log start \n",__FUNCTION__,__LINE__);
        if(level == AV_LOG_WARNING){
            LOGW_FFMPEG(fmt,vl);
        }else if(level == AV_LOG_DEBUG){
            LOGD_FFMPEG(fmt, vl);
        }else if(level == AV_LOG_FATAL){
            LOGI_FFMPEG(fmt, vl);
        }else if(level == AV_LOG_ERROR){
            LOGE_FFMPEG(fmt, vl);
            //printf(fmt,vl);
        }
        //LOGD("[%s   %d] ffmpeg log end \n",__FUNCTION__,__LINE__);
    }
    
#endif
    
    
    
}

static RT_IPCAM_INFO* getIpcamInfoByDid(RT_PLAYER *pstRtplayer,const char *pDid){
    
    
    //查找可以用的相机
    int i = RT_MAX_IPCAM_SIZE-1;
    int index = -1;
    for(i = RT_MAX_IPCAM_SIZE-1 ; i >= 0 ; i--){
        if(pstRtplayer->stRtIpcamInfo[i].stRtParams){
            if(strstr(pstRtplayer->stRtIpcamInfo[i].stRtParams->acDid,pDid)){
                //LOGD("[%s   %d]  ipcam is find success \n",__FUNCTION__,__LINE__);
                index = i;
                break;
            }
        }
    }
    
    //LOGD("[%s   %d]  index = %d \n",__FUNCTION__,__LINE__,index);
    
    if(index != -1){
        RT_IPCAM_INFO *stRtIpcamInfo = &pstRtplayer->stRtIpcamInfo[index];
        return stRtIpcamInfo;
    }else{
        LOGE("[%s   %d] faile  index = %d \n",__FUNCTION__,__LINE__,index);
        
        //如果查找失败，打印存储的数组里面的值，方便定位问题
        for(i = RT_MAX_IPCAM_SIZE-1 ; i >= 0 ; i--){
            if(pstRtplayer->stRtIpcamInfo[i].stRtParams){
                    LOGE("[%s   %d]  index =%d  acDid=%s  srcpDid =%s \n",
                         __FUNCTION__,__LINE__,i,
                         pstRtplayer->stRtIpcamInfo[i].stRtParams->acDid,pDid);
            }else{
                LOGE("[%s    %d] pstRtplayer->stRtIpcamInfo[%d].stRtParams is NULL\n",__FUNCTION__,__LINE__,i);
            }
        }
        
        
        return NULL;
    }
    
}


//解析aac一帧数据
static int getADTSFrame(unsigned char *buffer,int buf_size,unsigned char * data,int *data_size,int *offSet){
	
    int size = 0;
    
    if(!buffer || !data || !data_size){
        LOGE("[%s   %d] !buffer || !data || !data_size \n",__FUNCTION__,__LINE__);
        return -1;
    }

	
	int readCount = 0;
    while (1) {
        if(buf_size<7){
            LOGE("[%s   %d] buf_size =%d <7 \n",__FUNCTION__,__LINE__,buf_size);
            return -1;
        }
        
        if(readCount >= 1){
            LOGD("[%s   %d] readCount =%d\n",__FUNCTION__,__LINE__,readCount);
            LOG_PRINT_HEX(buffer, 0, 7);
        }
        if((buffer[0] == 0xff) && ((buffer[1] & 0xf0) == 0xf0)){
            size |= ((buffer[3] & 0x03) << 11); //high 2 bit
            size |= buffer[4] <<3;              //middle 8 bit
            size |= ((buffer[5] & 0xe0) >> 5);  //low 3 bit
            break;
        }
        readCount ++;
        *offSet = readCount;
        
        --buf_size;
        ++buffer;
    }
    
    if(buf_size < size){
        return 1;
    }
    
    if(size > RT_MAX_AAC_FRAME_SIZE){
        *data_size = size;
        LOGE("[%s   %d] size =%d > maxSize =%d \n",__FUNCTION__,__LINE__,size,RT_MAX_AAC_FRAME_SIZE);
        return 2;
    }
    memcpy(data, buffer, size);
    *data_size = size;
    
    return 0;
}


//释放所有的资源
static int relaseRtPlayer(RT_PLAYER *pstRtplayer){
    
    LOGD("[%s    %d] \n",__FUNCTION__,__LINE__);
    
    //释放资源
    int i = RT_MAX_IPCAM_SIZE-1;
    for(i = RT_MAX_IPCAM_SIZE-1 ; i >= 0 ; i--){
        
        RT_IPCAM_INFO *stRtIpcamInfo = &pstRtplayer->stRtIpcamInfo[i];
        
        
        if(stRtIpcamInfo->stRtParams){
            LOGD("[%s   %d] ---------------index =%d------------------\n",__FUNCTION__,__LINE__,i);
            LOGD("[%s    %d] start relase uid =%s  \n",
             __FUNCTION__,__LINE__,
                 stRtIpcamInfo->stRtParams->acDid);
        }
        
        //释放输入流
        if(stRtIpcamInfo->stRtStreamIn){
            rt_stream_in_relase(stRtIpcamInfo->stRtStreamIn);
            free(stRtIpcamInfo->stRtStreamIn);
            stRtIpcamInfo->stRtStreamIn = NULL;
        }
        
        //释放输出流
        if(stRtIpcamInfo->stRtStreamOut){
            rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
            free(stRtIpcamInfo->stRtStreamOut);
            stRtIpcamInfo->stRtStreamOut = NULL;
        }
        
        //释放视频
        if(stRtIpcamInfo->stRtVideo){
            rt_video_relase(stRtIpcamInfo->stRtVideo,pstRtplayer->enGetDataType);
            free(stRtIpcamInfo->stRtVideo);
            stRtIpcamInfo->stRtVideo = NULL;
        }
        
        //释放音频
        if(stRtIpcamInfo->stRtAudio){
            rt_audio_relase(stRtIpcamInfo->stRtAudio);
            free(stRtIpcamInfo->stRtAudio);
            stRtIpcamInfo->stRtAudio = NULL;
        }
        
        //释放参数结构体
        if(stRtIpcamInfo->stRtParams){
            memset(stRtIpcamInfo->stRtParams->acDid,0,sizeof(stRtIpcamInfo->stRtParams->acDid));
			if(stRtIpcamInfo->stRtParams->stRtParmasExtra){
				free(stRtIpcamInfo->stRtParams->stRtParmasExtra);
				stRtIpcamInfo->stRtParams->stRtParmasExtra = NULL;
				LOGD("[%s   %d] free stRtParmasExtra success\n",__FUNCTION__,__LINE__);
			}
            free(stRtIpcamInfo->stRtParams);
            stRtIpcamInfo->stRtParams = NULL;
            LOGD("[%s   %d] free stRtParams success\n",__FUNCTION__,__LINE__);
        }
        
        memset(stRtIpcamInfo, 0, sizeof(RT_IPCAM_INFO));
        
    }
    
    LOGD("[%s   %d] -----------------end---------------------\n",__FUNCTION__,__LINE__);
    if(pstRtplayer->pVideoDecodeFrame){
        av_frame_free(&pstRtplayer->pVideoDecodeFrame);
        pstRtplayer->pVideoDecodeFrame = NULL;
        LOGD("[%s   %d] pDecodeFrame free \n",__FUNCTION__,__LINE__);
    }
    
    if(pstRtplayer->pSDLCond){
        SDL_CondSignal(pstRtplayer->pSDLCond);
        SDL_DestroyCond(pstRtplayer->pSDLCond);
        pstRtplayer->pSDLCond = NULL;
        LOGD("[%s   %d] pSDLCond free \n",__FUNCTION__,__LINE__);
    }
    
    if(pstRtplayer->pSDLMutex){
        SDL_UnlockMutex(pstRtplayer->pSDLMutex);
        SDL_DestroyMutex(pstRtplayer->pSDLMutex);
        pstRtplayer->pSDLMutex = NULL;
        LOGD("[%s   %d] pSDLMutex free \n",__FUNCTION__,__LINE__);
    }
    
    if(pstRtplayer->pPcmBuf){
        free(pstRtplayer->pPcmBuf);
        pstRtplayer->pPcmBuf = NULL;
        LOGD("[%s   %d] pPcmBuf free \n",__FUNCTION__,__LINE__);
    }
    
    if(pstRtplayer->pPcmTempBuf){
        pstRtplayer->pPcmTempBuf = NULL;
        LOGD("[%s   %d] pPcmTempBuf free \n",__FUNCTION__,__LINE__);
    }
    
    i = 0;
    for(i =0 ; i< RT_VIDEO_PICTURE_QUEUE_SIZE ;i ++){
        RT_PICTURE *stRtPicture = &pstRtplayer->stRtPictures[i];
		if(stRtPicture->pBuffer){
			av_free(stRtPicture->pBuffer);
			stRtPicture->pBuffer = NULL;
			LOGD("[%s   %d] free stRtPicture->pBuffer success\n",__FUNCTION__,__LINE__);
		}
		
        if(stRtPicture->pDecodeFrame){
            
            //av_free((stRtPicture->pDecodeFrame));
            av_frame_unref(stRtPicture->pDecodeFrame);
            av_frame_free(&stRtPicture->pDecodeFrame);
            stRtPicture->pDecodeFrame = NULL;
            LOGD("[%s   %d] free RT_PICTURE success index = %d \n",__FUNCTION__,__LINE__,i);
        }
        memset(stRtPicture->acDid, 0, sizeof(stRtPicture->acDid));
    }
    
    av_lockmgr_register(NULL);
    avformat_network_deinit();
    
    return 0;
}

static double getVideoClock(RT_VIDEO *stRtVideo){
	double delta;
	delta = (av_gettime() - stRtVideo->s64CurrentPtsTime) / 1000000.0;
	return stRtVideo->s64CurrentPts + delta;
}

static double getAudioClock(RT_PLAYER *pstRtplayer,RT_AUDIO *stRtAudio){
	double pts;
	int hw_buf_size, bytes_per_sec, n;
	pts = stRtAudio->s64AudioClock; /* maintained in the audio thread */
	hw_buf_size = pstRtplayer->u32PcmBufSize - pstRtplayer->u32PcmBufIndex;
	bytes_per_sec = 0;
	
	if(stRtAudio && stRtAudio->pAudioCodecCtx) {
		n = stRtAudio->pAudioCodecCtx->channels * 2;

		//一秒要播放的字节数
		bytes_per_sec = stRtAudio->pAudioCodecCtx->sample_rate * n;
	}
	if(bytes_per_sec) {
		//减去还没有播放的字节
		pts -= (double)hw_buf_size / bytes_per_sec;
	}
	return pts;
}

static double getExternalClock(){
	//同步到外部时钟
	return av_gettime() / 1000000.0;
}

//获取要匹配的时钟类型
static double getMasterClock(RT_PLAYER *pstRtplayer,RT_IPCAM_INFO *stRtIpcamInfo) {
	
	if(stRtIpcamInfo->enRtAvSyncType== RT_AV_SYNC_VIDEO_MASTER) {
		//音频同步到视频
		return getVideoClock(stRtIpcamInfo->stRtVideo);
	} else if(stRtIpcamInfo->enRtAvSyncType == RT_AV_SYNC_AUDIO_MASTER) {
		return getAudioClock(pstRtplayer,stRtIpcamInfo->stRtAudio);
	} else {
		//同步到外部时钟
		return getExternalClock();
	}
}


//这个方法要写的有点复杂，主要是注意两点
//1.pFilePath 参数可以为null，如果为null，则注意一些参数的初始化，比如说【视频，音频】
//2.pFilePath 参数不为null，则说明是使用ffmpeg的方式获取数据流，对应的一些参数是不会再这里初始化的
//会在Rt_stream_in里面再初始化【音频和视频】
static int addIpcam(int *pPlayerHandle,const char *pFilePath,RT_PARAMS *stRtParams){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    if(stRtParams == NULL){
        LOGE("[%s   %d] stRtParams is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = NULL;
    pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    
    //查找可以用的相机
    int i = 0;
    int index = -1;
    char isReadAdd = 0;
    for(i = 0 ; i < RT_MAX_IPCAM_SIZE ; i++){
        if(pstRtplayer->stRtIpcamInfo[i].stRtParams &&
           strstr(pstRtplayer->stRtIpcamInfo[i].stRtParams->acDid,stRtParams->acDid)){
            LOGD("[%s   %d] ipcam is ready add \n",__FUNCTION__,__LINE__);
            index = i;
            isReadAdd = 1;
            break;
        }
        if(NULL == pstRtplayer->stRtIpcamInfo[i].stRtVideo){
            index = i;
        }
    }
    
    //如果已经添加
    if(isReadAdd){
        return -1;
    }
    
    //如果找不到没有使用的ipc，说明添加的ipc已经满了
    if(index == -1){
        LOGE("[%s   %d] ipcam array is full \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_IPCAM_INFO *stRtIpcamInfo = &(pstRtplayer->stRtIpcamInfo[index]);
    //释放之前的资源，安全做法
    if(stRtIpcamInfo->stRtParams){
		if(stRtIpcamInfo->stRtParams->stRtParmasExtra){
			free(stRtIpcamInfo->stRtParams->stRtParmasExtra);
			stRtIpcamInfo->stRtParams->stRtParmasExtra = NULL;
		}
        free(stRtIpcamInfo->stRtParams);
        stRtIpcamInfo->stRtParams = NULL;
    }
    memset(stRtIpcamInfo,0,sizeof(RT_IPCAM_INFO));

	//将stRtIpcamInfo->stRtParams指针赋值
	stRtIpcamInfo->stRtParams = stRtParams;

	if(NULL != stRtParams->stRtParmasExtra){
		stRtIpcamInfo->enRtAvSyncType = stRtParams->stRtParmasExtra->enRtAvSyncType;
	}else{
		//默认以音频为主的同步方式
		stRtIpcamInfo->enRtAvSyncType = RT_AV_SYNC_AUDIO_MASTER;
	}
    
    LOGD("[%s   %d]  index = %d   pDid = %s  enRtAvSyncType=%d\n",
         __FUNCTION__,
         __LINE__,
         index,
         stRtIpcamInfo->stRtParams->acDid,
         stRtIpcamInfo->enRtAvSyncType);
    
    /********新建RtVideo*********/
    if(NULL != stRtIpcamInfo->stRtVideo){
        LOGD("[%s   %d] stRtIpcamInfo->stRtVideo != NULL \n",__FUNCTION__,__LINE__);
        rt_video_relase(stRtIpcamInfo->stRtVideo,pstRtplayer->enGetDataType);
        free(stRtIpcamInfo->stRtVideo);
        stRtIpcamInfo->stRtVideo = NULL;
    }
    stRtIpcamInfo->stRtVideo = (RT_VIDEO *)malloc(sizeof(RT_VIDEO));
    memset(stRtIpcamInfo->stRtVideo, 0, sizeof(RT_VIDEO));
    if(NULL == stRtIpcamInfo->stRtVideo){
         LOGE("[%s   %d] (RT_VIDEO *)malloc faile \n",__FUNCTION__,__LINE__);
         goto ERR_EXIT;
    }
    //设置回调
    stRtIpcamInfo->stRtVideo->funVideoMsgReturnCallBack = stRtParams->funVideoMsgReturnCallBack;
	stRtIpcamInfo->stRtVideo->userData = stRtParams->userData;
	stRtIpcamInfo->stRtVideo->s32Fps = stRtParams->s32Fps;
    
    
    /*********如果支持音频*******/
    if(stRtParams->enRtOpenAudioState == RT_AUDIO_ENABLE){
        //释放上一次没有释放的资源
        if(NULL != stRtIpcamInfo->stRtAudio){
            LOGD("[%s   %d] stRtIpcamInfo->stRtVideo != NULL \n",__FUNCTION__,__LINE__);
            rt_audio_relase(stRtIpcamInfo->stRtAudio);
            free(stRtIpcamInfo->stRtAudio);
            stRtIpcamInfo->stRtAudio = NULL;
        }
        //新建RtAudio
        stRtIpcamInfo->stRtAudio = (RT_AUDIO *)malloc(sizeof(RT_AUDIO));
        memset(stRtIpcamInfo->stRtAudio, 0, sizeof(RT_AUDIO));
        if(NULL == stRtIpcamInfo->stRtAudio){
            LOGE("[%s   %d] (RT_AUDIO *)malloc faile \n",__FUNCTION__,__LINE__);
            goto ERR_EXIT;
        }
        LOGD("[%s   %d] malloc stRtAudio success \n",__FUNCTION__,__LINE__);
        //memset(stRtIpcamInfo->stRtAudio->acDid, 0, sizeof(stRtIpcamInfo->stRtAudio->acDid));
        //strcpy(stRtIpcamInfo->stRtAudio->acDid, stRtParams->acDid);
        
        //设置回调
        stRtIpcamInfo->stRtAudio->funVideoMsgReturnCallBack = stRtParams->funVideoMsgReturnCallBack;
        stRtIpcamInfo->stRtAudio->userData = stRtParams->userData;
		
       
    }

	 /********初始化RTStreamIn*********/
    if(pstRtplayer->enGetDataType == RT_GET_DATA_FROME_FFMPEG ){
        
        //如果传人的文件路径不为null，这里说明播放为调用ffmpeg的方式获取视频流，则需要初始化输入流的结构体
        if( NULL != pFilePath ){
            
            //释放上一次没有释放的资源
            if(NULL != stRtIpcamInfo->stRtStreamIn){
                LOGD("[%s   %d] stRtIpcamInfo->stRtStreamIn != NULL \n",__FUNCTION__,__LINE__);
                rt_stream_in_relase(stRtIpcamInfo->stRtStreamIn);
                free(stRtIpcamInfo->stRtStreamIn);
                stRtIpcamInfo->stRtStreamIn = NULL;
            }
            //重新初始化
            stRtIpcamInfo->stRtStreamIn = (RT_STRAM_IN *)malloc(sizeof(RT_STRAM_IN));
            memset(stRtIpcamInfo->stRtStreamIn,0,sizeof(RT_STRAM_IN));
            if(NULL == stRtIpcamInfo->stRtStreamIn){
				 LOGE("[%s   %d] (RT_STRAM_IN *)malloc error \n",__FUNCTION__,__LINE__);
                 goto ERR_EXIT;
            }
            int rec = rt_stream_in_init(stRtIpcamInfo,pFilePath);
            
            if(rec == -1){
                goto ERR_EXIT;
            }
            
            //设置回调
            stRtIpcamInfo->stRtStreamIn->funVideoMsgReturnCallBack = stRtParams->funVideoMsgReturnCallBack;
			stRtIpcamInfo->stRtStreamIn->userData = stRtParams->userData;
            
            LOGD("[%s   %d] rt_stream_in_init success pFilePath = %s socketType = %d \n",
                 __FUNCTION__,__LINE__,
                 stRtIpcamInfo->stRtStreamIn->acRtspPath,
                 stRtIpcamInfo->stRtStreamIn->enSocketModel);
			
        }else{
            LOGE("[%s   %d] get data frome ffmpeg but path is NULL \n",__FUNCTION__,__LINE__);
            goto ERR_EXIT;
        }
    }else{
		
		//如果数据源来自其它，则初始化数据，如果不是，则会由stream_in再初始化
		int rec = rt_video_init(stRtIpcamInfo->stRtVideo,stRtParams->avCodecID,
								stRtParams->enRtLiveType,stRtParams->enAVPixelFormat,NULL);
		if(stRtParams->stRtParmasExtra){
			stRtIpcamInfo->stRtVideo->s32CacheFrameNum = stRtParams->stRtParmasExtra->s32CacheFrameNum;
			LOGD("[%s   %d] s32CacheFrameNum set to %d\n",__FUNCTION__,__LINE__,stRtIpcamInfo->stRtVideo->s32CacheFrameNum);
		}
		if(rec == -1){
			goto ERR_EXIT;
		}
		LOGD("[%s	%d] rt_video_init success \n ",__FUNCTION__,__LINE__);
		

		if(stRtParams->enRtOpenAudioState == RT_AUDIO_ENABLE){
			 //如果数据源来自其它，则初始化数据
	        if(pstRtplayer->enGetDataType == RT_GET_DATA_FROME_OTHER){
				
				int rec = rt_audio_init(stRtIpcamInfo->stRtAudio,AV_CODEC_ID_AAC,NULL);//默认是aac的音频格式
				
	            if(rec == -1){
	                //goto ERR_EXIT;
	                rt_audio_relase(stRtIpcamInfo->stRtAudio);
	                free(stRtIpcamInfo->stRtAudio);
	                stRtIpcamInfo->stRtAudio = NULL;
	                
	                LOGD("[%s   %d] rt_audio_init faile \n",__FUNCTION__,__LINE__);
	            }
				
				
				if(stRtParams->enRtAudioType == RT_AUDIO_TYPE_PCM){
					int s32Channel = stRtParams->stRtAudioParams.s32Channel;
					int s32Sample_rate = stRtParams->stRtAudioParams.s32Sample_rate;
					int s32Profile = stRtParams->stRtAudioParams.s32Profile;

					//根据采样率，信道等信息确认pcm要转为aac所需要的buf长度(即多长的pcm数据可以转成一帧aac，用来存储mp4)
					stRtIpcamInfo->stRtAudio->s32PcmToAacSize = av_samples_get_buffer_size(NULL,s32Channel,1024,AV_SAMPLE_FMT_S16,1);
					
					LOGD("[%s	%d] s32Channel=%d s32Profile=%d s32Sample_rate=%d s32PcmToAacSize=%d\n",__FUNCTION__,__LINE__,s32Channel,s32Profile,s32Sample_rate,stRtIpcamInfo->stRtAudio->s32PcmToAacSize);	
				}
				
				//stRtIpcamInfo->stRtAudio->stRtAudioParams 初始化
				stRtIpcamInfo->stRtAudio->stRtAudioParams = &(stRtParams->stRtAudioParams);
				stRtIpcamInfo->stRtAudio->enRtAudioType = stRtParams->enRtAudioType;
				LOGD("[%s   %d] rt_audio_init success audio = %s\n ",__FUNCTION__,__LINE__,stRtParams->enRtAudioType == RT_AUDIO_TYPE_PCM ? "pcm" : "aac");
	        }
		}

	}
	
    
    //记录总共使用的ipc个数
    SDL_LockMutex(pstRtplayer->pSDLMutex);
    pstRtplayer->s32UseIpcams ++;
    SDL_UnlockMutex(pstRtplayer->pSDLMutex);
    
    LOGD("[%s   %d] add ipcam success \n",__FUNCTION__,__LINE__);
    
    return 0;
    
ERR_EXIT:
    
    LOGE("[%s    %d] error \n",__FUNCTION__,__LINE__);
    if(stRtIpcamInfo->stRtParams){
        memset(stRtIpcamInfo->stRtParams->acDid,0,sizeof(stRtIpcamInfo->stRtParams->acDid));
		if(stRtIpcamInfo->stRtParams->stRtParmasExtra){
			free(stRtIpcamInfo->stRtParams->stRtParmasExtra);
			stRtIpcamInfo->stRtParams->stRtParmasExtra = NULL;
		}
        free(stRtIpcamInfo->stRtParams);
        stRtIpcamInfo->stRtParams = NULL;
    }
    
    if(stRtIpcamInfo->stRtStreamIn){
        rt_stream_in_relase(stRtIpcamInfo->stRtStreamIn);
        free(stRtIpcamInfo->stRtStreamIn);
        stRtIpcamInfo->stRtStreamIn = NULL;
    }
    
    if(stRtIpcamInfo->stRtVideo){
        rt_video_relase(stRtIpcamInfo->stRtVideo,pstRtplayer->enGetDataType);
        free(stRtIpcamInfo->stRtVideo);
        stRtIpcamInfo->stRtVideo = NULL;
    }
    
    if(stRtIpcamInfo->stRtAudio){
        rt_audio_relase(stRtIpcamInfo->stRtAudio);
        free(stRtIpcamInfo->stRtAudio);
        stRtIpcamInfo->stRtAudio = NULL;
    }
    
    if(stRtIpcamInfo->stRtStreamOut){
        rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
        free(stRtIpcamInfo->stRtStreamOut);
        stRtIpcamInfo->stRtStreamOut = NULL;
    }
    
    return -1;
}





//发送刷新事件
static Uint32 video_refreshEventWork(Uint32 interval,void *opaque){
    
     SDL_Event event;
     event.type = RT_EVNET_REFRESH;
     event.user.data1 = opaque;
     SDL_PushEvent(&event);
     return 0;
 }
 
 //计算暂停时间
 static int video_sendRefreshEvent(int userIpcam,RT_VIDEO *stRtVideo,int delay,RT_LIVE_TYPE liveType,const char*pDid){
     
     //LOGD("[%s   %d] delay = %d \n",__FUNCTION__,__LINE__,delay);
     
     //如果是直播
     if(liveType == RT_LIVE_TYPE_LIVE){

		
#ifdef RT_DRONE
		//如果是飞控的话，默认最小是 8帧
         if(delay>120){
	         LOGD("[%s   %d] delay = %d > 120 and set to 70ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 70;
	     }else if(delay < 20){
	         LOGD("[%s   %d] delay = %d <20 and set to 20ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 20;
	     }
#else
		 //如果是ipc的话，默认最小是 5帧，有可能是晚上降帧
		 if(delay>200){
	         LOGD("[%s   %d] delay = %d > 200 and set to 70ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 70;
	     }else if(delay < 20){
	         LOGD("[%s   %d] delay = %d <20 and set to 20ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 20;
	     }
		 
#endif
		
         if(stRtVideo->s32CacheFrameNum >= 0){
         
             if(stRtVideo->pVideoPacketQueue->nb_packets > stRtVideo->s32CacheFrameNum)
             {
             	 
                 delay = delay -20;
                 
                 if(delay < 0){
                     delay = 0;
                 }


#ifdef RT_DRONE

				 
				 //缓存包打印10，有可能是异常情况了，为了不延迟，就尽可能的快放
				 if(stRtVideo->pVideoPacketQueue->nb_packets > 10){
					delay = 0;
					//LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
				 }

#endif
				 //这里为了避免过多的打印，每隔20次打印一次
				 static int temp = 0;
				 temp ++;
				 if(temp % 20 ==0){
	                 LOGW("[%s   %d] nb_packets = %d > cacheFrameNum =%d  did = %s set do delay = %d\n",
	                 __FUNCTION__,
	                 __LINE__,
	                 stRtVideo->pVideoPacketQueue->nb_packets,
	                 stRtVideo->s32CacheFrameNum,pDid,delay);
				 }

				 
             }
             else if(stRtVideo->pVideoPacketQueue->nb_packets <= 0)
             {
                 delay = delay+20;
             }
             
         }else{
             //如果缓存的个数设置小于0，则将暂停的时间设置为5，进可能快的去播放，几乎是实时播放
             delay = 5;
             SDL_FlushEvent(RT_EVNET_REFRESH);
         }
     
         //如果缓存队列过大，加快播放
         if(stRtVideo->pVideoPacketQueue->nb_packets > 20){
             delay = 5;
             SDL_FlushEvent(RT_EVNET_REFRESH);
         }
 
     }else{
     	//如果不是直播
		if(delay>110){
	         LOGD("[%s   %d] delay = %d and set to 110ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 110;
	     }else if(delay < 10){
	         LOGD("[%s   %d] delay = %d and set to 10 ms\n",__FUNCTION__,__LINE__,delay);
	         delay = 10;
	     }
		 
	 }
     
     //如果当前播放的ipc个数大于2，为了减少延迟，就不做定时播放
     if(userIpcam > 2){
         delay = 0;
     }
     
     //定时后发送执行
     SDL_AddTimer(delay, video_refreshEventWork, stRtVideo);
     
     return 0;
}




//显示任务
static int video_displayWork(RT_PLAYER *pstRtplayer,int userIpcms,RT_IPCAM_INFO *stRtIpcamInfo,RT_PICTURE *stRtPicture){

	RT_AUDIO *stRtAudio = stRtIpcamInfo->stRtAudio;
	RT_VIDEO *stRtVideo = stRtIpcamInfo->stRtVideo;
	RT_PARAMS *stRtParams = stRtIpcamInfo->stRtParams;
	
	
    double actualDelay,delay,syncThreshold,diff,refClock = 0.0;

	stRtVideo->s64CurrentPts = stRtPicture->s64Pts;
	stRtVideo->s64CurrentPtsTime = av_gettime();
	
    //计算前后帧的pts差，改值将会用于做为定时的值
    delay = stRtPicture->s64Pts - stRtVideo->s64FrameLastPts;
	
	
    if(delay <=0){
        delay = stRtVideo->s64FrameLastDelay;
    }
    
    //如果差值大于1说明设备端返回的时候不是按照ffmpeg的标准来计算
    //比如说差值为40(ms)，这里的时间其实就是真正的时间间隔了，需要换算一下
    if(delay >= 1.0){
		
		//方便查看log
		static int count = 0;
		count++;
		if(count % 30 ==0){
			LOGD("[%s   %d] delay =%f > 1.0 \n",__FUNCTION__,__LINE__,delay);
		}
		
        delay = delay /1000;
    }
	
    stRtVideo->s64FrameLastDelay = delay;
    stRtVideo->s64FrameLastPts = stRtPicture->s64Pts;

#if 1
	//非直播模式下，如果同步方式为视频同步到音频,
	if(stRtIpcamInfo->enRtAvSyncType != RT_AV_SYNC_VIDEO_MASTER 
		&& stRtVideo->enLiveType != RT_LIVE_TYPE_LIVE  ){
	    if(stRtAudio){
			
	        refClock = getMasterClock(pstRtplayer,stRtIpcamInfo);

			//LOGD("[%s   %d] refClock=%f\n",__FUNCTION__,__LINE__,refClock);
			
	        if(refClock != 0){
				
	            diff = stRtVideo->s64VideoClock - refClock;
	            //syncThreshold = (delay > AV_SYNC_THRESHOLD ) ? delay : AV_SYNC_THRESHOLD;

				syncThreshold = FFMAX(AV_SYNC_THRESHOLD_MIN,FFMIN(AV_SYNC_THRESHOLD_MAX,delay));

				//LOGD("[%s   %d]  D delay = %f  diff=%f  syncThreshold=%f\n",__FUNCTION__,__LINE__,delay,diff,syncThreshold);
				
	            if(!isnan(diff) && fabs(diff) < 3600){
	               
					if (diff <= -syncThreshold)//说明视频慢了，要加快
					{
						delay =FFMAX(0, delay + diff);

						//LOGD("[%s   %d]  A delay = %f  diff=%f  syncThreshold=%f\n",__FUNCTION__,__LINE__,delay,diff,syncThreshold);
					}
		            else if (diff >= syncThreshold && delay >  AV_SYNC_THRESHOLD)//说明视频快了，要延迟
		            {
		                delay = delay+ diff;
						//LOGD("[%s   %d] B delay = %f  diff=%f  syncThreshold=%f\n",__FUNCTION__,__LINE__,delay,diff,syncThreshold);
		            }
		            else if (diff >= syncThreshold)
		            {
		                delay = 2 *delay;
						//LOGD("[%s   %d] C delay = %f  diff=%f  syncThreshold=%f\n",__FUNCTION__,__LINE__,delay,diff,syncThreshold);
		            }
					
	            }
				
	        }
	    }
	}

#endif
	
#if 0

    if(stRtVideo->s64FrameTimer == 0){
		stRtVideo->s64FrameTimer = (av_gettime()/1000000.0);
	}
    stRtVideo->s64FrameTimer += delay;
	
    actualDelay = stRtVideo->s64FrameTimer-(av_gettime()/1000000.0);
    if(actualDelay < 0.010){
        actualDelay = 0.010;
    }
	
   // LOGD("[%s   %d] actualDelay = %f \n",__FUNCTION__,__LINE__,actualDelay);
   
#endif
	
    
    //发送刷新事件
    actualDelay = delay;
    
    //方便查看log
	static int temp = 0;
	if(stRtAudio){
		if((temp ++) % 200 == 0){
			LOGD("[%s   %d] delay = %f s64VideoClock=%f  s64AudioClock=%f did=%s\n",__FUNCTION__,__LINE__,actualDelay,stRtVideo->s64VideoClock,stRtAudio->s64AudioClock,stRtIpcamInfo->stRtParams->acDid);
		}
	}

	//LOGD("[%s	%d]  video_displayWork E =%f \n ",__FUNCTION__,__LINE__,actualDelay);
	video_sendRefreshEvent(userIpcms,stRtVideo, (int)(actualDelay * 1000 + 0.5),stRtVideo->enLiveType,
                     stRtParams->acDid);

	if(stRtVideo->s32DisplayTraffic < stRtVideo->s32DecodeTraffic){
		//对显示的数据流量进行累加
		stRtVideo->s32DisplayTraffic += stRtPicture->s32PacketSize;
	}
    
    if(stRtParams->s32BlockVideoDecodeData){
        //这个是解码后的数据，但是没有进行对应的转码，比如使用opengl进行转码
        if(stRtParams->funVideoDecodeDataReturnCallBack && stRtPicture->pDecodeFrame){
            stRtParams->funVideoDecodeDataReturnCallBack(stRtParams->userData,stRtPicture);
        }
    }else{
        //如果是ios，可以直接将解码后的frame送出去显示，外部再转化，android的话必须要转rgb
        if(stRtParams->s32BlockScaleData && stRtParams->funScaleDataReturnCallBack && stRtPicture->pDecodeFrame){
            //LOGD("[%s   %d] stRtPicture->s32Width =%d stRtPicture->s32Height =%d \n",__FUNCTION__,__LINE__,stRtPicture->s32Width,stRtPicture->s32Height);
            stRtParams->funScaleDataReturnCallBack(stRtParams->userData,stRtPicture);
        }else{
			 //显示
            rt_video_display(stRtVideo, stRtPicture);
		}
       	
    }
    
    return 0;
}

//事件任务，最终是调用displayWork
static int video_eventWork(RT_PLAYER *pstRtplayer){
    //取出解码好后的数据
    RT_PICTURE *stRtPicture = &pstRtplayer->stRtPictures[pstRtplayer->s32PictureRIndex];
    
    //根据解码好后的数据对应的id，找对应的ipc
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, stRtPicture->acDid);
    
    if(NULL != stRtIpcamInfo){
        
        //如果没有解码好后的数据
        if(pstRtplayer->s32PictureSize == 0){
            video_sendRefreshEvent(pstRtplayer->s32UseIpcams,stRtIpcamInfo->stRtVideo,
                             40,
                             stRtIpcamInfo->stRtVideo->enLiveType,stRtPicture->acDid);
        }else{
        	
            //将解码好后的数据拿去显示
            video_displayWork(pstRtplayer,pstRtplayer->s32UseIpcams,stRtIpcamInfo,stRtPicture);
            
            //s32PictureRIndex 轮询
            if(++(pstRtplayer->s32PictureRIndex) >= RT_VIDEO_PICTURE_QUEUE_SIZE){
                pstRtplayer->s32PictureRIndex = 0;
            }
            
            //总计数减1
            SDL_LockMutex(pstRtplayer->pSDLMutex);
            (pstRtplayer->s32PictureSize)--;
            SDL_CondSignal(pstRtplayer->pSDLCond);
            SDL_UnlockMutex(pstRtplayer->pSDLMutex);
            
        }
        
    }else{
        LOGE("[%s   %d] stRtIpcamInfo null \n",__FUNCTION__,__LINE__);
    }
    
    return 0;
}

//事件监听，最终回调用eventWork
static int video_eventListener(void *argv){
    
    RT_PLAYER *pstRtplayer = NULL;
    pstRtplayer = (RT_PLAYER *)argv;
    
    if(pstRtplayer->s32Stop){
        LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_IPCAM_INFO *stRtIpcamInfo = NULL;
    
    //查找可用ipc
    int i = RT_MAX_IPCAM_SIZE -1;
    for(i = RT_MAX_IPCAM_SIZE -1 ; i >= 0 ; i--){
        stRtIpcamInfo = &pstRtplayer->stRtIpcamInfo[i];
        if(stRtIpcamInfo->stRtVideo){
            break;
        }
    }
    
    //开始发送刷新事件
    video_sendRefreshEvent(pstRtplayer->s32UseIpcams,stRtIpcamInfo->stRtVideo, 40, stRtIpcamInfo->stRtVideo->enLiveType,
                     stRtIpcamInfo->stRtParams->acDid);
    
    //轮询不断的对事件进行监听
    SDL_Event event;
    for(;;){
        
        if(pstRtplayer->s32QuitRefresh){
            LOGD("[%s   %d] s32QuitRefresh A \n",__FUNCTION__,__LINE__);
            break;
        }

		//方便查看log
		static int temp = 0;
		temp++;
		if(temp % 1000 ==0){
			LOGD("[%s   %d] SDL_WaitEvent thread running count=%d \n",__FUNCTION__,__LINE__,temp);
		}
        
        //以超时的方式来等待事件
        if(SDL_WaitEventTimeout(&event, 150)){
            
            if(pstRtplayer->s32QuitRefresh){
                LOGD("[%s   %d] s32QuitRefresh B \n",__FUNCTION__,__LINE__);
                break;
            }
            
            switch (event.type) {
                case RT_EVNET_EIXT://退出事件
                    //LOGD("[%s   %d] RT_EVNET_EIXT \n",__FUNCTION__,__LINE__);
                    pstRtplayer->s32Stop = 1;
                    if(pstRtplayer->s32Stop){
                        pstRtplayer->s32QuitRefresh = 1;
                        if(pstRtplayer->s32QuitRefresh){
                            LOGD("[%s   %d] s32QuitRefresh C \n",__FUNCTION__,__LINE__);
                            break;
                        }
                    }
                    break;
                case RT_EVNET_REFRESH://刷新事件
                    //LOGD("[%s   %d]  RT_EVNET_REFRESH \n ",__FUNCTION__,__LINE__);

					/*如果暂停*/
					if(pstRtplayer->s8VideoPause){
						static char temp = 0;
						temp++;
						if(temp % 255 ==0){
							temp = 0;
							LOGD("[%s   %d] video pause \n",__FUNCTION__,__LINE__);
						}
						//SDL_Delay(50);
						video_sendRefreshEvent(pstRtplayer->s32UseIpcams,stRtIpcamInfo->stRtVideo, 50, stRtIpcamInfo->stRtVideo->enLiveType,stRtIpcamInfo->stRtParams->acDid);
						break;
					}
					
                    video_eventWork(pstRtplayer);
					
                    break;
                default:
                    break;
            }
            
        }else{
            LOGD("[%s   %d] wait event time out error =%s \n",__FUNCTION__,__LINE__,SDL_GetError());
            
            //如果事件超时了，继续发送刷新事件
            video_sendRefreshEvent(pstRtplayer->s32UseIpcams,stRtIpcamInfo->stRtVideo, 40, stRtIpcamInfo->stRtVideo->enLiveType,stRtIpcamInfo->stRtParams->acDid);
        }
    }
    
    LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
    return 0;
}


//将解码好后的frame，转成rgb并存储在数组中
static int video_queuePicture(RT_PLAYER *stRtPlayer,RT_IPCAM_INFO *stRtIpcamInfo,AVFrame *stDecodeFrame,double s64Pts,int packetSize){
    
    //这里一直等待到pic的数组被消耗
    SDL_LockMutex(stRtPlayer->pSDLMutex);
    while(stRtPlayer->s32PictureSize >= RT_VIDEO_PICTURE_QUEUE_SIZE && !stRtPlayer->s32QuitDecodeVideoThread){
        //LOGD("[%s   %d] lock \n ",__FUNCTION__,__LINE__);
        SDL_CondWait(stRtPlayer->pSDLCond, stRtPlayer->pSDLMutex);
    }
    SDL_UnlockMutex(stRtPlayer->pSDLMutex);
    
    if(stRtPlayer->s32QuitDecodeVideoThread){
        LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PICTURE *stRtPicture = &(stRtPlayer->stRtPictures[stRtPlayer->s32PictureWIndex]);
    
    //初始化pDecodeFrame
    if(!stRtPicture->pDecodeFrame ||
       stRtPicture->s32Width != stRtIpcamInfo->stRtVideo->s32PixelW ||
       stRtPicture->s32Height != stRtIpcamInfo->stRtVideo->s32PixelH){
        
        stRtPicture->s32Allocated = 0;
        
        if(stRtPicture->pDecodeFrame){
            //av_free(stRtPicture->pDecodeFrame);
			av_frame_free(&stRtPicture->pDecodeFrame);
            stRtPicture->pDecodeFrame = NULL;
            LOGD("[%s   %d] free pDecodeFrame width=%d height =%d\n",__FUNCTION__,__LINE__,stRtPicture->s32Width,stRtPicture->s32Height);
        }
        
        stRtPicture->s32Width = stRtIpcamInfo->stRtVideo->s32PixelW;
        stRtPicture->s32Height = stRtIpcamInfo->stRtVideo->s32PixelH;
        
        AVFrame *pstAVFrame = av_frame_alloc();
        if(NULL == pstAVFrame){
            LOGE("[%s   %d] av_frame_alloc error \n",__FUNCTION__,__LINE__);
            return -1;
        }

		if(stRtPicture->pBuffer){
			av_free(stRtPicture->pBuffer);
			stRtPicture->pBuffer = NULL;
			LOGD("[%s   %d] stRtPicture->pBuffer ! NULL \n",__FUNCTION__,__LINE__);
		}
        
        //int s32NumBytes = avpicture_get_size(stVideo->enAVPixelFormat, stRtPicture->s32Width, stRtPicture->s32Height);
        int s32NumBytes = av_image_get_buffer_size(stRtIpcamInfo->stRtVideo->enAVPixelFormat,stRtPicture->s32Width, stRtPicture->s32Height,1);
        
        uint8_t *buffer = (uint8_t *) av_malloc(s32NumBytes * sizeof(uint8_t));
        if(NULL == buffer){
            LOGE("[%s   %d] av_malloc error \n",__FUNCTION__,__LINE__);
            return -1;
        }
        
        //avpicture_fill((AVPicture*)pstAVFrame, buffer, stVideo->enAVPixelFormat, stRtPicture->s32Width, stRtPicture->s32Height);
        int rec = av_image_fill_arrays(pstAVFrame->data, pstAVFrame->linesize,buffer,
                             stRtIpcamInfo->stRtVideo->enAVPixelFormat,stRtPicture->s32Width,
                             stRtPicture->s32Height,1);
        //LOGD("[%s   %d] rec =%d \n",__FUNCTION__,__LINE__,rec);
        if(rec < 0){
            LOGE("[%s   %d] av_image_fill_arrays error \n",__FUNCTION__,__LINE__);
            return -1;
        }
        
        //将建立好的复制给
        stRtPicture->pBuffer = buffer;
        stRtPicture->pDecodeFrame = pstAVFrame;
        
        SDL_LockMutex(stRtPlayer->pSDLMutex);
        stRtPicture->s32Allocated = 1;
        SDL_CondSignal(stRtPlayer->pSDLCond);
        SDL_UnlockMutex(stRtPlayer->pSDLMutex);
        
        char fmt[32];
        memset(fmt, 0,sizeof(32));
        if(stRtIpcamInfo->stRtVideo->enAVPixelFormat == AV_PIX_FMT_RGBA){
            strcpy(fmt, "AV_PIX_FMT_RGBA");
        }else if(stRtIpcamInfo->stRtVideo->enAVPixelFormat == AV_PIX_FMT_YUV420P){
            strcpy(fmt, "AV_PIX_FMT_YUV420P");
        }else if(stRtIpcamInfo->stRtVideo->enAVPixelFormat == AV_PIX_FMT_RGB24){
            strcpy(fmt, "AV_PIX_FMT_RGB24");
        }

		//对pDecodeFrame赋值，这些值必须要手动赋值
        stRtPicture->pDecodeFrame->format = stRtIpcamInfo->stRtVideo->enAVPixelFormat;
		stRtPicture->pDecodeFrame->width = stRtPicture->s32Width;
		stRtPicture->pDecodeFrame->height = stRtPicture->s32Height;
        LOGD("[%s   %d] alloc RT_PICTURE success  enAVPixelFormat =%s  WIndex=%d \n",__FUNCTION__,__LINE__,fmt,stRtPlayer->s32PictureWIndex);
        
        if(stRtPlayer->s32QuitDecodeVideoThread){
            LOGE("[%s   %d] exit \n",__FUNCTION__,__LINE__);
            return -1;
        }
    }
    
    if(stRtPicture->pDecodeFrame){
        
        //如果这里设置了解码s32BlockVideoDecodeData则不需要进行转码操作了
        if(stRtIpcamInfo->stRtParams->s32BlockVideoDecodeData){
            //stRtPicture->pDecodeFrame = stDecodeFrame;
            av_frame_unref(stRtPicture->pDecodeFrame);
            av_frame_move_ref(stRtPicture->pDecodeFrame,stDecodeFrame);
        }else{
            
            if(stRtIpcamInfo->stRtVideo->stpSwsCtx){
                //视频转码，缩放
                sws_scale(stRtIpcamInfo->stRtVideo->stpSwsCtx,
                      (uint8_t const * const *)stDecodeFrame->data,
                      stDecodeFrame->linesize,
                      0,
                      stRtIpcamInfo->stRtVideo->s32PixelH,
                      stRtPicture->pDecodeFrame->data,
                      stRtPicture->pDecodeFrame->linesize);
            }else{
                LOGE("[%s   %d] stpSwsCtx == NULL \n",__FUNCTION__,__LINE__);
            }
            
        }
        
        stRtPicture->s64Pts = s64Pts;
		stRtPicture->s32PacketSize = packetSize;
        //LOGE("[%s   %d] pts = %f \n",__FUNCTION__,__LINE__,s64Pts);
        
        //保存did,这样刷新画面的时候，才能对应相应的did，为了避免多台播放的时候，刷新错乱
        if(0 != strcmp(stRtIpcamInfo->stRtParams->acDid,stRtPicture->acDid)){
        	memset(stRtPicture->acDid,0,sizeof(stRtPicture->acDid));
        	strcpy(stRtPicture->acDid, stRtIpcamInfo->stRtParams->acDid);
		}

		
        //长度累计
        SDL_LockMutex(stRtPlayer->pSDLMutex);
        //index 不断的轮询
        if(++(stRtPlayer->s32PictureWIndex) >= RT_VIDEO_PICTURE_QUEUE_SIZE){
            stRtPlayer->s32PictureWIndex = 0;
        }
       
        (stRtPlayer->s32PictureSize)++;
        
        SDL_UnlockMutex(stRtPlayer->pSDLMutex);
        
    }else{
        LOGE("[%s   %d] pDecodeFrame error \n",__FUNCTION__,__LINE__);
    }

    return 0;
}

// 解码的工作
static int video_decodeWork(RT_PLAYER *pstRtplayer){
    
    RT_IPCAM_INFO *stRtIpcamInfo = NULL;
    static int index = RT_MAX_IPCAM_SIZE -1;
    int i= 0;
    //如果单台ipc
    if(pstRtplayer->s32UseIpcams == 1){
        index = RT_MAX_IPCAM_SIZE -1;
    }else if(pstRtplayer->s32UseIpcams > 1){
        //查找可用ipc
        i = index;
    }else{
        //LOGD("[%s   %d] pstRtplayer->s32UseIpcams == 0 \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    //LOGD("[%s   %d] index =%d \n",__FUNCTION__,__LINE__,index);
    for(i = index ; i >= 0 ; i--){
        stRtIpcamInfo = &pstRtplayer->stRtIpcamInfo[i];
        if(stRtIpcamInfo->stRtVideo){
            break;
        }
    }
    
    index--;
    //这里轮询的去解码
    if(index - (RT_MAX_IPCAM_SIZE - pstRtplayer->s32UseIpcams) < 0){
        index = RT_MAX_IPCAM_SIZE -1;
    }
    
    
    if(stRtIpcamInfo){

		if(pstRtplayer->s32QuitDecodeVideoThread){
			LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT;
		}
        
        if(NULL == stRtIpcamInfo->stRtVideo->pVideoPacketQueue){
			goto ERR_EXIT;
        }
        //直到有数据，才建立刷新线程
        if(!gs_s32StartEventListenerTag){
            
            if(stRtIpcamInfo->stRtVideo->pVideoPacketQueue->nb_packets>0)
            {
                
                pstRtplayer->s32QuitRefresh = 0;
                
                LOGD("[%s   %d] create EventListener thread \n",__FUNCTION__,__LINE__);
                
                //以线程分离的方式来创建线程
                pstRtplayer->pEventThread = SDL_CreateThread(video_eventListener, "eventListener", pstRtplayer);
				if(NULL != pstRtplayer->pEventThread){
					gs_s32StartEventListenerTag = 1;
					LOGD("[%s   %d] pEventThread=%p \n",__FUNCTION__,__LINE__,pstRtplayer->pEventThread);
                }else{
					LOGD("[%s   %d] pEventThread create faile \n",__FUNCTION__,__LINE__);
				}
            }else{
                //LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
            }
            
        }
        

		int packetSize = 0;
        //解码
        double s64Pts = rt_video_decode(stRtIpcamInfo->stRtVideo,
                                        stRtIpcamInfo->stRtParams->acDid,
                                        pstRtplayer->pVideoDecodeFrame,&packetSize);

		pstRtplayer->s32IsAlreadyShow = 1;
		
        //如果pts为-1，说明解码失败了
        if(-1 != s64Pts){
			
			//LOGD("[%s   %d] s64Pts= %f \n",__FUNCTION__,__LINE__,s64Pts);
			
//飞控
#ifdef RT_DRONE
			
			if(rt_ffmpeg_decode_faile_get() && stRtIpcamInfo->stRtVideo->s8IsFilterBadFrame){
				rt_ffmpeg_decode_faile_set(0);
				LOGE("[%s	%d] RT_ffmegp_decode_faile \n",__FUNCTION__,__LINE__);
				goto ERR_EXIT;
			}
#endif

			
            //将解码后的存储到队列中
            video_queuePicture(pstRtplayer,stRtIpcamInfo, pstRtplayer->pVideoDecodeFrame, s64Pts,packetSize);
			
        }else{

			goto ERR_EXIT;
		}
        
    }else{
    	LOGE("[%s   %d] stRtIpcamInfo NULL \n",__FUNCTION__,__LINE__);
    	goto ERR_EXIT;
    }
    
    return 0;

ERR_EXIT:
	//休眠一下，防止cpu占用过高
	SDL_Delay(10);
	return -1;
}



//解码的线程，最终会调用decodeWork进行相应地工作
static int video_decodeThread(void *argv){
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)argv;
    
    LOGD("[%s   %d] start \n",__FUNCTION__,__LINE__);
    
    if(pstRtplayer->s32Stop){
        LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
        return -1;
    }
    pstRtplayer->s32QuitDecodeVideoThread = 0;
    gs_s32StartEventListenerTag = 0;
    
    //死循环，不停的解码，并将解码好后的数据存储在队列中
    for(;;){
        if(pstRtplayer->s32QuitDecodeVideoThread){
            LOGD("[%s   %d] s32QuitDecodeVideoThread \n",__FUNCTION__,__LINE__);
            break;
        }
        //解码工作
        video_decodeWork(pstRtplayer);
    }
    
    //退出解码线程后，再退出读取数据的线程
    //pstRtplayer->s32QuitReadDataThread = 1;
    LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
    
    return 0;
}

//SDL播放音频的回调
static void audio_sdlCallBack(void*userData,uint8_t *stream,int len){
    RT_PLAYER *stRtPlayer = (RT_PLAYER *)(userData);
	
    if(stRtPlayer){
		
#if 0
		int len1=0;
		if(stRtPlayer->s32QuitDecodeAuidoThread || stRtPlayer->s32Exit){
			stRtPlayer->u32AudioBufIndex = 0;
			stRtPlayer->u32AudioBufSize = 0;
			LOGD("[%s   %d] exit\n",__FUNCTION__,__LINE__);
			return;
		}
		
		if (stRtPlayer->u32AudioBufIndex >= stRtPlayer->u32AudioBufSize) {
			return 0;
		}
		
		len1 = stRtPlayer->u32AudioBufSize - stRtPlayer->u32AudioBufIndex;
        if (len1 > len) {
            len1 = len;
        }
        memcpy(stream, (uint8_t *) stRtPlayer->pPcmTempBuf + stRtPlayer->u32AudioBufIndex, len1);
        len -= len1;
        stream += len1;
		
        stRtPlayer->pPcmTempBuf += len;
        stRtPlayer->u32AudioBufIndex += len1;
		
#else	
		
 		SDL_memset(stream, 0, len);
	    if(stRtPlayer->u32PcmBufSize <= 0 || stRtPlayer->s32QuitDecodeAuidoThread){
			//SDL_Delay();
	        return;
	    }
		
		if(len > stRtPlayer->u32PcmBufSize){
			 len = stRtPlayer->u32PcmBufSize;
		}
		
	    SDL_MixAudio(stream, stRtPlayer->pPcmTempBuf, len, SDL_MIX_MAXVOLUME);
		
	    stRtPlayer->pPcmTempBuf += len;
	    stRtPlayer->u32PcmBufSize -= len;
		stRtPlayer->u32PcmBufIndex += len;
		
		//LOGD("[%s   %d] len=%d\n",__FUNCTION__,__LINE__,len);
		
#endif
		

    }else{
        LOGE("[%s   %d] stRtPlayer == NULL\n",__FUNCTION__,__LINE__);
    }
}


// 解码的工作
static int audio_decodeWork(RT_PLAYER *pstRtplayer){
    
    RT_IPCAM_INFO *stRtIpcamInfo = NULL;
    static int index = RT_MAX_IPCAM_SIZE -1;
    int i= 0;
    //如果单台ipc
    if(pstRtplayer->s32UseIpcams == 1){
        index = RT_MAX_IPCAM_SIZE -1;
    }else if(pstRtplayer->s32UseIpcams > 1){
        //查找可用ipc
        i = index;
    }else{
        //LOGD("[%s   %d] pstRtplayer->s32UseIpcams == 0 \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    //LOGD("[%s   %d] index =%d \n",__FUNCTION__,__LINE__,index);
    for(i = index ; i >= 0 ; i--){
        stRtIpcamInfo = &pstRtplayer->stRtIpcamInfo[i];
        if(stRtIpcamInfo->stRtAudio){
            break;
        }
    }
    
    index--;
    //这里轮询的去解码
    if(index - (RT_MAX_IPCAM_SIZE - pstRtplayer->s32UseIpcams) < 0){
        index = RT_MAX_IPCAM_SIZE -1;
    }
    
    if(stRtIpcamInfo){
        
        RT_AUDIO *stRtAudio = stRtIpcamInfo->stRtAudio;
        if(NULL == stRtAudio || NULL == stRtAudio->pstAudioPacketQueue ||  NULL ==stRtAudio->stRtAudioParams){
			goto ERR_EXIT;
        }
		
		
		/*pstRtplayer->s32IsAlreadyDecoderAudio是因为必须要解码一次，解码成功后，采样率，信道等信息才能获取到(如果是aac)
		这样在不开启声音的时候，录像就能知道采样率，信道等信息
		之所以要添加这个stRtIpcamInfo->stRtVideo->enLiveType != RT_LIVE_TYPE_LIVE条件是因为回放的时候，
		必须要做到音视频同步必须要计算s64AudioClock的值来作为同步的参考值*/
		int len = 0;
		if(!pstRtplayer->s32IsAlreadyDecoderAudio || stRtAudio->s32OpenAudio || stRtIpcamInfo->stRtVideo->enLiveType != RT_LIVE_TYPE_LIVE){
			double pts;
        	len = rt_audio_decode(stRtAudio, pstRtplayer->pPcmBuf,&pts);
		}
		
		
#if 1
		/*如果没有开始音频则不用播放，如果是回放本地文件则默认播放音频了*/
		if(!stRtAudio->s32OpenAudio ){
			if(stRtIpcamInfo->stRtParams->enRtLiveType != RT_LIVE_TYPE_LOCAL){
				static int temp = 0;
				if(temp++ % 150 == 0){
					LOGD("[%s   %d] audio is not open \n",__FUNCTION__,__LINE__);
				}
				goto ERR_EXIT;
			}
		}
#endif
		//LOGD("[%s   %d] len=%d\n",__FUNCTION__,__LINE__,len);
		if(len <= 0){
			goto ERR_EXIT;
		}

#if 1		
		/**
		如果是本地avi视频，因为录制的音频格式不是pcm的，必须要转码，并且要凑够一帧的pcm数据才能送去播放
		*/
		if(stRtIpcamInfo->stRtStreamIn){
			if(strstr(stRtIpcamInfo->stRtStreamIn->acRtspPath,".avi")){
				int s32PcmToAacSize = stRtAudio->s32PcmToAacSize;
				uint8_t *input_data = pstRtplayer->pPcmBuf;
				if(stRtAudio->pAudioBuf && len < s32PcmToAacSize){
					
					if(stRtAudio->s32AudioBufSize<=0){//如果音频长度小于=0，说明里面没有数据，直接拷贝
						memcpy(stRtAudio->pAudioBuf, input_data, len);
						stRtAudio->s32AudioBufSize = len;
					}else{
						//如果音频长度不为0，需要将数据往前移，并且把回调的数据添加到尾部
						memmove(stRtAudio->pAudioBuf, stRtAudio->pAudioBufBeginPos, stRtAudio->s32AudioBufSize);
						memcpy(stRtAudio->pAudioBuf + stRtAudio->s32AudioBufSize , input_data, len);
						stRtAudio->s32AudioBufSize += len;
					}
					stRtAudio->pAudioBufBeginPos = stRtAudio->pAudioBuf;

					if(stRtAudio->s32AudioBufSize < s32PcmToAacSize){
						goto ERR_EXIT;
					}
					
					memcpy(pstRtplayer->pPcmBuf,stRtAudio->pAudioBufBeginPos,s32PcmToAacSize);
					stRtAudio->s32AudioBufSize -= s32PcmToAacSize;
					stRtAudio->pAudioBufBeginPos += (s32PcmToAacSize % RT_AUDIO_INBUF_SIZE);
					len = s32PcmToAacSize;
				}
				
			}
			
		}
#endif
		
		pstRtplayer->s32IsAlreadyDecoderAudio = 1;
		
        if(stRtIpcamInfo->stRtParams->s32BlockAudioDecodeData){
            if(stRtIpcamInfo->stRtParams->funAudioDecodeDataReturnCallBack){
                stRtIpcamInfo->stRtParams->funAudioDecodeDataReturnCallBack(stRtIpcamInfo->stRtParams->userData,stRtIpcamInfo->stRtParams->acDid,pstRtplayer->pPcmBuf,len);
            }else{
                LOGE("[%s   %d] funAudioDecodeDataReturnCallBack == NULL\n",__FUNCTION__,__LINE__);
            }
        }else{
        	if(pstRtplayer->s32QuitDecodeAuidoThread){
	            LOGD("[%s   %d] s32QuitDecodeAuidoThread \n",__FUNCTION__,__LINE__);
	            return 0;
	        }
        	
            //赋值，pPcmTempBuf跟s32AudioLen将用于SDL播放
	        pstRtplayer->pPcmTempBuf = pstRtplayer->pPcmBuf;
	        pstRtplayer->u32PcmBufSize = len;
			pstRtplayer->u32PcmBufIndex = 0;
			
            /*
            如果没有开启SDL回调则开启，这里只开启一次，放在这个地方初始化，
            是因为必须先确定好采样率，信道等信息
            */
            if(0 == gs_s32StartSDLAudioCallBackTag){
            
                gs_s32StartSDLAudioCallBackTag = 1;
                
                //如果是播放
                SDL_AudioSpec wanted_spec;
                
                //默认支持的采样率
                static const int sample_rates[] = {0,7350,8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000};
                
                //查找采样率是否真确，如果这个值不正确，会导致sdl，回调无效，并且会卡死
                int i = 5;
                int smaple_rate = -1;
                while(i>=0){
                    if(stRtAudio->stRtAudioParams->s32Sample_rate ==sample_rates[i]){
                        smaple_rate = stRtAudio->stRtAudioParams->s32Sample_rate;
                        break;
                    }
                    i--;
                }
                if(smaple_rate == -1){
                    LOGE("[%s   %d] error sample_reate = %d and set to defualt 96000\n",__FUNCTION__,__LINE__,stRtAudio->pAudioCodecCtx->sample_rate);
                    smaple_rate = 96000;
                }

				int s32Channel = stRtAudio->stRtAudioParams->s32Channel;
				if(s32Channel <= 0){
					LOGE("[%s   %d] s32Channel =%d set to default 1 \n",__FUNCTION__,__LINE__,s32Channel);
					s32Channel= 1;
				}
                wanted_spec.freq = smaple_rate;
                wanted_spec.format = AUDIO_S16SYS;
                wanted_spec.channels = s32Channel;
                wanted_spec.samples = 1024;//aac:1024 ;mp3:1152
                wanted_spec.silence = 0;//静音
                wanted_spec.callback = audio_sdlCallBack;
                wanted_spec.userdata = pstRtplayer;
                
                if(pstRtplayer->s32QuitDecodeAuidoThread){
                    LOGD("[%s   %d] quit\n",__FUNCTION__,__LINE__);
                    goto ERR_EXIT;
                }
                
                if(SDL_OpenAudio(&wanted_spec, NULL)<0){
                    LOGE("[%s   %d] cannot open audio device \n",__FUNCTION__,__LINE__);
                    goto ERR_EXIT;
                }
				
                SDL_PauseAudio(0);
				
                LOGD("[%s   %d] SDL_OpenAudio freq=%d  channels=%d\n",
					__FUNCTION__,__LINE__,
					wanted_spec.freq ,
					wanted_spec.channels);
				
				LOGD("[%s   %d] Carefully !!!!!!!!!! s32OpenAudio=%d  audioStatus=%d  s32QuitDecodeAuidoThread =%d\n",
					__FUNCTION__,__LINE__,
					stRtAudio->s32OpenAudio,
					SDL_GetAudioStatus(),
					pstRtplayer->s32QuitDecodeAuidoThread);
            }
			
#if 0
            while ((pstRtplayer->u32AudioBufIndex < pstRtplayer->u32AudioBufSize) && (!pstRtplayer->s32Exit)) {
				if(pstRtplayer->s32Exit){
					LOGD("[%s   %d] s32Exit\n",__FUNCTION__,__LINE__);
					break;
				}
                //直到SDL播放完毕pPcmTempBuf里面的数据，才进行下一次解码
                SDL_Delay(1);
            }
#else		
			/*
			如果正在播放解码完后一直等待到audio_sdlCallBack
			函数消耗完pPcmTempBuf数据后才进行下一次音频解码
			
			*/
			while ((stRtAudio->s32OpenAudio)&& (SDL_GetAudioStatus() == SDL_AUDIO_PLAYING) &&(pstRtplayer->u32PcmBufSize > 0)&&(!pstRtplayer->s32QuitDecodeAuidoThread)){
				//LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
				SDL_Delay(1);
			}
#endif
            
        }
        
    }else{
        LOGE("[%s   %d] stRtIpcamInfo NULL \n",__FUNCTION__,__LINE__);
    }
    
    return 0;
	
ERR_EXIT:
	//休眠一下，防止占用cpu过高
	SDL_Delay(10);
	return -1;
}



static int audio_decodeThread(void *argv){
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)argv;
    
    LOGD("[%s   %d] start \n",__FUNCTION__,__LINE__);
    
    if(pstRtplayer->s32Stop){
        LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
        return -1;
    }
    pstRtplayer->s32QuitDecodeAuidoThread = 0;
    gs_s32StartSDLAudioCallBackTag = 0;
    //死循环，不停的解码，并将解码好后的数据存储在队列中
    for(;;){
        if(pstRtplayer->s32QuitDecodeAuidoThread){
            LOGD("[%s   %d] s32QuitDecodeAuidoThread \n",__FUNCTION__,__LINE__);
            break;
        }

		/*如果暂停*/
		if(pstRtplayer->s8VideoPause){
			static char temp = 0;
			temp++;
			if(temp % 255 ==0){
				temp = 0;
				LOGD("[%s   %d] video pause \n",__FUNCTION__,__LINE__);
			}
			SDL_Delay(30);
			continue;
		}
		
        //解码工作
        audio_decodeWork(pstRtplayer);
    }
    
    LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
    
    return 0;
}


static int stream_readDataWork(RT_PLAYER *pstRtplayer){
	
	RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,RT_DEFAUT_UID);

	if(stRtIpcamInfo == NULL){
		LOGE("[%s   %d] \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
	RT_STRAM_IN *stRtStreamIn = stRtIpcamInfo->stRtStreamIn;
	RT_VIDEO *stRtRtVideo = stRtIpcamInfo->stRtVideo;
    RT_AUDIO *stRtAudio = stRtIpcamInfo->stRtAudio;
	
	static int readDataErrorCount = 0;
	
    /***********************快进********************/
    if(stRtStreamIn->s64SeekPosition >= 0 && RT_LIVE_TYPE_LIVE != stRtStreamIn->enLiveType){
        
        int64_t seek_target = stRtStreamIn->s64SeekPosition;
        seek_target = seek_target * AV_TIME_BASE;
        
        if(stRtStreamIn->pformatCtx->start_time != AV_NOPTS_VALUE){
            seek_target += stRtStreamIn->pformatCtx->start_time;
        }
        
       // seek_target += av_rescale_q(seek_target, AV_TIME_BASE_Q, stRtRtVideo->pVideoStream->time_base);
        
        int stream_index = av_find_default_stream_index(stRtStreamIn->pformatCtx);
        //if(stream_index >= 0){
            int rec = av_seek_frame(stRtStreamIn->pformatCtx, -1, seek_target, AVSEEK_FLAG_BACKWARD);
            
            if(rec <0){
                if(stRtStreamIn->funVideoMsgReturnCallBack){
                    stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_SEEK_STATE,0);
                }
            }else{
            	
                //avi格式要特别处理一下
                if(stRtStreamIn->enLiveType != RT_LIVE_TYPE_LIVE && strstr(stRtIpcamInfo->stRtParams->acDid,"avi")){
                    stRtRtVideo->s64VideoClock = stRtStreamIn->s64SeekPosition;
                }else{
                    //stRtRtVideo->s64VideoClock = 0;
                }
                
                rt_queue_clear(stRtRtVideo->pVideoPacketQueue);
                if(stRtAudio){
                    rt_queue_clear(stRtAudio->pstAudioPacketQueue);
                }
                
                if(stRtStreamIn->funVideoMsgReturnCallBack){
                    stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_SEEK_STATE,1);
                }
                
            }
            
        //}
        
        LOGD("[%s   %d] seek to %lld",__FUNCTION__,__LINE__,stRtStreamIn->s64SeekPosition);
        
        //将快进时间置为-1
        stRtStreamIn->s64SeekPosition = -1;
        
    }

	
    /***************如果不是直播,读取本地文件会很快，所以要做如下处理**********/
    if(stRtStreamIn->enLiveType == RT_LIVE_TYPE_LOCAL){

		/**
		如果视频的队列，或者音频的队列超过了最大值
		*/
		
        if(stRtRtVideo->pVideoPacketQueue->nb_packets > RT_MAX_QUEUE_SIZE ||
           (stRtAudio &&
            (stRtAudio->pstAudioPacketQueue)&&
            (stRtAudio->pstAudioPacketQueue->nb_packets>RT_MAX_QUEUE_SIZE))){
			
			if(!stRtAudio){
            	LOGD("[%s   %d] nb_packets to much  videoPackets=%d\n",
                 __FUNCTION__,
                 __LINE__,
                 stRtRtVideo->pVideoPacketQueue->nb_packets);
			}else{
				if(stRtAudio->pstAudioPacketQueue){
					LOGD("[%s   %d] nb_packets to much  videoPackets=%d audioPackets=%d\n",
                 		__FUNCTION__,
                 		__LINE__,
                 		stRtRtVideo->pVideoPacketQueue->nb_packets,
                 		stRtAudio->pstAudioPacketQueue->nb_packets);
				}
			}
			
			SDL_Delay(50);
        	return -1;
			
        }
    }

	AVPacket pkt;
    av_init_packet(&pkt);
    int rec = av_read_frame(stRtStreamIn->pformatCtx, &pkt);
    if(rec < 0){
        if(rec == AVERROR_EOF){
            LOGE("[%s   %d] AVERROR_EOF \n",__FUNCTION__,__LINE__);
        }else if(rec == AVERROR_EXIT){
            LOGE("[%s   %d] AVERROR_EXIT \n",__FUNCTION__,__LINE__);
        }else if(rec == AVERROR_EXTERNAL){
            LOGE("[%s   %d] AVERROR_EXTERNAL \n",__FUNCTION__,__LINE__);
        }
		
		//如果不是直播说明播放完毕
	    if(stRtStreamIn->enLiveType != RT_LIVE_TYPE_LIVE){
	        
	        //如果队列中的数目没有小于0，则说明队列中没有播放完毕，但是已经读完完毕了
	        if(stRtRtVideo->pVideoPacketQueue->nb_packets <= 0){
				pstRtplayer->s32QuitReadDataThread = 1;
	            LOGD("[%s   %d] read data end exit queueSize =%d \n",__FUNCTION__,__LINE__,stRtRtVideo->pVideoPacketQueue->nb_packets);
				
				//视频播放结束状态
				stRtStreamIn->s32State = 1;
				
			}else{
	            SDL_Delay(200);
	            LOGD("[%s   %d] read data end queueSize =%d \n",__FUNCTION__,__LINE__,stRtRtVideo->pVideoPacketQueue->nb_packets);
	        }
	        
	    }else{
	        
	       
			readDataErrorCount++;
	        //因为超时时间设置为1秒，所以这里连续3秒读取不到数据，则结束
	        if(readDataErrorCount >= 3){
	            
	            LOGE("[%s   %d] readDataErrorCount=%d and exit\n",__FUNCTION__,__LINE__,readDataErrorCount);

				pstRtplayer->s32QuitReadDataThread = 1;

				//视频播放结束状态
				stRtStreamIn->s32State = 2;
				
	        } 
			SDL_Delay(30);
	        LOGE("[%s   %d] readDataErrorCount=%d\n",__FUNCTION__,__LINE__,readDataErrorCount);
	    }
	    
	    return -1;
    }


//飞控
#ifdef RT_DRONE
			
			static int miss_packet_count =0;
			static char wait_i_frame =0;
			
			//如果是丢包
			if(rt_ffmpeg_miss_package_get()&& stRtRtVideo->s8IsFilterBadPacket){
				
				rt_ffmpeg_miss_package_set(0);
				
				/*
				如果丢包超过一次或者丢的是I帧
				【如果要过滤掉所有的花屏，这里可以写成miss_packet_count>=0】
				*/
				if(miss_packet_count>=1 || pkt.flags){
	
					/*
					是否等待i帧，如果g_wait_i_frame为1，则后面的帧会被抛弃，直到下一个I帧到来
					*/
					wait_i_frame = 1;
					miss_packet_count =0;
					LOGE("[%s	  %d] Wait I Frame	miss is %s	Frame\n",__FUNCTION__,__LINE__,pkt.flags? "I":"P");
				}
				
				miss_packet_count++;
				
				LOGE("[%s	  %d] RT_ffmegp_miss_package\n",__FUNCTION__,__LINE__);
				av_packet_unref(&pkt);
				
				return -1;
			}
	
			//如果是I帧
			if(pkt.flags && wait_i_frame){
				wait_i_frame = 0;
				miss_packet_count = 0;
				LOGE("[%s	  %d] I Frame Start\n",__FUNCTION__,__LINE__);
				LOG_PRINT_HEX(pkt.data,0,36);
			}
			
			if(wait_i_frame){
				LOGE("[%s	  %d] wait_i_frame\n",__FUNCTION__,__LINE__);
				av_packet_unref(&pkt);
				return -1;
			}
				
#endif

    //如果获取数据成功
    readDataErrorCount = 0;
	if(0 != pkt.size){
            
        //如果直播过程中，出现缓冲过大的情况【一般都是手机性能达不到要求，解码慢】
        if(stRtStreamIn->enLiveType != RT_LIVE_TYPE_LOCAL){
            if(stRtRtVideo->pVideoPacketQueue->nb_packets > RT_MAX_QUEUE_SIZE){
                rt_queue_clear(stRtRtVideo->pVideoPacketQueue);
                
                if(stRtAudio){
                    rt_queue_clear(stRtAudio->pstAudioPacketQueue);
                }
                
                LOGD("[%s   %d] queue to much nb_packets=%d \n",__FUNCTION__,__LINE__,stRtRtVideo->pVideoPacketQueue->nb_packets);
                av_packet_unref(&pkt);
                return -1;
            }
        }
        
        //添加到队列中
        if(pkt.stream_index == stRtRtVideo->s32VideoStreamIndex){
            //LOG_PRINT_HEX(pkt.data, 0, 60);
            //保存视频数据
            if(stRtIpcamInfo->stRtStreamOut &&
               stRtIpcamInfo->stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
                rt_stream_out_write_video_h264(stRtIpcamInfo->stRtStreamOut,&pkt);
            }
            //记录接收到的数据包总量
			stRtRtVideo->s32ReceiveTraffic += pkt.size;		
			
			/*
			如果是直播
			*/
			if(stRtIpcamInfo->stRtParams->enRtLiveType == RT_LIVE_TYPE_LIVE){
				/*
				这里尝试的去统计一下fps，计算两个I帧之间p帧的个数，
				这种方式对gob跟fps相同的情况下适用，统计方式有待修正，暂时这样写
				*/
				static int temp = 0;
				if(pkt.flags){
					if(temp != 0){
						if( temp >5 && temp < 40){
							stRtRtVideo->s32CountFps = temp;
							//LOGD("[%s   %d] countFps=%d\n",__FUNCTION__,__LINE__,temp);
						}
					}
					temp = 1;
				}else if(temp >=1 && !pkt.flags){
					temp ++;
				}
			}
	

			if(stRtIpcamInfo->stRtParams->funH264DataReturnCallBack){
				int rec = stRtIpcamInfo->stRtParams->funH264DataReturnCallBack(stRtIpcamInfo->stRtParams->userData,RT_DEFAUT_UID,&pkt);
				if(rec >= 0){
					rt_queue_put(stRtRtVideo->pVideoPacketQueue, &pkt);
				}else{
					av_packet_unref(&pkt);
					LOGD("[%s   %d] pAVPacket is Drop \n",__FUNCTION__,__LINE__);
				}
			}else{
            	//存放到视频队列中
            	rt_queue_put(stRtRtVideo->pVideoPacketQueue, &pkt);
			}
        }else if(stRtAudio && pkt.stream_index == stRtAudio->s32AudioStreamIndex){
            //LOG_PRINT_HEX(pkt.data, 0, 30);
            
            //保存音频数据
            if(stRtIpcamInfo->stRtStreamOut &&
               stRtIpcamInfo->stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
                rt_stream_out_write_audio_aac(stRtIpcamInfo->stRtStreamOut,&pkt);
            }
            
            //存放到音频队列中
            rt_queue_put(stRtAudio->pstAudioPacketQueue, &pkt);
            
        }else{
            LOGD("[%s   %d] bad packet \n",__FUNCTION__,__LINE__);
            av_packet_unref(&pkt);
        }
        
    }else{
         av_packet_unref(&pkt);
         LOGD("[%s   %d] pAVPacket size 0 \n",__FUNCTION__,__LINE__);
    }
	
	return 0;
}

static int stream_readDataThread(void *argv){
	
	RT_PLAYER *pstRtplayer = (RT_PLAYER *)argv;
	LOGD("[%s   %d] start \n",__FUNCTION__,__LINE__);
    pstRtplayer->s32QuitReadDataThread = 0;

	RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,RT_DEFAUT_UID);
	
	if(NULL == stRtIpcamInfo){
        LOGE("[%s   %d] stRtIpcamInfo \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_STRAM_IN *stRtStreamIn = stRtIpcamInfo->stRtStreamIn;
	
	if(rt_stream_in_open(stRtStreamIn) < 0){
		//视频打开失败设置回调
		if(stRtStreamIn->funVideoMsgReturnCallBack){
			stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_FILE_OPNE_STATE,0);
		}
		return -1;
	}
	
	if(pstRtplayer->s32QuitReadDataThread){
		LOGD("[%s	%d] s32QuitReadDataThread \n",__FUNCTION__,__LINE__);
		return -1;
	}

	long long videoTotalTime = rt_stream_in_find_info(stRtStreamIn) ;
	if(videoTotalTime <0 ){
		return -1;
	}
	if(videoTotalTime > 0){  
		if(stRtStreamIn->funVideoMsgReturnCallBack){
        	stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_TOTAL_PTS,(int)videoTotalTime);
    	}
	}
	
	
    if(pstRtplayer->s32QuitReadDataThread){
		LOGD("[%s	%d] s32QuitReadDataThread \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
    RT_VIDEO *stRtRtVideo = stRtIpcamInfo->stRtVideo;
    RT_AUDIO *stRtAudio = stRtIpcamInfo->stRtAudio;
    /***************************************音频***************************************/
    if(stRtAudio){
        int status = 0;
        if(stRtStreamIn->s32AudioStreamIndex == -1){
            stRtAudio->s32OpenAudio = 0;
            status = 0;
            //开启音频失败
            LOGE("[%s   %d] can not audio stream index \n",__FUNCTION__,__LINE__);
        }else{
            status = 1;

			stRtAudio->pAudioStream = stRtStreamIn->pformatCtx->streams[stRtStreamIn->s32AudioStreamIndex];

			if(NULL == stRtAudio->pAudioStream){
				LOGE("[%s   %d] NULL == stRtAudio->pAudioStream\n",__FUNCTION__,__LINE__);
				return -1;
			}

			//记得赋值给stRtAudioParams
			stRtIpcamInfo->stRtAudio->stRtAudioParams = &(stRtIpcamInfo->stRtParams->stRtAudioParams);
			
            if(rt_audio_init(stRtAudio,stRtAudio->pAudioStream->codecpar->codec_id,
                             stRtAudio->pAudioStream->codecpar) < 0 ){
                //音频初始化失败，初始化失败后为了不影响出图，这里不做处理
            }else{
                stRtAudio->s32AudioStreamIndex = stRtStreamIn->s32AudioStreamIndex;
                //rt_audio_play(stRtIpcamInfo);
            }

			
			/*
			本地视频默认打开音频
			*/
			if(stRtIpcamInfo->stRtParams->enRtLiveType == RT_LIVE_TYPE_LOCAL){
				stRtAudio->s32OpenAudio = 1;
			}
            LOGE("[%s   %d] open audio stream success \n",__FUNCTION__,__LINE__);
        }
        
        //将音频开启成功与否的状态回调出去
        if(stRtStreamIn->funVideoMsgReturnCallBack){
            stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_AUIDO_OPEN_STATE,status);
        }
        
    }else{
        LOGE("[%s   %d] open audio stream faile \n",__FUNCTION__,__LINE__);
    }
    
    
    /***************************************视频***************************************/
	if(stRtRtVideo){
	    if(stRtStreamIn->s32VideoStreamIndex != -1){
			
			
		   	stRtRtVideo->pVideoStream= stRtStreamIn->pformatCtx->streams[stRtStreamIn->s32VideoStreamIndex];
			
			if(NULL == stRtRtVideo->pVideoStream){
				LOGE("[%s   %d] NULL == stRtRtVideo->pVideoStream\n",__FUNCTION__,__LINE__);
				return -1;
			}
			
			LOGD("[%s   %d] codec_id=%d\n",__FUNCTION__,__LINE__,stRtRtVideo->pVideoStream->codecpar->codec_id);
	        
	        if(rt_video_init(stRtRtVideo, stRtRtVideo->pVideoStream->codecpar->codec_id,
	                         stRtIpcamInfo->stRtParams->enRtLiveType,
	                         stRtIpcamInfo->stRtParams->enAVPixelFormat,
	                         stRtRtVideo->pVideoStream->codecpar)<0){
	            //视频初始化失败
	            return -1;
	        }
			
	        stRtRtVideo->s32VideoStreamIndex  = stRtStreamIn->s32VideoStreamIndex;
			RT_PARAMS_EXTRA *stRtParmasExtra = stRtIpcamInfo->stRtParams->stRtParmasExtra;
	        if(stRtParmasExtra){
				stRtIpcamInfo->stRtVideo->s32CacheFrameNum = stRtParmasExtra->s32CacheFrameNum;
				stRtIpcamInfo->stRtVideo->s8IsFilterBadFrame= stRtParmasExtra->s8IsFilterBadFrame;
				stRtIpcamInfo->stRtVideo->s8IsFilterBadPacket= stRtParmasExtra->s8IsFilterBadPacket;
				LOGD("[%s   %d] s32CacheFrameNum = %d, s8IsFilterBadFrame=%d, s8IsFilterBadPacket=%d\n",__FUNCTION__,__LINE__,
					stRtIpcamInfo->stRtVideo->s32CacheFrameNum,
					stRtParmasExtra->s8IsFilterBadFrame,
					stRtParmasExtra->s8IsFilterBadPacket);
			}
	    }else{
	        LOGE("[%s   %d] can not video stream index \n",__FUNCTION__,__LINE__);
	        return -1;
	    }
	}else{
		 LOGE("[%s   %d] stRtRtVideo is NULL \n",__FUNCTION__,__LINE__);
		 return -1;
	}

	if(pstRtplayer->s32QuitReadDataThread){
		LOGD("[%s	%d] s32QuitReadDataThread \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
	//死循环，不停的获取数据
    for(;;){
        if(pstRtplayer->s32QuitReadDataThread){
            LOGD("[%s   %d] s32QuitReadDataThread \n",__FUNCTION__,__LINE__);
            break;
        }

		/*如果暂停*/
		if(pstRtplayer->s8VideoPause){
			static char temp = 0;
			temp++;
			if(temp % 255 ==0){
				temp = 0;
				LOGD("[%s   %d] video pause \n",__FUNCTION__,__LINE__);
			}
			SDL_Delay(50);
			continue;
		}
		
        //读取数据的工作
        stream_readDataWork(pstRtplayer);
    }
	
	//这里让线程退出后再回调对应的消息，避免一些重连的问题(比如说用户接收到视频中断后，马上重连操作)
	if(stRtStreamIn->s32State == 1){
		if(stRtStreamIn->funVideoMsgReturnCallBack){
			LOGD("[%s   %d] send video play end msg\n",__FUNCTION__,__LINE__);
            stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_LIVE_PLAY_END,1);
        }
	}else if(stRtStreamIn->s32State == 2){
		if(stRtStreamIn->funVideoMsgReturnCallBack){
			LOGD("[%s   %d] send video interrupt end msg\n",__FUNCTION__,__LINE__);
            stRtStreamIn->funVideoMsgReturnCallBack(stRtStreamIn->userData,stRtIpcamInfo->stRtParams->acDid,RT_MSG_TYPE_LIVE_PLAY_INTERRUPT,1);
        }
	}
    
    LOGD("[%s   %d] exit \n",__FUNCTION__,__LINE__);
	
	return 0;
}



int rt_pub_init(int **hppPlayerHandle,RT_GET_DATA_TYPE enGetDataType,int initFlags){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL != *hppPlayerHandle){
        LOGE("[%s   %d] hppPlayerhandle != NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    memset(&gs_stRtPlayer,0,sizeof(RT_PLAYER));
    
    gs_stRtPlayer.s32Exit = 1;
	gs_stRtPlayer.s32Stop = 1;
    gs_stRtPlayer.s32QuitDecodeVideoThread = 1;
    gs_stRtPlayer.s32QuitDecodeAuidoThread = 1;
    gs_stRtPlayer.s32QuitReadDataThread = 1;
    gs_stRtPlayer.s32QuitRefresh = 1;
    gs_stRtPlayer.enGetDataType = enGetDataType;
    gs_stRtPlayer.s32UseIpcams = 0;
    gs_stRtPlayer.pDecodeVideoThread = NULL;
    gs_stRtPlayer.pEventThread = NULL;
    gs_stRtPlayer.u32PcmBufSize = 0;
	gs_stRtPlayer.u32PcmBufIndex = 0;
	gs_stRtPlayer.s32AudioPlay = 0;
	gs_stRtPlayer.s32IsAlreadyDecoderAudio = 0;
	gs_stRtPlayer.s32IsAlreadyShow = 0;
	gs_stRtPlayer.s8VideoPause = 0;
	
	//确认初始化的模块
	if (initFlags & RT_INIT_VIDEO) {
		++gs_SubsystemRefCount[RT_INIT_VIDEO];
		LOGD("[%s	%d] RT_INIT_VIDEO\n",__FUNCTION__,__LINE__);
	}
	
	if (initFlags & RT_INIT_AUDIO) {
		++gs_SubsystemRefCount[RT_INIT_AUDIO];
		LOGD("[%s	%d] RT_INIT_AUDIO\n",__FUNCTION__,__LINE__);
	}
	
	
    SDL_SetMainReady();
    
    //初始化SDL
    Uint32 subsystem_mask = SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER;//SDL_INIT_VIDEO  SDL_INIT_AUDIO | SDL_INIT_TIMER
    if (SDL_WasInit(subsystem_mask) == subsystem_mask) {
        LOGE("[%s	 %d ] Video and Audio initialized.\n", __FUNCTION__,__LINE__);
    } else {
        if(SDL_Init(subsystem_mask)!=0){
            LOGE("[%s	 %d ]init SDL error: %s\n", __FUNCTION__,__LINE__,SDL_GetError());
            return -1;
        }
    }
	
    SDL_EventState(SDL_SYSWMEVENT, SDL_IGNORE);
    SDL_EventState(SDL_USEREVENT, SDL_IGNORE);
    
    //初始化之前先确保上一次资源释放完(安全做法)
    relaseRtPlayer(&gs_stRtPlayer);
    
    //ffmpeg注册所有
    av_register_all();
    avformat_network_init();
    
    //将地址传递出去，外部通过该地址来做相应的操作
    *hppPlayerHandle = (int*)&gs_stRtPlayer;

	//这里开始下面的打印会闪退，应该是ffmpeg打印log不能在xx线程，有可能是编译的问题
    //av_log_set_level(AV_LOG_WARNING|AV_LOG_DEBUG|AV_LOG_FATAL|AV_LOG_ERROR);//AV_LOG_ERROR  AV_LOG_WARNING AV_LOG_DEBUG AV_LOG_FATAL
    //av_log_set_callback(ffmepgLogoutPut);
    
    gs_stRtPlayer.pVideoDecodeFrame = av_frame_alloc();
    if(NULL == gs_stRtPlayer.pVideoDecodeFrame){
        LOGE("[%s   %d] av_frame_alloc error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    gs_stRtPlayer.pSDLMutex = SDL_CreateMutex();
    if(NULL == gs_stRtPlayer.pSDLMutex){
        LOGE("[%s   %d] SDL_CreateMutex error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    gs_stRtPlayer.pSDLCond = SDL_CreateCond();
    if(NULL == gs_stRtPlayer.pSDLCond){
        LOGE("[%s   %d] SDL_CreateCond error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    gs_stRtPlayer.pPcmBuf = (uint8_t*)malloc(RT_AUDIO_INBUF_SIZE + AV_INPUT_BUFFER_PADDING_SIZE);
    if(NULL == gs_stRtPlayer.pPcmBuf){
        LOGE("[%s   %d] pPcmBuf malloc error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }

	
	LOGD("#################################################################\n");
	
   	LOGD("[%s   %d] success *hppPlayerHandle = %d\n",__FUNCTION__,__LINE__,(int)(*hppPlayerHandle));

	
	//打印ffmpeg的版本，sdl的版本
	SDL_version compiled;
    SDL_VERSION(&compiled);
	LOGD("[%s   %d] ffmpegVersion=%s , SDLVersion=%d.%d.%d , SDKVersion=%s \n",
   	__FUNCTION__,
   	__LINE__,
   	av_version_info(),
   	compiled.major, 
   	compiled.minor, 
   	compiled.patch,
   	RTP2P_VERSION);

	#ifdef RT_DRONE
	LOGD("[%s   %d] is support Drone\n",__FUNCTION__,__LINE__);
	#else
	LOGD("[%s   %d] not support Drone\n",__FUNCTION__,__LINE__);
	#endif
	LOGD("#################################################################\n");
	
    return 0;
	
ERR_EXIT:
    
    LOGE("[%s   %d] error \n",__FUNCTION__,__LINE__);
    
    if(gs_stRtPlayer.pSDLCond){
        SDL_CondSignal(gs_stRtPlayer.pSDLCond);
        SDL_DestroyCond(gs_stRtPlayer.pSDLCond);
        gs_stRtPlayer.pSDLCond = NULL;
    }
    
    if(gs_stRtPlayer.pSDLMutex){
        SDL_DestroyMutex(gs_stRtPlayer.pSDLMutex);
        gs_stRtPlayer.pSDLMutex = NULL;
    }
    
    if(gs_stRtPlayer.pVideoDecodeFrame){
        av_frame_free(&gs_stRtPlayer.pVideoDecodeFrame);
        gs_stRtPlayer.pVideoDecodeFrame = NULL;
    }
    
    *hppPlayerHandle = NULL;
    
    return -1;
}


//添加ipcam,使用ffmpeg播放本地视频
int rt_pub_add_local_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pFilePath){
    if(pFilePath == NULL){
        LOGE("[%s   %d] pFilePath is NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
	if(stRtParams == NULL){
        LOGE("[%s   %d] stRtParams is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	memset(stRtParams->acDid,0,sizeof(stRtParams->acDid));
	strcpy(stRtParams->acDid,RT_DEFAUT_UID);
    return addIpcam(pPlayerHandle, pFilePath, stRtParams);
}

//添加ipcam,使用ffmpeg播放rtsp视频
int rt_pub_add_rtsp_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pRtspPath){
    if(pRtspPath == NULL){
        LOGE("[%s   %d] pRtspPath is NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
	if(stRtParams == NULL){
        LOGE("[%s   %d] stRtParams is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	memset(stRtParams->acDid,0,sizeof(stRtParams->acDid));
	strcpy(stRtParams->acDid,RT_DEFAUT_UID);
    return addIpcam(pPlayerHandle, pRtspPath, stRtParams);
}

//添加ipcam,使用ffmpeg播放http视频
int rt_pub_add_http_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pHttpPath){
    if(pHttpPath == NULL){
        LOGE("[%s   %d] pHttpPath is NULL\n",__FUNCTION__,__LINE__);
        return -1;
    }
	if(stRtParams == NULL){
        LOGE("[%s   %d] stRtParams is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	memset(stRtParams->acDid,0,sizeof(stRtParams->acDid));
	strcpy(stRtParams->acDid,RT_DEFAUT_UID);
    return addIpcam(pPlayerHandle, pHttpPath, stRtParams);
}

//添加ipcam,使用p2p获取视频流的时候使用，所以不需要传递文件的路径
int rt_pub_add_p2p_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams){
    return addIpcam(pPlayerHandle, NULL, stRtParams);
}

//移除ipcam,这个方法是很危险的方法，在多个视频同时直播过程中少用
int rt_pub_remove_ipcam(int *pPlayerHandle,const char *pDid){
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,pDid);
    if(NULL == stRtIpcamInfo){
        LOGE("[%s   %d] remove ipcam error \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    SDL_LockMutex(pstRtplayer->pSDLMutex);
    memset(stRtIpcamInfo->stRtParams->acDid, 0, sizeof(stRtIpcamInfo->stRtParams->acDid));
    pstRtplayer->s32UseIpcams --;
    
    
    LOGD("[%s    %d] start remove uid =%s  \n",__FUNCTION__,__LINE__,stRtIpcamInfo->stRtParams->acDid);
    
    
    //释放视频
    if(stRtIpcamInfo->stRtVideo){
        rt_video_relase(stRtIpcamInfo->stRtVideo,pstRtplayer->enGetDataType);
        free(stRtIpcamInfo->stRtVideo);
        stRtIpcamInfo->stRtVideo = NULL;
    }
    
    //释放音频
    if(stRtIpcamInfo->stRtAudio){
        rt_audio_relase(stRtIpcamInfo->stRtAudio);
        free(stRtIpcamInfo->stRtAudio);
        stRtIpcamInfo->stRtAudio = NULL;
    }
    
    //释放输入流
    if(stRtIpcamInfo->stRtStreamIn){
        rt_stream_in_relase(stRtIpcamInfo->stRtStreamIn);
        free(stRtIpcamInfo->stRtStreamIn);
        stRtIpcamInfo->stRtStreamIn = NULL;
    }
    
    //释放输出流
    if(stRtIpcamInfo->stRtStreamOut){
        rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
        free(stRtIpcamInfo->stRtStreamIn);
        stRtIpcamInfo->stRtStreamOut = NULL;
    }
    
    memset(stRtIpcamInfo, 0,sizeof(RT_IPCAM_INFO));
    SDL_UnlockMutex(pstRtplayer->pSDLMutex);
    
    return 0;
}


//开始播放
int rt_pub_start(int *pPlayerHandle){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    
    pstRtplayer->s32Stop = 0;
	pstRtplayer->s32Exit = 0;
	
	//如果支持视频
	if(gs_SubsystemRefCount[RT_INIT_VIDEO]){
		//开启解码线程
	    if(pstRtplayer->s32QuitDecodeVideoThread){
	        pstRtplayer->pDecodeVideoThread = SDL_CreateThread(video_decodeThread, "decodeVideoThread", pstRtplayer);
	        if(NULL == pstRtplayer->pDecodeVideoThread){
				LOGE("[%s   %d]pDecodeVideoThread create failed\n",__FUNCTION__,__LINE__);
				return -1;
			}
	    }else{
	        LOGE("[%s   %d] pDecodeVideoThread is already start \n",__FUNCTION__,__LINE__);
	    }
	}else{
		LOGD("[%s   %d] video is disenable RT_INIT_VIDEO is not seted\n",__FUNCTION__,__LINE__);
	}

	//如果支持音频
	if(gs_SubsystemRefCount[RT_INIT_AUDIO]){

	     //开启解码线程
	    if(pstRtplayer->s32QuitDecodeAuidoThread){
	        pstRtplayer->pDecodeAudioThread = SDL_CreateThread(audio_decodeThread, "audio_decodeThread", pstRtplayer);
			if(NULL == pstRtplayer->pDecodeAudioThread){
				LOGE("[%s   %d]pDecodeAudioThread create failed\n",__FUNCTION__,__LINE__);
				return -1;
			}
	    }else{
	        LOGE("[%s   %d] pDecodeAudioThread is already start \n",__FUNCTION__,__LINE__);
	    }
	}else{
		LOGD("[%s   %d] audio is disenable RT_INIT_AUDIO is not seted\n",__FUNCTION__,__LINE__);
	}
	
    //如果数据源来源于ffmpeg，说明是单路播放，并且由ffmpeg获取数据
    //例如本地视频播放，rtsp点播,并且这里规定，uid必须为RT_DEFAUT_UID
    if(pstRtplayer->enGetDataType == RT_GET_DATA_FROME_FFMPEG){

		//获取视频数据的线程
		if(pstRtplayer->s32QuitReadDataThread){
			pstRtplayer->pReadDataThread = SDL_CreateThread(stream_readDataThread, "stream_readDataThread", pstRtplayer);
			if(NULL == pstRtplayer->pReadDataThread){
				LOGE("[%s   %d]pReadDataThread create failed\n",__FUNCTION__,__LINE__);
				return -1;
			}
			
		}else{
			LOGE("[%s   %d] pReadDataThread is already start \n",__FUNCTION__,__LINE__);
		}

		LOGD("[%s   %d] start and get data frome ffmpeg \n",__FUNCTION__,__LINE__);
    }else{
        LOGD("[%s   %d] start and get data frome other \n",__FUNCTION__,__LINE__);
    }
    
    return 0;
}

//停止播放
int rt_pub_stop(int *pPlayerhandle){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerhandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerhandle;
    //SDL_CondSignal(pstRtplayer->pSDLCond);

	
    if(pstRtplayer->pEventThread){
        
        //如果以线程分离的方式创建，不能执行SDL_WaitThread，由系统决定资源的回收
        LOGD("[%s   %d] SDL_WaitThread pEventThread\n",__FUNCTION__,__LINE__);
        
        //发送退出的命令
        SDL_Event event;
        event.type = RT_EVNET_EIXT;
        SDL_PushEvent(&event);
		
		SDL_Delay(50);
		
        pstRtplayer->s32QuitRefresh = 1;
        
        SDL_WaitThread(pstRtplayer->pEventThread, NULL);
		pstRtplayer->pEventThread = NULL;
    }
    
    if(pstRtplayer->pDecodeVideoThread){
		
        //如果以线程分离的方式创建，不能执行SDL_WaitThread，由系统决定资源的回收
        LOGD("[%s   %d] SDL_WaitThread pDecodeVideoThread\n",__FUNCTION__,__LINE__);
        pstRtplayer->s32QuitDecodeVideoThread = 1;
		//s32QuitDecodeVideoThread 值1后记得调用这个，要不有可能会退不出解码线程
		SDL_CondSignal(pstRtplayer->pSDLCond);
        SDL_WaitThread(pstRtplayer->pDecodeVideoThread, NULL);
		
        pstRtplayer->pDecodeVideoThread = NULL;
    }
    
    if(pstRtplayer->pDecodeAudioThread){
        
         //如果以线程分离的方式创建，不能执行SDL_WaitThread，由系统决定资源的回收
        LOGD("[%s   %d] SDL_WaitThread pDecodeAudioThread\n",__FUNCTION__,__LINE__);
        pstRtplayer->s32QuitDecodeAuidoThread = 1;
        SDL_WaitThread(pstRtplayer->pDecodeAudioThread, NULL);
        pstRtplayer->pDecodeAudioThread = NULL;
    }
	
	if(pstRtplayer->pReadDataThread){
         //如果以线程分离的方式创建，不能执行SDL_WaitThread，由系统决定资源的回收
        LOGD("[%s   %d] SDL_WaitThread pReadDataThread\n",__FUNCTION__,__LINE__);
        pstRtplayer->s32QuitReadDataThread = 1;
        SDL_WaitThread(pstRtplayer->pReadDataThread, NULL);
		pstRtplayer->pReadDataThread = NULL;
		
	}
    
    //发送退出的命令
    pstRtplayer->s32Stop = 1;
    
    pstRtplayer->s32UseIpcams = 0;
    
    relaseRtPlayer(pstRtplayer);
    
    LOGD("[%s   %d] stop\n",__FUNCTION__,__LINE__);
    SDL_Delay(150);
    
    return 0;
}



//退出
int rt_pub_exit(int *pPlayerhandle){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerhandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerhandle;
	gs_SubsystemRefCount[RT_INIT_AUDIO] = 0x0;
	gs_SubsystemRefCount[RT_INIT_VIDEO] = 0x0;
	memset( gs_SubsystemRefCount, 0x0, sizeof(gs_SubsystemRefCount));
	
	pstRtplayer->s32Exit = 1;
    //SDL_VideoQuit();
	//SDL_AudioQuit();
	SDL_Quit();
	
	LOGD("[%s   %d] SDL_Quit\n",__FUNCTION__,__LINE__);
	
    return 0;
}


//录制视频
//录制视频的时候pFileName 不能为null fps 也必须要准确
int rt_pub_start_rec(int *pPlayerHandle,const char*pDid,const char*pFileName,int fps,int s32SynTime){
	
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    
    if(NULL == stRtIpcamInfo){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	
    if(stRtIpcamInfo->stRtStreamOut){
		if(stRtIpcamInfo->stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
        	//为了安全，再次释放上一次的资源
        	if(stRtIpcamInfo->stRtStreamOut){
            	rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
            	free(stRtIpcamInfo->stRtStreamOut);
            	stRtIpcamInfo->stRtStreamOut = NULL;
            	LOGD("[%s   %d] stRtIpcamInfo->stRtStreamOut != NULL \n",__FUNCTION__,__LINE__);
        	}
        	LOGD("[%s   %d] rt_stream_out_init success  did =%s \n ",__FUNCTION__,__LINE__,stRtIpcamInfo->stRtParams->acDid);
		}
    }
	
	stRtIpcamInfo->stRtStreamOut = (RT_STRAM_OUT *)malloc(sizeof(RT_STRAM_OUT));
    if(NULL == stRtIpcamInfo->stRtStreamOut){
        LOGE("[%s   %d] (RT_STRAM_OUT *)malloc faile \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
	
    //初始化
    memset(stRtIpcamInfo->stRtStreamOut, 0, sizeof(RT_STRAM_OUT));

	//为了避免fps出错，这里做了如下处理
	if(fps <= 0){
		if(av_q2d(stRtIpcamInfo->stRtVideo->pVideoCodecCtx->time_base) != 0 &&
			pstRtplayer->enGetDataType == RT_GET_DATA_FROME_FFMPEG){

			//通过pVideoCodecCtx的time_base变量转为fps
			fps = 1/av_q2d(stRtIpcamInfo->stRtVideo->pVideoCodecCtx->time_base);
			LOGD("[%s   %d] fps is 0 and set to 1/pVideoCodecCtx->time_base =%d\n",__FUNCTION__,__LINE__,fps);
		}else{

			//使用自己统计的fps作为当前的fps
			fps = stRtIpcamInfo->stRtVideo->s32CountFps;
			LOGD("[%s   %d] fps is 0 and set to countFps =%d\n",__FUNCTION__,__LINE__,stRtIpcamInfo->stRtVideo->s32CountFps);
		}
	}
    stRtIpcamInfo->stRtVideo->s32Fps = fps;
	
	int audioType = RT_AUDIO_TYPE_PCM;
	//将音频参数指针赋值给stRtStreamOut，这样stRtStreamOut就可以使用里面的参数
    if(stRtIpcamInfo->stRtAudio && stRtIpcamInfo->stRtAudio->stRtAudioParams){
        stRtIpcamInfo->stRtStreamOut->stRtAudioParams = stRtIpcamInfo->stRtAudio->stRtAudioParams;
		audioType = stRtIpcamInfo->stRtAudio->enRtAudioType;
    }else{
		if(stRtIpcamInfo->stRtParams->enRtOpenAudioState ==RT_AUDIO_DISENABLE){
			audioType = RT_AUDIO_TYPE_NONE;
			LOGE("[%s	%d] audio is dis enable audioType set to RT_AUDIO_TYPE_NONE \n",__FUNCTION__,__LINE__);
		}else{
			LOGE("[%s	%d] stRtIpcamInfo->stRtAudio || stRtIpcamInfo->stRtAudio->stRtAudioParams == NULL\n",__FUNCTION__,__LINE__);
		}
	}
	
	//s32SynTime是以同步的方式保存数据，如果仅仅是保存视频，可以将标志位值为0
	//如果有音频，最好是同步的方式保存mp4
    int rec = rt_stream_out_init(stRtIpcamInfo->stRtStreamOut,audioType,
                                 stRtIpcamInfo->stRtVideo->s32PixelW,
                                 stRtIpcamInfo->stRtVideo->s32PixelH,
                                 stRtIpcamInfo->stRtVideo->s32Fps,s32SynTime>0?1:0);
	
    if(rec == -1){
        goto ERR_EXIT;
    }
	
	//开始保存数据，将保存标志位打开
    rt_stream_out_start(stRtIpcamInfo->stRtStreamOut, pFileName);
	
    return 0;
	
ERR_EXIT:
   	
    LOGE("[%s   %d] error \n",__FUNCTION__,__LINE__);
    if(NULL != stRtIpcamInfo->stRtStreamOut){
        rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
        free(stRtIpcamInfo->stRtStreamOut);
        stRtIpcamInfo->stRtStreamOut = NULL;
    }
    
    return -1;
}


//停止录像
int rt_pub_stop_rec(int *pPlayerHandle,const char*pDid){
	
	if(NULL == pPlayerHandle){
	   LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
	   return -1;
   	}
   	
   	RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
   	
   	RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
   	
   	if(NULL == stRtIpcamInfo){
	   LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
	   return -1;
   	}
	
	if(stRtIpcamInfo->stRtStreamOut){
        rt_stream_out_stop(stRtIpcamInfo->stRtStreamOut);
        free(stRtIpcamInfo->stRtStreamOut);
        stRtIpcamInfo->stRtStreamOut = NULL;
		return 0;
    }else{
        LOGD("[%s   %d] stream out faile\n",__FUNCTION__,__LINE__);
		return -1;
    }
	
	return 0;
}


//这里打开音频是值要不要播放，音频一直都有解码
int rt_pub_audio_open(int *pPlayerHandle,const char*pDid ,int openState){
    
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    if(NULL == stRtIpcamInfo){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    if(stRtIpcamInfo->stRtAudio == NULL){
        LOGE("[%s   %d] stRtAudio == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    stRtIpcamInfo->stRtAudio->s32OpenAudio = (openState == 0 ? 0 : 1);
	
	if(!stRtIpcamInfo->stRtParams->s32BlockAudioDecodeData){
		if(stRtIpcamInfo->stRtAudio->s32OpenAudio){
			SDL_PauseAudio(0);
	        LOGD("[%s   %d] Audio play\n",__FUNCTION__,__LINE__);
		}else{
			SDL_PauseAudio(1);
	        LOGD("[%s   %d] Audio stop\n",__FUNCTION__,__LINE__);
		}
	}

    //LOGD("[%s   %d] s32OpenAudio =%d \n",__FUNCTION__,__LINE__,stRtIpcamInfo->stRtAudio->s32OpenAudio);
    
    return 0;
}


/**
获取常用的参数，所有对外提供的的参数都是通过RT_NORMAL_PARAMS这个结构体获取
比如要流量的统计，当前缓存的个数等
*/
int rt_pub_get_normal_params(int *pPlayerHandle,const char*pDid,RT_NORMAL_PARAMS *stRtNormalParams){
	
	if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }

	if(!stRtNormalParams){
		LOGE("[%s   %d] stRtNormalParams is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
	if(!pstRtplayer->s32IsAlreadyShow || pstRtplayer->s32Stop){
		LOGD("[%s   %d] video is not start show or is stop\n",__FUNCTION__,__LINE__);
		return -1;
	}

	RT_IPCAM_INFO *stRtIpcamInfo;
	if(pDid == NULL){
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, RT_DEFAUT_UID);
	}else{
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
	}

	if(!stRtIpcamInfo){
		LOGE("[%s   %d] stRtIpcamInfo is NULL\n",__FUNCTION__,__LINE__);
		return -1;
	}

	
    if(stRtIpcamInfo->stRtStreamOut){
        stRtNormalParams->s32RevFrameCount = stRtIpcamInfo->stRtStreamOut->s32VideoWriteFrameCount;
    }else{
		//LOGE("[%s   %d] stRtIpcamInfo or stRtIpcamInfo->stRtStreamOut is NULL\n",__FUNCTION__,__LINE__);
	}

	RT_VIDEO *stRtVideo = stRtIpcamInfo->stRtVideo;
	if(stRtVideo){
		
		stRtNormalParams->s32DisplayTraffic = stRtVideo->s32DisplayTraffic;
		stRtNormalParams->s32DecodeTraffic  = stRtVideo->s32DecodeTraffic;
		stRtNormalParams->s32ReceiveTraffic = stRtVideo->s32ReceiveTraffic;

		stRtNormalParams->s32TotalFramePts  = stRtVideo->s32TotalFramePts;

		/*
		当前队列中有的个数，即队列中缓存的个数
		*/
		if(stRtIpcamInfo->stRtVideo->pVideoPacketQueue){
			stRtNormalParams->s32CacheFrameNum  = stRtVideo->pVideoPacketQueue->nb_packets;
		}

		/*
		内部统计的fps
		*/
		stRtNormalParams->s32CountPts = stRtVideo->s32CountFps;

		/**
		视频播放的进度
		*/
		stRtNormalParams->s64VideoClock = stRtVideo->s64VideoClock;

		/*
		暂停状态
		*/
		stRtNormalParams->s8VideoIsPuase = pstRtplayer->s8VideoPause;
	}else{
		LOGE("[%s   %d] stRtIpcamInfo->stRtVideo is NULL\n",__FUNCTION__,__LINE__);
	}


	
    return 0;
}



/*
设置常用的参数，所有参数的设置都是通过RT_NORMAL_PARAMS这个结构体进行设置
比如，设置缓存的个数等
*/
int rt_pub_set_normal_params(int *pPlayerHandle,const char*pDid,RT_NORMAL_PARAMS *stRtNormalParams,int paramFlags){
	if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	
	if(!stRtNormalParams){
		LOGE("[%s   %d] stRtNormalParams is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
	if(!pstRtplayer->s32IsAlreadyShow || pstRtplayer->s32Stop){
		LOGD("[%s   %d] video is not start show or is stop\n",__FUNCTION__,__LINE__);
		return -1;
	}

	RT_IPCAM_INFO *stRtIpcamInfo = NULL;
	if(pDid == NULL){
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, RT_DEFAUT_UID);
	}else{
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
	}

	if(!stRtIpcamInfo){
		LOGE("[%s   %d] stRtIpcamInfo is NULL\n",__FUNCTION__,__LINE__);
		return -1;
	}

	RT_VIDEO *stRtVideo = stRtIpcamInfo->stRtVideo;
	if(stRtVideo){
		 if(paramFlags & RT_PARAMS_CacheFrameNum){
		 	stRtVideo->s32CacheFrameNum = stRtNormalParams->s32CacheFrameNum;
		 }
		
		 if(paramFlags & RT_PARAMS_FilterBadPacket){
			stRtVideo->s8IsFilterBadPacket = stRtNormalParams->s8IsFilterBadPacket;
			LOGD("[%s   %d] s8IsFileterBadPacket =%d \n",__FUNCTION__,__LINE__,stRtVideo->s8IsFilterBadPacket);
		 }
		 
		 if(paramFlags & RT_PARAMS_FilterBadFrame){
			stRtVideo->s8IsFilterBadFrame = stRtNormalParams->s8IsFilterBadFrame;
			LOGD("[%s   %d] s8IsFilterBadFrame =%d \n",__FUNCTION__,__LINE__,stRtVideo->s8IsFilterBadFrame);
		 }

		 if(paramFlags & RT_PARAMS_VideoIsPause){
			pstRtplayer->s8VideoPause = stRtNormalParams->s8VideoIsPuase;
		 	LOGD("[%s   %d] s8VideoPause =%d \n",__FUNCTION__,__LINE__,pstRtplayer->s8VideoPause);
		 }
	}else{
		LOGE("[%s   %d] stRtIpcamInfo->stRtVideo is NULL\n",__FUNCTION__,__LINE__);
	}
	
	return 0;
}


//添加外部提供视频数据,time要记得转为毫秒
int rt_pub_add_video_h264(int *pPlayerHandle,const char *pDid,
                     unsigned char * data,int len,double time,
                     int keyFrame)
{
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    
    if(pstRtplayer->s32Stop || pstRtplayer->s32QuitDecodeVideoThread){
        LOGD("[%s   %d] s32Stop =%d s32QuitDecodeVideoThread=%d\n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop,pstRtplayer->s32QuitDecodeVideoThread);
        return -1;
    }
    
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
	RT_VIDEO *stRtVideo = stRtIpcamInfo->stRtVideo;
	RT_STRAM_OUT *stRtStreamOut = stRtIpcamInfo->stRtStreamOut;

	/*
	这里尝试的去统计一下fps，计算两个I帧之间p帧的个数，
	这种方式对gob跟fps相同的情况下适用，统计方式有待修正，暂时这样写
	*/
	static int temp = 0;
	if(keyFrame){
		if(temp != 0){
			if( temp >10 && temp < 40){
				stRtVideo->s32CountFps = temp;
				//LOGD("[%s   %d] countFps=%d\n",__FUNCTION__,__LINE__,temp);
			}
		}
		temp = 1;
	}else if(temp >=1 && !keyFrame){
		temp ++;
	}
	
	
    if(stRtIpcamInfo !=NULL && stRtVideo!= NULL){
        if(stRtVideo->pVideoPacketQueue){
            
            AVPacket pkt;
            av_init_packet(&pkt);
            pkt.data = data;
            pkt.size = len;
            pkt.flags = keyFrame;
            pkt.stream_index = AVMEDIA_TYPE_VIDEO;
			
			//为了让时间从0开始计算
			if(stRtVideo->s64FirstVideoTimestamp <= 0 ){
				stRtVideo->s64FirstVideoTimestamp = time;
			}
			//转换为秒
			double pts = (time - stRtVideo->s64FirstVideoTimestamp)/1000;
            
            if(stRtVideo->pVideoStream){
                pkt.pts = pts * 1/av_q2d(stRtIpcamInfo->stRtVideo->pVideoStream->time_base);
            }else{
                pkt.pts = pts * 1/av_q2d((AVRational){1, 90000});
            }
            
            //pkt.stream_index = stRtIpcamInfo->stRtVideo->s32VideoStreamIndex;
            
            //保存视频数据
            if(stRtStreamOut != NULL && stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
                rt_stream_out_write_video_h264(stRtStreamOut,&pkt);
            }
            
            //如果缓存大于最大数目，则清空队列
            if(stRtVideo->enLiveType == RT_LIVE_TYPE_LIVE && 
				stRtVideo->pVideoPacketQueue->nb_packets>RT_MAX_QUEUE_SIZE){
				
                rt_queue_clear(stRtVideo->pVideoPacketQueue);
                LOGD("[%s   %d] queue size too max try to clean queue \n",__FUNCTION__,__LINE__);
				
            }
			
			//每隔50次打印，方便查看log
			static int temp = 0;
			temp++;
        	if(temp % 200 ==0){
				LOGD("[%s   %d] video packets size = %d \n",__FUNCTION__,__LINE__,stRtVideo->pVideoPacketQueue->nb_packets);
        	}

			//记录接收到的数据包总量
			stRtVideo->s32ReceiveTraffic+=len;
			
            rt_queue_put(stRtVideo->pVideoPacketQueue, &pkt);
            
        }
		
    }else{
        LOGE("[%s   %d] add video error \n",__FUNCTION__,__LINE__);
    }
    
    return 0;
}


//添加外部提供视频数据
int rt_pub_add_video_h265(int *pPlayerHandle,const char *pDid,
                     unsigned char * data,int len,double time,
                     int keyFrame)
{	
	
	return 0;
}


//添加外部提供的音频数据,time为毫秒,因为添加的aac数据是按buf的长度返回
//所以，buf中的数据有可能是多帧，有可能是少帧等等，处理起来比较困难
int rt_pub_add_audio_aac(int *pPlayerHandle,const char *pDid,
                     unsigned char * data,int len,double time)
{
    
    //LOG_PRINT_HEX(data, 0, 30);
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    if(pstRtplayer->s32Stop|| pstRtplayer->s32QuitDecodeAuidoThread){
        LOGD("[%s   %d] s32Stop =%d s32QuitDecodeAuidoThread=%d\n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop,pstRtplayer->s32QuitDecodeAuidoThread);
        return -1;
    }
	
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    if(stRtIpcamInfo == NULL){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    RT_AUDIO *stRtAudio =stRtIpcamInfo->stRtAudio;
    if(stRtAudio){

		stRtAudio->enRtAudioType = RT_AUDIO_TYPE_AAC;
        if(stRtAudio->pAudioBuf){
            
            if(stRtAudio->s32AudioBufSize<=0){//如果音频长度小于=0，说明里面没有数据，直接拷贝
                if(len < RT_AUDIO_INBUF_SIZE){
                    memcpy(stRtAudio->pAudioBuf, data, len);
                    stRtAudio->s32AudioBufSize = len;
                }else{
                    stRtAudio->s32AudioBufSize = 0;
                    LOGE("[%s   %d] len =%d > maxSize =%d \n",__FUNCTION__,__LINE__,len,RT_AUDIO_INBUF_SIZE);
                    return -1;
                }
            }else{
                if((stRtAudio->s32AudioBufSize + len) < RT_AUDIO_INBUF_SIZE){
                    //如果音频长度不为0，需要将数据往前移，并且把回调的数据添加到尾部
                    memmove(stRtAudio->pAudioBuf, stRtAudio->pAudioBufBeginPos, stRtAudio->s32AudioBufSize);
                    memcpy(stRtAudio->pAudioBuf + stRtAudio->s32AudioBufSize , data, len);
                    stRtAudio->s32AudioBufSize += len;
                }else{
                    LOGE("[%s   %d] s32AudioBufSize =%d + len =%d > maxSize =%d\n",__FUNCTION__,__LINE__,stRtAudio->s32AudioBufSize,len,RT_AUDIO_INBUF_SIZE);
                    
                    if(len < RT_AUDIO_INBUF_SIZE){
                        memcpy(stRtAudio->pAudioBuf, data, len);
                        stRtAudio->s32AudioBufSize = len;
                    }else{
                        LOGE("[%s   %d] len =%d > maxSize =%d \n",__FUNCTION__,__LINE__,len,RT_AUDIO_INBUF_SIZE);
                        stRtAudio->s32AudioBufSize = 0;
                        return -1;
                    }
                }
            }
            stRtAudio->pAudioBufBeginPos = stRtAudio->pAudioBuf;
            
        }else{
            LOGE("[%s   %d]  pAudioBuf == NULL\n",__FUNCTION__,__LINE__);
            return -1;
        }
		
       
        if(stRtAudio->pstAudioPacketQueue){
            
            //这里增加了一个死循环，为了防止多帧同时返回的情况，造成音频延迟
            while (1) {
				
				if(pstRtplayer->s32Stop || pstRtplayer->s32QuitDecodeAuidoThread){
					LOGD("[%s	%d] s32Stop =%d s32QuitDecodeAuidoThread=%d\n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop,pstRtplayer->s32QuitDecodeAuidoThread);
					return -1;
				}

				if(stRtAudio->s32AudioBufSize <= 0){
					return -1;
				}
				
                
                //重缓存中获取一帧的数据
                int size = 0;
                int offSet = 0;
                uint8_t *input_data = stRtAudio->pAudioBufBeginPos;
                memset(pstRtplayer->acAacFrame, 0, RT_MAX_AAC_FRAME_SIZE);
                int ret = getADTSFrame(input_data,stRtAudio->s32AudioBufSize, pstRtplayer->acAacFrame, &size,&offSet);
                if(ret == -1){
                    //说明：1。找不到aac头，2。buf的长度小于7
                    LOGE("[%s   %d] getADTSFrame error offset = %d \n",__FUNCTION__,__LINE__,offSet);
                    
                    //如果偏移量大于1，说明是buf里面的数据没有aac的头
                    if(offSet >=1){
                        
                        if(stRtAudio->pAudioBufBeginPos + offSet < stRtAudio->pAudioBuf + RT_AUDIO_INBUF_SIZE){
                            //这里直接跳过这部分数据，这样下次查询的时候就不用再次查询，提高效率
                            stRtAudio->pAudioBufBeginPos += offSet;
                            stRtAudio->s32AudioBufSize -= offSet;
                        }else{
                            LOGE("[%s   %d] pAudioBufBeginPos + offSet =%s > pAudioBuf + RT_AUDIO_INBUF_SIZE =%s\n",__FUNCTION__,
                                 __LINE__,
                                 (stRtAudio->pAudioBufBeginPos + offSet),
                                 (stRtAudio->pAudioBuf + RT_AUDIO_INBUF_SIZE));
                            
                        }
                    }
                    return -1;
                }else if(ret == 1){
                    //不够一帧数据，说明已经找到头，但是帧的数据不完整，需要等待下一帧的数据补全
                    //LOGE("[%s   %d] not enough a frame \n",__FUNCTION__,__LINE__);
                    
                    return -1;
                }else if(ret == 2){
                	//说明解析头出错，得到的buf长度大于指定的最大值1024
                    LOGE("[%s   %d] s32AudioBufSize =%d \n",__FUNCTION__,__LINE__,stRtAudio->s32AudioBufSize);
                    stRtAudio->s32AudioBufSize = 0;
                    return -1;
                }
                
                if(pstRtplayer->s32Stop || pstRtplayer->s32QuitDecodeAuidoThread){
                    LOGD("[%s   %d] s32Stop \n",__FUNCTION__,__LINE__);
                    return -1;
                }

				
#if 1  			
                //通过读取aac头的方式获取对应的信息
                char profile_str[10]={0};
                char frequence_str[10]={0};
                
                unsigned char profile=pstRtplayer->acAacFrame[2]&0xC0;
                profile=profile>>6;
                switch(profile){
                    case 0: sprintf(profile_str,"Main");break;
                    case 1: sprintf(profile_str,"LC");break;
                    case 2: sprintf(profile_str,"SSR");break;
                    default:sprintf(profile_str,"unknown");break;
                }
                
                //LOGD("[%s   %d] profile_str =%s \n",__FUNCTION__,__LINE__,profile_str);
                unsigned char sampling_frequency_index=pstRtplayer->acAacFrame[2]&0x3C;
                sampling_frequency_index=sampling_frequency_index>>2;
                int sample_rate = 0;
                switch(sampling_frequency_index){
                    case 0: sprintf(frequence_str,"96000Hz");sample_rate=96000;break;
                    case 1: sprintf(frequence_str,"88200Hz");sample_rate=88200;break;
                    case 2: sprintf(frequence_str,"64000Hz");sample_rate=64000;break;
                    case 3: sprintf(frequence_str,"48000Hz");sample_rate=48000;break;
                    case 4: sprintf(frequence_str,"44100Hz");sample_rate=44100;break;
                    case 5: sprintf(frequence_str,"32000Hz");sample_rate=32000;break;
                    case 6: sprintf(frequence_str,"24000Hz");sample_rate=24000;break;
                    case 7: sprintf(frequence_str,"22050Hz");sample_rate=22050;break;
                    case 8: sprintf(frequence_str,"16000Hz");sample_rate=16000;break;
                    case 9: sprintf(frequence_str,"12000Hz");sample_rate=12000;break;
                    case 10: sprintf(frequence_str,"11025Hz");sample_rate=11025;break;
                    case 11: sprintf(frequence_str,"8000Hz");sample_rate=8000;break;  
                    default:sprintf(frequence_str,"unknown");sample_rate=-1;break;  
                }
                
                //LOGD("[%s   %d] frequence_str =%s \n",__FUNCTION__,__LINE__,frequence_str);
                
                unsigned char channel_configuration = (pstRtplayer->acAacFrame[2] & 0x01)>>2;
                channel_configuration |= (pstRtplayer->acAacFrame[3] & 0xC0) >>6;

				//这样之所以在这里也赋值是因为播放视频的时候未必解码音频数据(之前的写法，现在只要有音频都会送去解码)，如果不播放声音
				//stRtAudio->stRtAudioParams里面的参数是得不到对应的值的，这个时候录像就会有问题
				//为了安全这里也做赋值
                if(stRtAudio->stRtAudioParams){
                    if(stRtAudio->stRtAudioParams->s32Channel == -1){
                        stRtAudio->stRtAudioParams->s32Channel = channel_configuration;
                        LOGD("[%s   %d] s32Channel=%d \n",__FUNCTION__,__LINE__,channel_configuration);
                    }
                    
                    if(stRtAudio->stRtAudioParams->s32Profile == -1){
                        stRtAudio->stRtAudioParams->s32Profile = profile;
                        LOGD("[%s   %d] s32Profile=%d \n",__FUNCTION__,__LINE__,profile);
                    }
                    
                    if(stRtAudio->stRtAudioParams->s32Sample_rate == -1){
                        stRtAudio->stRtAudioParams->s32Sample_rate = sample_rate;
                        LOGD("[%s   %d] s32Sample_rate=%d \n",__FUNCTION__,__LINE__,sample_rate);
                    }
                }
                
#endif
                if(offSet>=1){
                    LOGE("[%s   %d] offSet = %d \n",__FUNCTION__,__LINE__,offSet);
                }
                stRtAudio->s32AudioBufSize -= (offSet + size);
				
				//为了防止越界%RT_AUDIO_INBUF_SIZE
                stRtAudio->pAudioBufBeginPos += ((offSet + size)%RT_AUDIO_INBUF_SIZE);
                
                AVPacket pkt;
                av_init_packet(&pkt);
                pkt.data = pstRtplayer->acAacFrame;
                pkt.size = size;
                pkt.stream_index = AVMEDIA_TYPE_AUDIO;
				
#if 1
				//为了让时间从0开始计算
				if(stRtAudio->s64FirstAudioTimestamp <= 0 ){
					stRtAudio->s64FirstAudioTimestamp = time;
				}
				//转换为秒
				double pts = (time - stRtAudio->s64FirstAudioTimestamp)/1000;
#else
				
				double pts =(stRtAudio->s34FrameCount++) * (size * 1000 / stRtAudio->stRtAudioParams->s32Sample_rate);
				LOGD("[%s   %d] pts= %f s34FrameCount=%d\n",__FUNCTION__,__LINE__,pts,stRtAudio->s34FrameCount);
				
#endif
				
                if(stRtAudio->pAudioStream){
                    pkt.pts = pts * 1/av_q2d(stRtAudio->pAudioStream->time_base);
                }else{
                    pkt.pts = pts * 1/av_q2d((AVRational){1, stRtAudio->stRtAudioParams->s32Sample_rate});
                }
                
                //保存视频数据
                if(stRtIpcamInfo->stRtStreamOut &&
                   stRtIpcamInfo->stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
                    rt_stream_out_write_audio_aac(stRtIpcamInfo->stRtStreamOut,&pkt);
                }
                
				
                //如果缓存大于最大数目，则清空队列(直播才)
                if(stRtIpcamInfo->stRtVideo->enLiveType == RT_LIVE_TYPE_LIVE && 
					stRtAudio->pstAudioPacketQueue->nb_packets>RT_MAX_AUDIO_QUEUE_SIZE){
                    rt_queue_clear(stRtAudio->pstAudioPacketQueue);
                    LOGD("[%s   %d] queue size too max try to clean queue A\n",__FUNCTION__,__LINE__);
                }

				static int temp = 0;
				temp++;
				//每隔50次打印，方便查看log
				if( temp % 200 ==0){
					LOGD("[%s   %d] audio packets size = %d \n",__FUNCTION__,__LINE__,stRtAudio->pstAudioPacketQueue->nb_packets);
				}
                
                rt_queue_put(stRtAudio->pstAudioPacketQueue,&pkt);
                
            }
            
        }else{
            LOGE("[%s   %d] stRtAudio == NULL\n",__FUNCTION__,__LINE__);
            return -1;
        }
        
    }else{
        LOGE("[%s   %d] add audio error \n",__FUNCTION__,__LINE__);
    }
    
    return 0;
}

//添加外部提供的音频数据
int rt_pub_add_audio_pcm(int *pPlayerHandle,const char *pDid,
                     unsigned char * data,int len,double time)
{
	//LOGD("[%s   %d] size=%d\n",__FUNCTION__,__LINE__,len);
	//LOG_PRINT_HEX(data, 0, 30);
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
    if(pstRtplayer->s32Stop || pstRtplayer->s32QuitDecodeAuidoThread){
        LOGD("[%s   %d] s32Stop =%d s32QuitDecodeAuidoThread=%d\n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop,pstRtplayer->s32QuitDecodeAuidoThread);
        return -1;
    }
	
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    if(stRtIpcamInfo == NULL){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    RT_AUDIO *stRtAudio =stRtIpcamInfo->stRtAudio;
    if(stRtAudio){
		
		stRtAudio->enRtAudioType = RT_AUDIO_TYPE_PCM;

		//这里之所以要将数据拷贝到大数组中是因为，有可能设备端返回的数据并不是一帧的pcm数据
		//需要存储再buf中，然后再一帧一帧的数据去存储到队列中
		if(stRtAudio->pAudioBuf){
            
            if(stRtAudio->s32AudioBufSize<=0){//如果音频长度小于=0，说明里面没有数据，直接拷贝
                if(len < RT_AUDIO_INBUF_SIZE){
                    memcpy(stRtAudio->pAudioBuf, data, len);
                    stRtAudio->s32AudioBufSize = len;
                }else{
                    stRtAudio->s32AudioBufSize = 0;
                    LOGE("[%s   %d] len =%d > maxSize =%d \n",__FUNCTION__,__LINE__,len,RT_AUDIO_INBUF_SIZE);
                    return -1;
                }
            }else{
                if((stRtAudio->s32AudioBufSize + len) < RT_AUDIO_INBUF_SIZE){
                    //如果音频长度不为0，需要将数据往前移，并且把回调的数据添加到尾部
                    memmove(stRtAudio->pAudioBuf, stRtAudio->pAudioBufBeginPos, stRtAudio->s32AudioBufSize);
                    memcpy(stRtAudio->pAudioBuf + stRtAudio->s32AudioBufSize , data, len);
                    stRtAudio->s32AudioBufSize += len;
                }else{
                    LOGE("[%s   %d] s32AudioBufSize =%d + len =%d > maxSize =%d\n",__FUNCTION__,__LINE__,stRtAudio->s32AudioBufSize,len,RT_AUDIO_INBUF_SIZE);
                    
                    if(len < RT_AUDIO_INBUF_SIZE){
                        memcpy(stRtAudio->pAudioBuf, data, len);
                        stRtAudio->s32AudioBufSize = len;
                    }else{
                        LOGE("[%s   %d] len =%d > maxSize =%d \n",__FUNCTION__,__LINE__,len,RT_AUDIO_INBUF_SIZE);
                        stRtAudio->s32AudioBufSize = 0;
                        return -1;
                    }
                }
            }
            stRtAudio->pAudioBufBeginPos = stRtAudio->pAudioBuf;
            
        }else{
            LOGE("[%s   %d]  pAudioBuf == NULL\n",__FUNCTION__,__LINE__);
            return -1;
        }

		if(stRtAudio->pstAudioPacketQueue){

			int s32PcmToAacSize = stRtAudio->s32PcmToAacSize;
			
			while(1){
				
				if(stRtAudio->s32AudioBufSize < s32PcmToAacSize){
					return -1;
				}
				
				if(s32PcmToAacSize > RT_MAX_AAC_FRAME_SIZE){
					stRtAudio->s32AudioBufSize = 0;
					LOGE("[%s   %d] s32PcmToAacSize =%d > RT_MAX_AAC_FRAME_SIZE=%d\n",__FUNCTION__,__LINE__,s32PcmToAacSize,RT_MAX_AAC_FRAME_SIZE);
					return -1;
				}
				memcpy(pstRtplayer->acAacFrame,stRtAudio->pAudioBufBeginPos,s32PcmToAacSize);
				stRtAudio->s32AudioBufSize -= s32PcmToAacSize;
				stRtAudio->pAudioBufBeginPos += (s32PcmToAacSize % RT_AUDIO_INBUF_SIZE);
				
				AVPacket pkt;
		        av_init_packet(&pkt);
		        pkt.data = pstRtplayer->acAacFrame;
		        pkt.size = s32PcmToAacSize;
		        pkt.stream_index = AVMEDIA_TYPE_AUDIO;
				
				//为了让时间从0开始计算
				if(stRtAudio->s64FirstAudioTimestamp <= 0 ){
					stRtAudio->s64FirstAudioTimestamp = time;
				}
				//转换为秒
				double pts = (time - stRtAudio->s64FirstAudioTimestamp)/1000;
				
		        if(stRtAudio->pAudioStream){
		            pkt.pts = pts * 1/av_q2d(stRtAudio->pAudioStream->time_base);
		        }else{
		            pkt.pts = pts * 1/av_q2d((AVRational){1, stRtAudio->stRtAudioParams->s32Sample_rate});
		        }
				
                //保存视频数据
                if(stRtIpcamInfo->stRtStreamOut &&
                   stRtIpcamInfo->stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
                    rt_stream_out_write_audio_pcm(stRtIpcamInfo->stRtStreamOut,&pkt);
                }
                
		        //如果缓存大于最大数目，则清空队列(直播才)
		        if(stRtIpcamInfo->stRtVideo->enLiveType == RT_LIVE_TYPE_LIVE && 
					stRtAudio->pstAudioPacketQueue->nb_packets>RT_MAX_AUDIO_QUEUE_SIZE){
					
		            rt_queue_clear(stRtAudio->pstAudioPacketQueue);
		            LOGD("[%s   %d] queue size too max try to clean queue A\n",__FUNCTION__,__LINE__);
					
		        }

				//每隔50次打印，方便查看log
				static int temp = 0;
				temp++;
 				if(temp % 200 ==0){
					LOGD("[%s   %d] audio packets size = %d \n",__FUNCTION__,__LINE__,stRtAudio->pstAudioPacketQueue->nb_packets);
				}
		        
		        rt_queue_put(stRtAudio->pstAudioPacketQueue,&pkt);
				
			}
		}
    }
	return 0;
}


/**
拍照将图标保存为jpg格式
width <= 0 或者 height <= 0的时候，使用默认的宽高，即源视频的宽高
*/
int rt_pub_take_jpeg(int *pPlayerHandle ,const char *pDid,const char*filePath,int width,int height){
	if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
	//取出解码好后的数据
    RT_PICTURE *stRtPicture = &pstRtplayer->stRtPictures[pstRtplayer->s32PictureRIndex];
	
	if(filePath == NULL){
		LOGE("[%s   %d] filePath is NULL\n",__FUNCTION__,__LINE__);
		return -1;
	}

	if(stRtPicture->pDecodeFrame == NULL){
		LOGE("[%s   %d] pDecodeFrame is NULL\n",__FUNCTION__,__LINE__);
		return -1;
	}
	RT_IPCAM_INFO *stRtIpcamInfo = NULL;

	if(NULL == pDid){
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,pDid);
	}else{
		stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,RT_DEFAUT_UID);
	}
    if(stRtIpcamInfo == NULL){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    RT_VIDEO*stRtVideo =stRtIpcamInfo->stRtVideo;
	if(stRtVideo == NULL){
	    LOGE("[%s   %d] stRtVideo == NULL \n",__FUNCTION__,__LINE__);
	    return -1;
	}
	
	if(width <= 0 || height <= 0){
		return rt_stream_out_write_pic_jpeg(stRtPicture->pDecodeFrame,stRtVideo->s32PixelW,stRtVideo->s32PixelH,stRtVideo->s32PixelW,stRtVideo->s32PixelH,filePath);
	}else{
		return rt_stream_out_write_pic_jpeg(stRtPicture->pDecodeFrame,stRtVideo->s32PixelW,stRtVideo->s32PixelH,width,height,filePath);
	}
}


/**
清空队列
type: 0:清空视频队列   1:清空音频队列  其他:清空所有
*/
int rt_pub_queue_clear(int *pPlayerHandle,const char *pDid,int type){
	 //LOG_PRINT_HEX(data, 0, 30);
    if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
	
    if(pstRtplayer->s32Stop){
        LOGD("[%s   %d] s32Stop =%d \n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop);
        return -1;
    }
	
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    if(stRtIpcamInfo == NULL){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }

	char isClearAudio = 0;
	char isClearVideo = 0;
	if(type != 0 && type != 1){ //清空所有
		isClearAudio = 1;
		isClearVideo = 1;
	}else if(type == 0){
		isClearVideo = 1;
	}else if(type == 1){
		isClearAudio = 1;
	}

	
	/**
	清空音频队列
	清空音频缓存，当用户觉得当前音频延迟过大的时候，可以清空队列，用最新的音频进行播放
	*/
	if(isClearAudio == 1){
	    RT_AUDIO *stRtAudio =stRtIpcamInfo->stRtAudio;
		if(stRtAudio && stRtAudio->pstAudioPacketQueue){
			rt_queue_clear(stRtAudio->pstAudioPacketQueue);
			
		}else{
			LOGE("[%s   %d] stRtAudio or stRtAudio->pstAudioPacketQueue is NULL \n",__FUNCTION__,__LINE__);
		}
		
	}

	
	/*
	清空视频队列
	*/
	if(isClearVideo == 1){
		 RT_VIDEO*stRtVideo=stRtIpcamInfo->stRtVideo;
		if(stRtVideo && stRtVideo->pVideoPacketQueue){
			rt_queue_clear(stRtVideo->pVideoPacketQueue);
		}else{
			LOGE("[%s   %d] stRtVideo or stRtVideo->pVideoPacketQueue is NULL \n",__FUNCTION__,__LINE__);
		}
	}
	return 0;
	
}


/**
* 获取队列的长度
* type = 1;视频
* type = 0;音频
*/
int rt_pub_queue_size(int *pPlayerHandle,const char *pDid,int type){
	if(NULL == pPlayerHandle){
        LOGE("[%s   %d] pPlayerHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerHandle;
	
    if(pstRtplayer->s32Stop){
        LOGD("[%s   %d] s32Stop =%d \n",__FUNCTION__,__LINE__,pstRtplayer->s32Stop);
        return -1;
    }
	
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer, pDid);
    if(stRtIpcamInfo == NULL){
        LOGE("[%s   %d] stRtIpcamInfo == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }

	/*
	音频队列
	获取音频队列的长度，用户可以通过这个方法来获取当前音频队列的长度,提供这两个函数，是考虑到
	使用SDL播放的过程中，往往出现音频延迟越来越严重，可以通过判断音频队列个数大于某个值后清空队列
	从而纠正音频延迟，即使是不用SDL来进行播放，java上层纠正音频延迟也是这样做的
	*/
	if(type == 1){
	    RT_AUDIO *stRtAudio =stRtIpcamInfo->stRtAudio;
		if(stRtAudio && stRtAudio->pstAudioPacketQueue){
			return stRtAudio->pstAudioPacketQueue->nb_packets;
		}else{
			LOGE("[%s   %d] stRtAudio or stRtAudio->pstAudioPacketQueue is NULL \n",__FUNCTION__,__LINE__);
		}

	/*
	视频类型
	*/
	}else if(type == 0){
		 RT_VIDEO*stRtVideo=stRtIpcamInfo->stRtVideo;
		if(stRtVideo && stRtVideo->pVideoPacketQueue){
			return stRtVideo->pVideoPacketQueue->nb_packets;
		}else{
			LOGE("[%s   %d] stRtVideo or stRtVideo->pVideoPacketQueue is NULL \n",__FUNCTION__,__LINE__);
		}
	}
	
	return 0;
	
}


//pts单位为秒
int rt_pub_video_seekto(int *pPlayerhandle,const char *pDid,int pts){
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    if(NULL == pPlayerhandle){
        LOGE("[%s   %d] pPlayerhandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    RT_PLAYER *pstRtplayer = (RT_PLAYER *)pPlayerhandle;
    
    RT_IPCAM_INFO *stRtIpcamInfo = getIpcamInfoByDid(pstRtplayer,pDid);
    
    if(NULL != stRtIpcamInfo){
        stRtIpcamInfo->stRtStreamIn->s64SeekPosition = pts;
        LOGE("[%s   %d] seekto pts == %d second(秒) \n",__FUNCTION__,__LINE__,pts);
    }else{
        LOGE("[%s   %d] stRtIpcamInfo == null \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    return 0;
}


