//
//  Rt_pub_def.h
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/16.
//  Copyright ? 2017年 杨青远. All rights reserved.
//

#ifndef Rt_pub_def_h
#define Rt_pub_def_h

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

//防止cpp调用ffmpeg出错
#ifndef INT64_C
#define INT64_C
#define UINT64_C
#endif


#ifdef __cplusplus
extern "C"{
#endif /* __plusplus*/

#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/time.h"
#include "SDL.h"
#include "libavutil/imgutils.h"

#include "Rt_queue.h"
#include "Rt_app_log.h"

#include "mp4v2/platform.h"
#include "mp4v2/mp4v2.h"
#include "mp4v2/general.h"


#ifdef ANDROID
#include <jni.h>
#endif

//sdk版本号
#define RTP2P_VERSION "0.1.03"

#define RT_TIME_BASE AV_TIME_BASE


#define AV_SYNC_THRESHOLD 0.01
#define AV_NOSYNC_THRESHOLD 10.0
/* no AV sync correction is done if below the minimum AV sync threshold */
#define AV_SYNC_THRESHOLD_MIN 0.03
/* AV sync correction is done if above the maximum AV sync threshold */
#define AV_SYNC_THRESHOLD_MAX 0.1


/*
rt_pub_init初始化的时候，需要指定使用的模块，这个是视频模块
*/
#define RT_INIT_VIDEO 0x000000001u

/*
rt_pub_init初始化的时候，需要指定使用的模块，这个是音频模块
*/
#define RT_INIT_AUDIO 0x000000010u

/*
rt_pub_init初始化的时候，需要指定使用的模块，这个是所有模块
*/
#define RT_INIT_ALL (RT_INIT_VIDEO | RT_INIT_AUDIO)

/*
 同时播放最大的ipc数目
 */
#define RT_MAX_IPCAM_SIZE 4

/*
  缓存解码后的数据（rgb）最大数目
*/
#define RT_VIDEO_PICTURE_QUEUE_SIZE 4

/*
 视频队列最大长度
*/
#define RT_MAX_QUEUE_SIZE 100

/*
 音频队列最大长度
*/
#define RT_MAX_AUDIO_QUEUE_SIZE 100 

/*
 默认uid,播放本地文件就必须使用默认的uid
*/
#define RT_DEFAUT_UID "defaultUid"

/*
 一帧aac数据的最大值
*/
#define RT_MAX_AAC_FRAME_SIZE 9600

/*
音频缓冲的大小
*/
#define RT_AUDIO_INBUF_SIZE 28480


/*
自定义SDL刷新事件
*/
#define RT_EVNET_REFRESH (SDL_USEREVENT + 0x01)

/*
自定义SDL退出事件
*/
#define RT_EVNET_EIXT    (SDL_USEREVENT + 0x02)

/*
要设置的参数名称
*/
typedef enum _RT_NORMAL_PARAMS_NAME_S{
	/*
	设置全部参数
	*/
	RT_PARAMS_ALL = 0x111111111u,

	/*
	只设置帧缓存
	*/
	RT_PARAMS_CacheFrameNum = 0x000000001u,

	/*
	只设置过滤丢包 0,1
	*/
	RT_PARAMS_FilterBadPacket = 0x000000010u,

	/*
	只设置过滤解码失败的帧 0,1
	*/
	RT_PARAMS_FilterBadFrame = 0x000000100u,

	/*
	视频暂停 ,开始置0，置1暂停
	*/
	RT_PARAMS_VideoIsPause = 0x000001000u,
	
	
}RT_NORMAL_PARAMS_NAME;

/*
一般的参数，主要用将系统中对外提供的参数进行回调，这样就不用写很多get的方法了
*/
typedef struct _RT_NORMAL_PARAMS_S{
	
	/*
	fps，播放视频的帧率，由外部设置，不能通过内部获取
	[不可外部进行修改]
	*/
	int s32Fps;
	
	/*
	视频的总时长
	[不可外部进行修改]
	*/
	int s32TotalFramePts;
	
	/*
	接收到的数据流量统计
	[不可外部进行修改]
	*/
	int s32ReceiveTraffic;

	/*
	显示的数据流量统计
	不可外部进行修改
	*/
	int s32DisplayTraffic;

	/*
	解码的数据流量统计
	[不可外部进行修改]
	*/
	int s32DecodeTraffic;
	  
    /*
     存储的帧数，或者可以看成是次数，可以通过这个值来计算存储的视频时间
     不可外部进行修改
     */
    int s32RevFrameCount;
	
	/*尝试缓存的个数，
	-1：不缓存  
	>=0: 会尝试缓存指定的值，
	同时会照成延迟问题
	，默认是-1
	[可外部动态进行修改]
	*/
    int  s32CacheFrameNum;

	/*
	内部根据接收到的I帧间隔统计的pts
	[不可外部进行修改]
	*/
	int s32CountPts;

	/*
   	这是指检测到连续丢包大于指定值后后，会丢掉后面的包，直到下一个I帧，默认值关闭
   	飞控才有效0-1
   	[可外部动态进行修改]
   	*/
   	char s8IsFilterBadPacket;


   	/*
	是否过滤破图,这个是值过滤解码失败的帧，
	飞控才有效0-1
	[可外部动态进行修改]
   	*/
   	char s8IsFilterBadFrame;
   
	
	/*
	视频播放的进度，即播放的总时间，本地视频回放，要显示进度条的使用用到
	[不可外部进行修改]
	*/
	int s64VideoClock;

	/*
	视频暂停 ,暂停置1，开始置0，这个主要用来播放本地视频暂停的时候用到
	[可外部动态进行修改]
	*/
	char s8VideoIsPuase;

	
	
}RT_NORMAL_PARAMS;


//解码好后的avframe
typedef struct _RT_PICTURE_S {

	/**
	用来填充pDecodeFrame的buff
	*/
	uint8_t* pBuffer;
	
	/*
	解码好后的数据，rgb，或者yuv
	*/
    AVFrame* pDecodeFrame;

	/*
	pDecodeFrame的pts
	*/
    double s64Pts;

	/*
	视频的宽
	*/
    int s32Width;

	/*
	视频的高
	*/
    int s32Height;
	
    int s32Allocated;

	/*
	解码成pDecodeFrame对应的packet的长度，使用这个累加可以计算当前显示的包的总数
	*/
	int s32PacketSize;

	/*
	对应的设备id
	*/
    char acDid[256];
    
} RT_PICTURE;


//音视频同步的类型
typedef enum _RT_AV_SYNC_TYPE_{
	/*
	视频同步到音频，默认
	*/
	RT_AV_SYNC_AUDIO_MASTER =0,

	/*
	音频同步到视频
	*/
	RT_AV_SYNC_VIDEO_MASTER,

	/*
	音视频同步到外部时钟
	*/
	RT_AV_SYNC_EXTERNAL_MASTER,
}RT_AV_SYNC_TYPE;


//消息类型
typedef enum _RT_MSG_TYPE_
{
	/*
	视频开始显示
	*/
    RT_MSG_TYPE_SHOW = 0x60,

	/*
	视频分辨率
	*/
    RT_MSG_TYPE_RESOLUTION,

	/*
	文件打开状态
	*/
    RT_MSG_TYPE_FILE_OPNE_STATE,

	/*
	总的视频长度（时间）
	*/
    RT_MSG_TYPE_TOTAL_PTS,

	/*
	视频拖动播放的状态
	*/
    RT_MSG_TYPE_SEEK_STATE,

	/*
	音频开启的状态
	*/
    RT_MSG_TYPE_AUIDO_OPEN_STATE,

	/*
	视频直播中断了
	*/
    RT_MSG_TYPE_LIVE_PLAY_INTERRUPT,

	/*
	视频播放结束
	*/
	RT_MSG_TYPE_LIVE_PLAY_END,
    
}RT_MSG_TYPE;


//使用ffmpeg获取视频流的socket类型
typedef enum _RT_SOCKET_TYPE_
{
    RT_SOCKET_NONE = -1,
    RT_SOCKET_UDP =0,
    RT_SOCKET_TCP =1,
}RT_SOCKET_TYPE;


//分辨率
typedef enum _RT_RESOLUTION_TYPE_{
    
    RT_RESOLUTION_640,
    RT_RESOLUTION_720,
    RT_RESOLUTION_1080,
    
}RT_RESOLUTION_TYPE;


//播放类型
typedef enum _RT_LIVE_TYPE_
{
    
    RT_LIVE_TYPE_NONE = -1,
    RT_LIVE_TYPE_LOCAL =0,   //本地回放
    RT_LIVE_TYPE_LIVE,       //直播
    RT_LIVE_TYPE_REMOTE,     //远程回放
    
}RT_LIVE_TYPE;


//获取视频，或者音频数据的方式
typedef enum _RT_GET_DATA_TYPE_
{
    /*
    使用ffmpeg的方式获取视频流
    */
    RT_GET_DATA_FROME_FFMPEG =0,
    
    /*
    使用其它的方式获取视频流，这个方式就必须调用
    rt_pub_add_video，rt_pub_add_audio添加数据
    */
    RT_GET_DATA_FROME_OTHER =1,
    
}RT_GET_DATA_TYPE;


//是否支持音频
typedef enum _RT_OPEN_AUDIO_STATE_
{
    
    /*
    不支持音频
    */
    RT_AUDIO_DISENABLE =0,//disable
    
    /*
    支持音频
	*/
    RT_AUDIO_ENABLE =1,//enable
    
}RT_OPEN_AUDIO_STATE;


//视频录像状态
typedef enum _RT_VIDEO_RECEIVE_STATE_
{
    
    /*
    不录像
    */
    RT_VIDEO_ENREC =0,
    
    /*
    录像
    */
    RT_VIDEO_REC =1,
    
}RT_VIDEO_RECEIVE_STATE;


//音频类型
typedef enum _RT_AUDIO_TYPE_{
	RT_AUDIO_TYPE_NONE = -1,
	RT_AUDIO_TYPE_PCM = 0,
	RT_AUDIO_TYPE_AAC = 1,
	RT_AUDIO_TYPE_OTHER = 2
}RT_AUDIO_TYPE;

//视频类型
typedef enum _RT_VIDEO_TYPE_{
    RT_VIDEO_TYPE_H264,
    RT_VIDEO_TYPE_H256
}RT_VIDEO_TYPE;



//音频数据的结构体，主要是aac音频数据
typedef struct _RT_AUIDO_PARAMS_S{
    
    //主要是录像音频的时候需要用到，因为mp4v2写音频数据，必须要知道下面的信息

	/*
	信道数
	1
	2
	*/
    int s32Channel;

	/*
	采样率，每秒采样的次数，1024
	8000
	16000
	*/
    int s32Sample_rate;

	/*
	哪个级别的aac
	FF_PROFILE_AAC_LOW
	FF_PROFILE_AAC_MAIN
	FF_PROFILE_AAC_HE
	*/
    int s32Profile;
    
}RT_AUDIO_PARAMS;


//时钟结构体，主要用于音视频同步的问题，目前没有使用
typedef struct _RT_CLOCK_S {
    double pts;           /* clock base */
    double pts_drift;     /* clock base minus time at which we updated the clock */
    double last_updated;
    double speed;
    int serial;           /* clock is based on a packet with this serial */
    int paused;
    int *queue_serial;    /* pointer to the current packet queue serial, used for obsolete clock detection */
} RT_CLOCK;


//视频信息
typedef struct _RT_VIDEO_S{
    /*
    对应ffmpeg AVStream
    注意该结构体的默认time_base = (AVRational){1, 90000} 90000:是mpeg4 一秒的tick数，即一秒分成90000份
	*/
    AVStream *pVideoStream;

	/*
	对应ffmpeg AVCodecContext，视频解码都离不开这个变量，包括解码后所要的信息都是在这个变量中
	注意该结构体的time_base =(AVRational){1, fps} ,所以AVStream的time_base精度是最高的
	*/
    AVCodecContext *pVideoCodecCtx;

	/*
	对应ffmpeg AVCodec
	*/
    AVCodec	*pVideoCodec;

	/*
	视频队列，存放视频包
	*/
    RtQueue *pVideoPacketQueue;

	/*
	解码的包，主要是用于从队列中拿出来后，临时存储的
	*/
    AVPacket *pDecodePacket;

	/*
	对应ffmpeg stream的index，ffmpeg中视频的stream 的index默认是0，音频是1
	*/
    int s32VideoStreamIndex;

	/*
	视频buf的长度，目前没有用到
	*/
    unsigned int u32VideoBufSize;

	/*
	视频buf的index，目前没有用到
	*/
    unsigned int u32VideoBufIndex;

	/*
	视频解码后，需要转码
	*/
    struct SwsCotext *stpSwsCtx;
	
    /*
	前一帧计算一预测帧的pts，主要是用于当前帧获取不到正确的pts时，
	将会使用该值作为当前帧的pts，可以用于当前播放的进度
	*/
    double	s64VideoClock;
	
	/*
	当前所以显示的pts
	*/
    double s64CurrentPts;

	/*
	当前pts对应的外部时间，通过av_gettime()获取外部时间-微秒
	*/
	int64_t	s64CurrentPtsTime;
	
    /*
	当前定时的时间，可以理解当前帧显示的时间，该值主要有前后帧的pts差值计算所得
	如果音视频同步，会根据音频的的时间进行同步运算
	*/
    uint32_t u32Delay;

	/*
	视频播放的总时长
	*/
    double s64FrameTimer;

	/*
	最近一帧的pts，即前一帧的pts
	*/
    double s64FrameLastPts;

	/*
	最近一帧显示的时间，即前一次定时的时间
	*/
    double s64FrameLastDelay;

	/*
	fps，播放视频的帧率，由外部设置，不能通过内部获取
	*/
    int s32Fps;


	/*
	这是值是内部统计的一个fps，主要用于计算视频的s64VideoClock的时候用到,主要是p2p播放的时候用到
	*/
	int s32CountFps;

	

	/*
	视频的总时长，本视频的时候会获取时间的总长度
	*/
    int s32TotalFramePts;
	
	/*
	接收到的数据流量统计
	*/
    int s32ReceiveTraffic;

	/*
	显示的数据流量统计，跟s32ReceiveTraffic不一定相同，有可能解码失败的数据不会拿去显示
	*/
	int s32DisplayTraffic;

	/*
	解码的数据流量统计
	*/
    int s32DecodeTraffic;

	/*
	视频的宽，这个值是解码后所得
	*/
    int s32PixelW;

	/*
	视频的高，这个值是解码后所得
	*/
    int s32PixelH;

	/*
	视频最终转码的类型，可由外部指定
	AV_PIX_FMT_YUV420P
	AV_PIX_FMT_RGB24
	AV_PIX_FMT_RGBA
	*/
    enum AVPixelFormat enAVPixelFormat;

	/*尝试缓存的个数，
	-1：不缓存  
	>=0: 会尝试缓存指定的值，
	同时会照成延迟问题
	，默认是-1
	*/
    int  s32CacheFrameNum; 
    
    
    /*
     视频信息回调，比如分辨率，开始出图,视频输入回调，比如ffmpeg加载失败
     uid:对应的uid
     msgType：消息类型
     status：状态，0 1
     */
    int (*funVideoMsgReturnCallBack)(void *userData,const char *uid, RT_MSG_TYPE msgType,int status);


	/*
	用户传递进来的数据
	*/
	void *userData;
	
    /*
     播放的类型，每一个ipc都有自己的对应的播放类型
     */
    RT_LIVE_TYPE enLiveType;


	/*
	第一次接收到的pts时间，后面的pts将会减去这个值，为了保证播放时间从0开始
	*/
	double s64FirstStartPts;


	/*
	第一次返回的视频时间戳,用在记录p2p视频数据回调中第一次返回数据的时间戳，
	这样做是了让计算的pts能从0开始计算，并且为单位为秒
	*/
	double s64FirstVideoTimestamp;

	
    /*
    这是指检测到连续丢包大于指定值后后，会丢掉后面的包，直到下一个I帧，默认值关闭
    飞控才有效
	*/
    char s8IsFilterBadPacket;


	/*
	 是否过滤破图,这个是值过滤解码失败的帧，
	 飞控才有效
	*/
    char s8IsFilterBadFrame;

	
}RT_VIDEO;


//音频
typedef struct _RT_AUDIO_S{
    
    AVStream *pAudioStream;
    AVCodecContext *pAudioCodecCtx;
    AVCodec	*pAudioCodec;
    
    /*
     音频队列
     */
    RtQueue *pstAudioPacketQueue;
    
    /*
     音频数据buf,这个音频数据主要是用在p2p音频数据回调的时候
     aac数据包返回来的时候会包含多帧的情况，需要用缓存区缓存起来后，再从缓冲区里面一帧一帧
     的解析并存储到队列中
    */
    uint8_t *pAudioBuf;
    
    /*
     记录pAudioBuf数据包的时候，需要用到
     */
    uint8_t *pAudioBufBeginPos;
    
    /*
     记录pAudioBuf数据包的长度
     */
    int s32AudioBufSize;
    
    /*
     对于在ffmpeg里面的AvStream 的index
     */
    int s32AudioStreamIndex;
    
    
    /*
     使用SDL播放的时候使用
     */
    unsigned int u32AudioBufIndex;
    
    /*
     播放时中
     */
    double s64AudioClock;

	
	/**
	第一次接收到的pts时间，后面的pts将会减去这个值，为了保证播放时间从0开始
	*/
	double s64FirstStartPts;

	/*
	第一次返回的音频时间搓,用在记录p2p视频数据回调中第一次返回数据的时间戳，
	这样做是了让计算的pts能从0开始计算，并且为单位为秒
	*/
	double  s64FirstAudioTimestamp;

	/*
	解析出的aac帧的帧数，用于p2p添加数据的时候计算pts
	*/
	int s34FrameCount;
    
    /*
     ipc 设备ID
     */
    //char acDid[256];
    
    /*
     是否播放声音，声音一直都有解码，但是没有送去播放而已
     */
    int s32OpenAudio;
    
    
    /*
     音频数据，这里的音频数据主要是在播放p2p流的时候使用到，
     因为没有没有经过ffmpeg事先获取后信息，设置SDL播放的时候必须要提前设置好
     */
    RT_AUDIO_PARAMS *stRtAudioParams;
    
    /*
     uid:对应的uid
     msgType：消息类型
     status：状态，0 1
     */
    int (*funVideoMsgReturnCallBack)(void *userData,const char *uid, RT_MSG_TYPE msgType,int status);

	/*
	用户数据
	*/
	void *userData;

	/*
	音频的类型
	*/
	RT_AUDIO_TYPE enRtAudioType;

	/*
	音频解码后，需要格式转换
	*/
	struct SwrContext *stpSwsCtx;

	/*
	pcm 转成一帧aac所需要的对应的pcm数据的长度，这个值会根据采样率，信道等计算而得
	所以播放pcm的时候，要特别注意初始化好stRtAudioParams
	*/
	int s32PcmToAacSize;
	
}RT_AUDIO;


//输入流，通过打开rtsp等方式获取视频流
typedef struct _RT_STREAM_IN_S{
    
    AVFormatContext *pformatCtx;
    
    /*
     文件路径
     */
    char acRtspPath[512];
    
    /*
     打开方式
     */
    RT_SOCKET_TYPE enSocketModel;
    
    /*
     播放类型
     */
    RT_LIVE_TYPE enLiveType;
    
    /*
     拖动进度条播放
     */
    int64_t s64SeekPosition;
  	
    
    int s32Quit;
    
    /*
     uid:对应的uid
     msgType：消息类型
     status：状态，0 1
     */
    int (*funVideoMsgReturnCallBack)(void *userData,const char *uid, RT_MSG_TYPE msgType,int status);

	/*
	用户传递进来的数据
	*/
	void *userData;

	/*
	视频流的index
	*/
	int s32VideoStreamIndex;
	
	/*
	音频流的index
	*/
    int s32AudioStreamIndex;

	/*
	视频获取获取的状态
	0:是正常退出，默认
	1:视频播放结束
	2:视频中断
	这个变量一般都是内部使用
	*/
	int s32State;
    
}RT_STRAM_IN;


//输出流，保存视频
typedef struct _RT_STREAM_OUT_S{
	/*
	主要用于编码用，将pcm数据转为aac存储为mp4格式
	*/
	AVCodecContext *pAudioCodecCtx;
	AVCodec *pAudioCodec;

	
	/*
	 存储编码好后的aac数据包
	*/
	AVPacket avPacket;
	
	/*
	编码的时候，要从pcm的buf中拿出指定的长度的数据来进行编码
	*/
	int s32pcmFrameSize;
	
	/*
	音频pcm帧，主要用于编码的时候
	*/
	AVFrame *pPcmFrame;
	
	/*
	主要用于填充pPcmFrame
	*/
	uint8_t *pcmFrameBuf;
	
	
	/*
	mp4v2的handle
	*/
    MP4FileHandle stMp4FileHandle;

	/*
	mp4v2视频的trackid
	*/
    MP4TrackId s32VideoTrackId;

	/*
	mp4v2音频的trackid
	*/
    MP4TrackId s32AudioTrackId;

	/*
	保存的文件名
	*/
    char acFileName[256];
    
    /*
     所要录像视频的帧率，这个帧率将决定视频是否能正常播放
     如果帧率不对，回导致视频快播，或者慢播，这个值由外部设置，不能动态获取，但是在录像的时候有对这个值做了特殊判断处理，
     具体请看代码
     */
    int s32Fps;
    
    /*
     所要录像的宽，这个值也要设置正确，这个值会从解码后获取
     */
    int s32Width;
    
    /*
     所要录像的高，这个值也要设置正确，这个值会从解码后获取
     */
    int s32Height;
    
    /*
     主要是录像音频的时候需要用到，使用mp4v2录制的时候用到，这个变量不会初始化，直接跟RT_AUDIO结构体中的
     stRtAudioParams的变量关联起来
     */
    RT_AUDIO_PARAMS *stRtAudioParams;
    
    
    /*
     录像状态
     */
    RT_VIDEO_RECEIVE_STATE enRtVideoRecState;
    
    
    /*
     标志为是否重制,这个标志将决定一帧的录像要从I帧开始写
     */
    int s32Reset;
    
    /*
     录像buff，保存录像的数据的时候，往往会先将数据拷贝到这个变量中，再拿这个buff的数据去本地化
     */
    uint8_t *pVideoBuf;
    
    /*
     录像buff，保存录像的数据的时候，往往会先将数据拷贝到这个变量中，再拿这个buff的数据去本地化
     */
    uint8_t *pAudioBuf;
    
    /*
     uid:对应的uid
     msgType：消息类型
     status：状态，0 1
     */
    int (*funVideoMsgReturnCallBack)(void *userData,const char *uid, RT_MSG_TYPE msgType,int status);

	/*
	用户数据
	*/
	void *userData;
    
    /*
     录制视频保存的帧数或者说是次数
     */
    int s32VideoWriteFrameCount;
    
    /*
     录制音频保存的帧数或者说是次数
     */
    int s32AudioWriteFrameCount;
    
    /*
     保存音视频的时候互斥对象,同时写音视频的时候需要锁，要不录像出来的视频会有很多问题
     比如：有一大段时间是图像不动，也没有音频
     */
    SDL_mutex *pSDLMutex;
	
	
	/*
	是否同步时间，默认为0，如果为1则写音视频的时候会按照时间来写，可能会有各种各样的问题，
	一般同时保存音视频的时候才会需要到同步，同步方式录制的时候，录制的时间越长，保存的时候，也会对应的耗时
	录制30分钟的视频，保存所消耗的时间不同的手机表现不同
	*/
	int s32SynTime;
	

	/*
	视频保存上一帧的时间(外部时钟)，只有s32SynTime == 1的时候，这个值才会使用
	*/
	long long s64VideoVoltime;

	/*
	音频保存上一帧的时间(外部时钟)，只有s32SynTime == 1的时候，这个值才会使用
	*/
	long long s64AudioVoltime;


	 /*
    录制的音频类型
    */
    RT_AUDIO_TYPE enRtAudioType;
    
    /*
    录制的视频类型
    */
    RT_VIDEO_TYPE enRtVideoType;
	
}RT_STRAM_OUT;

//额外的参数，主要是一些高级设置的参数
typedef struct _RT_PARAMS_EXTRA_S{
	
	/*
	设置视频缓存的个数，在直播的过程中才会起作用，默认是-1，
	这个参数也可后面动态的设置
	*/
	int  s32CacheFrameNum;

	/*
	音视频同步的类型，默认 RT_AV_SYNC_AUDIO_MASTER(音频同步到视频)
	*/
	RT_AV_SYNC_TYPE enRtAvSyncType;

	
    /*
    这是指检测到连续丢包大于指定值后后，会丢掉后面的包，直到下一个I帧，默认值关闭
    飞控才有效
    这个参数也可后面动态的设置
	*/
    char s8IsFilterBadPacket;


	/*
	 是否过滤破图,这个是值过滤解码失败的帧，
	 飞控才有效
	 这个参数也可后面动态的设置
	*/
    char s8IsFilterBadFrame;
	
}RT_PARAMS_EXTRA;

//参数,这个是有外部设置后，传递进来的
typedef struct _RT_PARAMS_S{

	/*
	AV_CODEC_ID_H264
	AV_CODEC_ID_H265
	*/
    enum AVCodecID avCodecID;
    
    /*
    ipc did
    */
    char acDid[256];
    
    /*
     socket打开类型
    */
    RT_SOCKET_TYPE enRtSocketType;

	/*
	所播放视频的fps
	*/
	int s32Fps;
    
    /*
     是否开启音频功能，默认关闭
    */
    RT_OPEN_AUDIO_STATE enRtOpenAudioState;
    
    /*
     视频转码的格式
     AV_PIX_FMT_YUV420P
	 AV_PIX_FMT_RGB24
	 AV_PIX_FMT_RGBA
    */
    enum AVPixelFormat enAVPixelFormat;

	
    /*
     播放类型,对应所添加的ipc的一个播放类型，
    */
    RT_LIVE_TYPE enRtLiveType;

	/*
     音频的播放类型,对应所添加的ipc的一个播放类型，
    */
	RT_AUDIO_TYPE enRtAudioType;

	/*
     视频的播放类型,对应所添加的ipc的一个播放类型，
    */
	RT_VIDEO_TYPE enRtVideoType;
    
    /*
     是否停止scaleDataReturnCallBack后面的操作，
     增加这个变量是因为执行scaleDataReturnCallBack回调后会有一个耗时的操作
     如果不是使用SDL来显示视频数据，则没有没有必要
    */
    int s32BlockScaleData;
    
    /*
     是否停止decodeDataReturnCallBack后面的操作
     增加这个变量是因为执行视频解码后会跟进设置的enAVPixelFormat来进行解码，这些耗时操作，
     如果不是使用该库来进行视频的缩放跟转码，这没有必要开启
    */
    int s32BlockVideoDecodeData;
    
    /*
     是否要停止后面的解码后使用SDL去播放的动作，这个值置1后，回将解码好后的数据回调出去
     不在使用SDL去播放，可以避免网络延迟后堆包，声音延迟问题
    */
    int s32BlockAudioDecodeData;

	/*
	用户数据，由外部传递进来
	*/
	void *userData;
    
    /*
     音频数据，这里的音频数据主要是在播放p2p流的时候使用到，
     因为没有没有经过ffmpeg事先获取后信息，设置SDL播放的时候必须要提前设置好，如果是播放的
     音频格式是pcm，必须要设置该参数，要不可能会播放失败，因为内部无法获取到对应的信息
    */
    RT_AUDIO_PARAMS stRtAudioParams;
    
    
    /*
     视频信息回调，比如分辨率，开始出图,视频输入回调，比如ffmpeg加载失败，具体看RT_MSG_TYPE消息类型定义
     uid:对应的uid
     msgType：消息类型
     status：状态，0 1
    */
    int (*funVideoMsgReturnCallBack)(void *userData,const char *uid, RT_MSG_TYPE msgType,int status);
    
    /*
     解码好后并且缩放后的视频回调,yuv420p转为rgb后的数据
    */
    int (*funScaleDataReturnCallBack)(void *userData,RT_PICTURE *pstPicture);
    
    /*
     解码好后的视频回调,这个回调的视频格式为YUV420p,之所以要增加这个函数回调是为了更加灵活的给外部提供更灵活的数据
     比如使用opengGL显示，这不需要缩放转码，这些工作可以交给openGL来做
    */
    int (*funVideoDecodeDataReturnCallBack)(void *userData,RT_PICTURE *pstPicture);
    
    /*
     解码好后的音频回调,之所以要增加这个函数回调是为可能的减少声音延迟，
     不再使用SDL的定时去播放
     （举例，网络卡顿一秒，一秒后恢复，这个时候，app端会收到累积了一秒的音频数据，后面继续使用SDL去播放的就会延迟了
     ，SDL 内部会根据采样率等信息做了定时处理）
    */
    int (*funAudioDecodeDataReturnCallBack)(void *userData,const char *uid,uint8_t *data,int len);

	/*
	将获取到的h264数据回调出去，返回值>=0 则数据将会被内部存储,即会拿去解码并显示，<0 内部则会将数据抛弃，默认可以不设置
	数据都会被内部存储，这个函数主要是针对飞控，比如判断是I帧后面的8个字节，比如判断该帧是否花屏等，由用户自己扩展，
	这个方法，使用ffmpeg获取数据的时候才会有效
	*/
	int (*funH264DataReturnCallBack)(void *userData,const char *uid,AVPacket *pkt);

	
	/*
	额外参数，默认是不使用的
	*/
	RT_PARAMS_EXTRA *stRtParmasExtra;
	
}RT_PARAMS;

//ipc，单台ipc会包含所有的音视频等数据
typedef struct _RT_IPCAM_INFO_S{

	/*
	输入流
	*/
    RT_STRAM_IN     *stRtStreamIn;

	/*
	输出流
	*/
    RT_STRAM_OUT    *stRtStreamOut;

	/*
	音频
	*/
    RT_AUDIO        *stRtAudio;

	/*
	视频
	*/
    RT_VIDEO        *stRtVideo;

	/*
	参数设置
	*/
    RT_PARAMS       *stRtParams;
	
	
	/*
	音视频同步的类型，默认 RT_AV_SYNC_AUDIO_MASTER(音频同步到视频)
	*/
	RT_AV_SYNC_TYPE enRtAvSyncType;
	
	
}RT_IPCAM_INFO;


//多台ipc设备
typedef struct _RT_PLAYER_S{
    
    /*
     多台ipc，默认有可以支持4台
    */
    RT_IPCAM_INFO  stRtIpcamInfo[RT_MAX_IPCAM_SIZE];
    
    /*
     解码好后视频数据的数组，
     多个ipc解码好后的数据可以共用同一个，所以定义在这里
    */
    RT_PICTURE stRtPictures[RT_VIDEO_PICTURE_QUEUE_SIZE];

	/*
	 stRtPictures数组里面使用的长度，这个值的计算都会添加同步锁
	*/
    int s32PictureSize;

	/*
	 stRtPictures存放的数组的index，这个值的计算都会添加同步锁
	*/
    int s32PictureWIndex;

	/*
	 stRtPictures取出来显示的数组的index，这个值的计算都会添加同步锁
	*/
    int s32PictureRIndex;

	/*
	 同步锁，主要用于计算上面几个值的时候添加的
	*/
    SDL_mutex *pSDLMutex;
    
    /*
	 同步锁，主要用于计算上面几个值的时候添加的
	*/
    SDL_cond *pSDLCond;
	
    /*
     一帧的aac数据,aac数据包解码后得到的一帧的aac数据，
     多个ipc解码好后的数据可以共用同一个，所以定义在这里
    */
    uint8_t acAacFrame[RT_MAX_AAC_FRAME_SIZE];
    
    /*
     解码好后的数据音频buf，解码后的音频数据并且能播放的数据一般都是pcm所以就命名为pPcmBuf，
     多个ipc解码好后的数据可以共用同一个，所以定义在这里
    */
    uint8_t *pPcmBuf;
    
    /*
     解码好后的数据，一般pPcmTempBuf = pPcmBuf，定义这个变量主要就是为了结合SDL使用，
     多个ipc解码好后的数据可以共用同一个，所以定义在这里
    */
    uint8_t *pPcmTempBuf;

	/*
	 音频是否播放
	*/
	int s32AudioPlay;
    
	/*
     记录重采样后返回的长度，这个长度主要用在使用SDL播放的时候
    */
    unsigned int u32PcmBufSize;
    
    /*
     使用SDL播放的时候使用
    */
    unsigned int u32PcmBufIndex;
    
    
    /*
     解码好后的AVFrame，每次解码成功后，数据都将用这个变量保存
    */
    AVFrame *pVideoDecodeFrame;
    
    
    /*
     退出,整个app
    */
    int s32Exit;

	/*
	 停止
	*/
	int s32Stop;
    
    /*
     退出刷新线程
    */
    int s32QuitRefresh;
    
    /*
     退出解码线程
    */
    int s32QuitDecodeVideoThread;
    
    /*
     退出解码音频的线程
    */
    int s32QuitDecodeAuidoThread;
    
    /*
     退出获取视频流的线程
    */
    int s32QuitReadDataThread;
    
    /*
     数据来源,只能播放相同数据来源的数据,这个在初始化的时候就已经定义好，
    */
    RT_GET_DATA_TYPE enGetDataType;
    
    /*
     当前使用的ipcam的数目
    */
    int s32UseIpcams;
    
    /*
     视频解码线程
    */
    SDL_Thread *pDecodeVideoThread;
    
    /*
     音频解码线程
    */
    SDL_Thread *pDecodeAudioThread;
	
	/*
	 获取视频流的线程，如果是通过ffmpeg的方式获取视频流，才会启动该线程
	*/
	SDL_Thread *pReadDataThread;
    
    /*
     刷新事件线程
    */
    SDL_Thread *pEventThread;


	/*
	 标志的是否已经解码音频数据，添加这个标志位是因为让在不开启音频播放的情况先
	 音频解码必须要先解码一次，初始化里面的部分内容，后面如果音频播放不开启的情况下，就不送去解码了，
	 这样提高性能
	*/
	int s32IsAlreadyDecoderAudio;


	/*
	是否已经出图,在没有出图前，获取内部信息，会返回0
	*/
	int s32IsAlreadyShow;

	/*
	视频暂停，0:播放 1:暂停，主要是本地视频播放的时候用到
	*/
	char s8VideoPause;
	
}RT_PLAYER;




/**
初始化
enGetDataType:获取数据的方式
initFlags:初始化模块的值RT_INIT_VIDEO，RT_INIT_AUDIO，RT_INIT_ALL，
备注:比如飞控不需要声音只需要指定RT_INIT_VIDEO即可
*/
int rt_pub_init(int **pPlayerHandle,RT_GET_DATA_TYPE enGetDataType,int initFlags);

/**
添加ipcam,使用ffmpeg播放本地视频，stRtParams 必须malloc
*/
int rt_pub_add_local_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pFilePath);

/**
添加ipcam,使用ffmpeg播放rtsp视频，stRtParams 必须malloc
*/
int rt_pub_add_rtsp_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pRtspPath);

/**
添加ipcam,使用ffmpeg播放http视频，stRtParams 必须malloc
*/
int rt_pub_add_http_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams,const char *pHttpPath);

/**
添加ipcam,使用p2p获取视频流的时候使用，所以不需要传递文件的路径，，stRtParams 必须malloc
*/
int rt_pub_add_p2p_ipcam(int *pPlayerHandle,RT_PARAMS *stRtParams);

/**
移除ipcam
*/
int rt_pub_remove_ipcam(int *pPlayerHandle,const char *pDid);

/**
开始
*/
int rt_pub_start(int *pPlayerHandle);

/**
停止
*/
int rt_pub_stop(int *pPlayerHandle);

/**
快进,pts单位为秒
*/
int rt_pub_video_seekto(int *pPlayerHandle,const char *pDid,int pts);


/**
退出
*/
int rt_pub_exit(int *pPlayerHandle);

/**
视频保存为mp4格式,s32SynTime是否要同步时间，如果仅仅录像视频或者音频则不需要
*/
int rt_pub_start_rec(int *pPlayerHandle,const char*pDid,const char*pFileName,int fps,int s32SynTime);

/**
停止录像
*/
int rt_pub_stop_rec(int *pPlayerHandle,const char*pDid);

/**
音频是否播放，即送去解码
*/
int rt_pub_audio_open(int *pPlayerHandle,const char*pDid,int openState);

/**
获取常用的参数，所有对外提供的的参数都是通过RT_NORMAL_PARAMS这个结构体获取
比如要流量的统计，当前缓存的个数等
如果pDid == NULL ,默认使用内部ID
*/
int rt_pub_get_normal_params(int *pPlayerHandle,const char*pDid,RT_NORMAL_PARAMS *stRtNormalParams);

/*
设置常用的参数，所有参数的设置都是通过RT_NORMAL_PARAMS这个结构体进行设置
比如，设置缓存的个数等
paramFlags就是要修改的参数名名
如果pDid == NULL ,默认使用内部ID
*/
int rt_pub_set_normal_params(int *pPlayerHandle,const char*pDid,RT_NORMAL_PARAMS *stRtNormalParams,int paramFlags);

/**
添加外部提供视频数据
*/
int rt_pub_add_video_h264(int *pPlayerHandle,const char *pDid,unsigned char * data,int len,double time,int keyFrame);

/**
添加外部提供视频数据
*/
int rt_pub_add_video_h265(int *pPlayerHandle,const char *pDid,unsigned char * data,int len,double time,int keyFrame);

/**
添加外部提供的音频数据,time为毫秒
*/
int rt_pub_add_audio_aac(int *pPlayerHandle,const char *pDid,unsigned char * data,int len,double time);

/**
添加外部提供的音频数据
*/
int rt_pub_add_audio_pcm(int *pPlayerHandle,const char *pDid,unsigned char * data,int len,double time);


/**
拍照将图标保存为jpg格式
width <= 0 或者 height <= 0的时候，使用默认的宽高，即源视频的宽高
如果是使用ffmpeg的方式获取数据流
pDid: 设置为RT_DEFAUT_UID或者设置为NULL
*/
int rt_pub_take_jpeg(int *pPlayerHandle ,const char *pDid,const char*filePath,int width,int height);

/**
* 获取队列的长度
* type = 1;视频
* type = 0;音频
*/
int rt_pub_queue_size(int *pPlayerHandle,const char *pDid,int type);


/**
清空队列
type: 0:清空视频队列   1:清空音频队列  其他:清空所有
*/
int rt_pub_queue_clear(int *pPlayerHandle,const char *pDid,int type);


/**
pts单位为秒
*/
int rt_pub_video_seekto(int *pPlayerhandle,const char *pDid,int pts);



#ifdef __cplusplus
}
#endif /* __plusplus*/

#endif /* Rt_pub_def_h */
