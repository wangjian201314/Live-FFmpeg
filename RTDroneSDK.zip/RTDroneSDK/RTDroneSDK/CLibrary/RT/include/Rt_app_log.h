//
//  Rt_log.h
//  RunTopSDK
//
//  Created by 杨青远 on 2017/4/12.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#ifndef Rt_log_h
#define Rt_log_h

#include <stdio.h>

#ifdef ANDROID
#include <jni.h>
#include <android/log.h>

#define TAG_RT "rt_log"
#define TAG_LIVE555 "live555_log"
#define TAG_FFMPEG "ffmpeg_log"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG_RT, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG_RT, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG_RT, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG_RT, __VA_ARGS__)


#define LOGI_555(...) __android_log_print(ANDROID_LOG_INFO,  TAG_LIVE555, __VA_ARGS__)
#define LOGD_555(...) __android_log_print(ANDROID_LOG_DEBUG, TAG_LIVE555, __VA_ARGS__)
#define LOGE_555(...) __android_log_print(ANDROID_LOG_ERROR, TAG_LIVE555, __VA_ARGS__)
#define LOGW_555(...) __android_log_print(ANDROID_LOG_WARN, TAG_LIVE555, __VA_ARGS__)

#define LOGI_FFMPEG(...) __android_log_print(ANDROID_LOG_INFO,  TAG_FFMPEG, __VA_ARGS__)
#define LOGD_FFMPEG(...) __android_log_print(ANDROID_LOG_DEBUG, TAG_FFMPEG, __VA_ARGS__)
#define LOGE_FFMPEG(...) __android_log_print(ANDROID_LOG_ERROR, TAG_FFMPEG, __VA_ARGS__)
#define LOGW_FFMPEG(...) __android_log_print(ANDROID_LOG_WARN, TAG_FFMPEG, __VA_ARGS__)

#else

    #define LOGI(...) printf(__VA_ARGS__)

    #define LOGD(...) printf(__VA_ARGS__)
    #define LOGE(...) printf(__VA_ARGS__)
    #define LOGW(...) printf(__VA_ARGS__)
    #define LOGI_555(...) printf(__VA_ARGS__)
    #define LOGD_555(...) printf(__VA_ARGS__)
    #define LOGE_555(...) printf(__VA_ARGS__)
    #define LOGW_555(...) printf(__VA_ARGS__)

    #define LOGI_FFMPEG(...) printf(__VA_ARGS__)
    #define LOGD_FFMPEG(...) printf(__VA_ARGS__)
    #define LOGE_FFMPEG(...) printf(__VA_ARGS__)
    #define LOGW_FFMPEG(...) printf(__VA_ARGS__)

//#define NOSUPPORT_S(fmt, arg...)  printf("%s:%d:"fmt, __FUNCTION__, __LINE__, ##arg)

#endif

#define LOG_PRINT_HEX(Source,Begain,End) \
do \
{ \
int i=0,Num; \
Num = (End>Begain)?(End - Begain):(Begain - End); \
char cTmp[3*Num+1]; \
cTmp[3*Num] = '\0'; \
for(;i < Num;i++) \
{ \
sprintf(cTmp+(3*i),"%02x ",*(Source+i+Begain)); \
} \
LOGD("%s\n",cTmp); \
}while(0)


#endif /* Rt_log_h */
