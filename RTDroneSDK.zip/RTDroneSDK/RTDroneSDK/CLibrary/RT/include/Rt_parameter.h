//
//  Rt_parameter.h
//  RTP2PApp
//
//  Created by 杨青远 on 2017/6/10.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#ifndef Rt_parameter_h
#define Rt_parameter_h

#include <stdio.h>
#include "Rt_pub_def.h"

#ifdef __cplusplus
#if _cplusplus
extern "C"{
#endif
#endif /* __plusplus*/
    
typedef enum _RT_PLATFORM_{
    RT_IOS,         //ios
    RT_ANDROID      //android
}RT_PLATFORM;

/*因为RT_PARAMS 的参数比较多，所以这里提供了常用的初始化方法*/

//播放本地的视频的时候，初始化RT_PARAMS
int rt_paramster_init_get_data_forme_ffmpeg_local(RT_PLATFORM platform,RT_PARAMS *stRtParams);

//播放远程视频，比如rtsp远程回放
int rt_paramster_init_get_data_forme_ffmpeg_remote(RT_PLATFORM platform,RT_PARAMS *stRtParams);

//远程直播
int rt_paramster_init_get_data_forme_ffmpeg_remote_live(RT_PLATFORM platform,RT_PARAMS *stRtParams);
    
//播放视频流从其它方式获取的视频，比如使用live555获取视频，ffmpeg解码播放，默认是直播的方式
int rt_paramster_init_get_data_forme_other(RT_PLATFORM platform,const char *did,RT_PARAMS *stRtParams);
    
int testReadAAC2();
int testReadAAC();


#ifdef __cplusplus
#if _cplusplus
}
#endif
#endif /* __plusplus*/

#endif /* Rt_parameter_h */
