//
//  Rt_video.h
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/17.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#ifndef Rt_video_h
#define Rt_video_h

#include <stdio.h>
#include "Rt_pub_def.h"

#ifdef __cplusplus
#if _cplusplus
extern "C"{
#endif
#endif /* __plusplus*/


int rt_video_init(RT_VIDEO *stRtVideo,enum AVCodecID avCodeID,RT_LIVE_TYPE enRtLiveType,
                  enum AVPixelFormat enAVPixelFormat,AVCodecParameters *par);

int rt_video_display(RT_VIDEO *stRtVideo,RT_PICTURE *stRtPicture);

double rt_video_decode(RT_VIDEO *stRtVideo,char *pDid,AVFrame *pDecodeFrame,int *packetSize);

int rt_video_relase(RT_VIDEO *stRtVideo,RT_GET_DATA_TYPE getDataType);


#ifdef __cplusplus
#if _cplusplus
}
#endif
#endif /* __plusplus*/

#endif /* Rt_video_h */
