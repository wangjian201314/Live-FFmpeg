//
//  Rt_audio.h
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/17.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#ifndef Rt_audio_h
#define Rt_audio_h
#include "Rt_pub_def.h"
#include <stdio.h>

#ifdef __cplusplus
#if _cplusplus
extern "C"{
#endif
#endif /* __plusplus*/

int rt_audio_init(RT_AUDIO *stRtAudio,enum AVCodecID avCodecID,AVCodecParameters *par);

int rt_audio_decode(RT_AUDIO *stRtAudio,uint8_t *buf,double *pts_ptr);

int rt_audio_relase(RT_AUDIO *stRtAudio);



#ifdef __cplusplus
#if _cplusplus
}
#endif
#endif /* __plusplus*/

#endif /* Rt_audio_h */
