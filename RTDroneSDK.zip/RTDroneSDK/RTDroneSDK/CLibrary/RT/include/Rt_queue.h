//
//  Rt_queue.h
//  RunTopSDK
//
//  Created by 杨青远 on 2017/4/12.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#ifndef Rt_queue_h
#define Rt_queue_h


#ifdef __cplusplus
#if _cplusplus
extern "C"{
#endif
#endif /* __plusplus*/
    
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/time.h"
#include "SDL.h"
    
    typedef struct RtQueue_S{
        
        AVPacketList 	*first_pkt;
        AVPacketList 	*last_pkt;
        int 			size;
        int 			nb_packets;
        SDL_mutex		*mutex;
        SDL_cond 		*cond;
        
    }RtQueue;
    
    int rt_queue_init(RtQueue *queue);
    
    int rt_queue_put(RtQueue *queue,AVPacket *pkt);
    
    int rt_queue_get(RtQueue *queue,AVPacket *pkt,int block);
    
    int rt_queue_clear(RtQueue *queue);
    
    int rt_queue_destroy(RtQueue *queue);
    
#ifdef __cplusplus
#if _cplusplus
}
#endif
#endif /* __plusplus*/

#endif


/* Rt_queue_h */
