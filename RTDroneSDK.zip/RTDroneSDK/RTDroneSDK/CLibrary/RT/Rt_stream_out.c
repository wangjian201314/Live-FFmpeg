//
//  Rt_stream_out.c
//  RTP2PApp
//
//  Created by 杨青远 on 2017/5/17.
//  Copyright © 2017年 杨青远. All rights reserved.
//

/*
 *将视频存储为mp4格式
 */
#include <sys/timeb.h>

#include "Rt_stream_out.h"
#include "Rt_pub_def.h"

#define H264_Get_NalType(c)  ( (c) & 0x1F )
#define STREAM_HEAD_LEN 4

#define NAL_TYPE_SLICE      1
#define NAL_TYPE_IDR        5
#define NAL_TYPE_SEI        6
#define NAL_TYPE_SPS        7
#define NAL_TYPE_PPS        8
#define NAL_TYPE_SEQ_END    9
#define NAL_TYPE_STREAM_END 10
#define MP4INFO_BUFF_LEN  128

#define RT_MAX_VIDEO_BUF_SIZE 521*1024


//aac规格
/*
 mpeg-2 AAC Main
 mpeg-2 AAC SSR
 mpeg-2 AAC LOW
 
 mpeg-4 AAC Main//主规格
 mpeg-4 AAC SSR//可变采样率规格
 mpeg-4 AAC LOW//低复杂度规格
 mpeg-4 AAC LTP//长时期预测规格
 mpeg-4 AAC LD//低延迟规格
 mpeg-4 AAC HE//高效率规格
 */
#define AAC_TYPE_MAIN 1 //主规格
#define AAC_TYPE_LOW 2  //低复杂度规格
#define AAC_TYPE_SSR 3  //可变采样率规格
#define AAC_TYPE_LTP 4  //长时期预测规格


/*标志是否已经写视频数据，添加这个标志是为了防止音频先写，导致视频没有缩列图*/
static char gs_s8IsStartReadVideo = 0;

/*标志是否写完视频，是为了防止没有写完视频就开始回收资源*/
static char gs_s8IsWriteVideoEnd = 1;

/*标志是否写完音频，是为了防止没有写完音频就开始回收资源*/
static char gs_s8IsWriteAudioEnd = 1;


//获取当前的时间，毫秒数
long long getSystemTime() {
    struct timeb t;
    ftime(&t);
    return 1000 * t.time + t.millitm;

}

//获取数据头的类型
static int getNaLType(void*p,int len){
    if(!p || 5>len){
        return -1;
    }
    
    unsigned char *b = (unsigned char*)p;
    if(b[0] || b[1] || b[2]!= 0x01)
    {
        b++;
        if(b[0] || b[1] || b[2]!= 0x01){
            return -1;
        }
    }
    
    b += 3;
    
    return *b;
}

//检查是否支持转换格式
static int checkSampleFmt(AVCodec *codec,enum AVSampleFormat sample_fmt){
    const enum AVSampleFormat *p = codec->sample_fmts;
    while (*p != AV_SAMPLE_FMT_NONE) {
        if(*p == sample_fmt){
            return 1;
        }
        p++;
    }
    return 0;
}


/**
获取到h264头的信息，sps,pps,sei
return 到0-i帧的长度
*/
static int getNALInfo(uint8_t *data,int size,unsigned char *sps,unsigned char *pps,unsigned char *sei,int *spsLength,int *ppsLength,int *seiLength){
	 //从I帧开始保存数据，这样视频才会有所列图
    if ( NAL_TYPE_SPS != (getNaLType( data, size ) & 0x1F )){
        LOG_PRINT_HEX(data,0,60);
        return -1;
    }

	if(sps == NULL || pps == NULL || sei == NULL ){
		LOGE("[%s   %d] sps == NULL || pps == NULL || sei == NULL\n",__FUNCTION__,__LINE__);
		return -1;
	}
	
	int nal_type = *(data + 4)& 0x1F;
    int sps_length = 0;
    int pps_length = 0;
    int sei_length = 0;

	
	int temp = 4;
	//以下操作主要是将sps，pps，sei，i帧 截取出来，并将对应的前面的4个字节（0 0 0 1）变成对应的内容的长度
	if (nal_type == NAL_TYPE_SPS ){
		
		int i=0;
		
		char* pDataAddrTmp = (char *)data;
		unsigned int u32DataLenTmp = size - 4;
		unsigned char u8NALTypeTmp = 0;
		unsigned char u8Find = 0;

		int length = size >128 ? 128 : size;
		
		for (i = 4; i < length && i < (int)u32DataLenTmp; i++)
		{
			if ((pDataAddrTmp[i + 0] == 0x0) && (pDataAddrTmp[i + 1] == 0x0)
				&& (pDataAddrTmp[i + 2] == 0x0) && (pDataAddrTmp[i + 3] == 0x1))
			{
				u8NALTypeTmp = *(pDataAddrTmp + i + 4) & 0x1F;
				
				if(u8NALTypeTmp== NAL_TYPE_PPS)
				{
					
					sps_length =i-4;
					temp =i;
					
					sps[0] = (sps_length & 0xff000000) >> 24;
					sps[1] = (sps_length & 0x00ff0000) >> 16;
					sps[2] = (sps_length & 0x0000ff00) >> 8;
					sps[3] =  sps_length & 0x000000ff;
					
					memcpy(sps+4, pDataAddrTmp+4, sps_length);
					
					//LOGD("[%s	%d] sps temp =%d,i =%d\n",__FUNCTION__,__LINE__,temp,i);
					
				}else if(u8NALTypeTmp == NAL_TYPE_SEI){
					
					if(pps_length ==0){
						
						pps_length = i-temp-4;
						
						pps[0] = (pps_length & 0xff000000) >> 24;
						pps[1] = (pps_length & 0x00ff0000) >> 16;
						pps[2] = (pps_length & 0x0000ff00) >> 8;
						pps[3] =  pps_length & 0x000000ff;
						
						memcpy(pps+4, pDataAddrTmp+temp+4,pps_length);
						
						temp =i;
						
						//LOGD("[%s	%d] pps temp =%d,i =%d\n",__FUNCTION__,__LINE__,temp,i);
						
					}
					
				}else if (u8NALTypeTmp == NAL_TYPE_IDR || u8NALTypeTmp == NAL_TYPE_SLICE){
					if(pps_length ==0){
						
						pps_length = i-temp-4;
						
						pps[0] = (pps_length & 0xff000000) >> 24;
						pps[1] = (pps_length & 0x00ff0000) >> 16;
						pps[2] = (pps_length & 0x0000ff00) >> 8;
						pps[3] =  pps_length & 0x000000ff;
						
						memcpy(pps+4, pDataAddrTmp+temp+4,pps_length);
						
						temp =i;
						
						 //LOGD("[%s	 %d] pps temp =%d,i =%d\n",__FUNCTION__,__LINE__,temp,i);
						
					}else{
						sei_length = i-temp-4;
						
						sei[0] = (sei_length & 0xff000000) >> 24;
						sei[1] = (sei_length & 0x00ff0000) >> 16;
						sei[2] = (sei_length & 0x0000ff00) >> 8;
						sei[3] =  sei_length & 0x000000ff;
						
						memcpy(sei+4, pDataAddrTmp+temp+4,sei_length);
						
						temp =i;
						//LOGD("[%s	%d] sei temp =%d,i =%d\n",__FUNCTION__,__LINE__,temp,i);
					}
					
					u8Find = 1;
					break;
				}
			}
		}
		
	}
	
	*spsLength = sps_length;
	*ppsLength = pps_length;
	*seiLength = sei_length;

	return temp;
}



//根据aac对象类型，采样率，声道数来获取aac配置信息
/*
 格式：5bits | 4bits | 4bits | 3bits
      第一栏   第二栏   第三栏   第四栏
 第一栏：AAC Object Type
 第二栏：SampleRate
 第三栏：Channel
 第四栏：Don‘t care 设 0
 
 举例 aacObjectType = LOW ,sampleRate = 44100,channle = 2
 第一栏：00010
 第二栏：0100
 第三栏：0010
 第四栏：000
 
 合起来 0001001000010000 =》 0x12 0x10
 */
static void getAAcConfig(unsigned char **pBuf,int aacObjectType,int sampleRate,int channle){
    
    unsigned char *pcTmp = NULL;
    pcTmp = (unsigned char *)malloc(2);
    *pBuf = pcTmp;
    
    unsigned char type = AAC_TYPE_LOW;
    if(aacObjectType==AAC_TYPE_MAIN){
        type = AAC_TYPE_MAIN;
    }else if(aacObjectType == AAC_TYPE_LOW){
        type = AAC_TYPE_LOW;
    }else if(aacObjectType == AAC_TYPE_SSR){
        type = AAC_TYPE_SSR;
    }else if(aacObjectType == AAC_TYPE_LTP){
        type = AAC_TYPE_LTP;
    }else{
        type = AAC_TYPE_LOW;
        LOGE("[%s   %d] set aacObjectType error set to default AAC_TYPE_LOW\n",__FUNCTION__,__LINE__);
    }
	
    unsigned char rate = 0;
    if (92017 <= sampleRate){
        rate = 0;
    }
    else if (75132 <= sampleRate){
        rate = 1;
    }
    else if (55426 <= sampleRate){
        rate = 2;
    }
    else if (46009 <= sampleRate){
        rate = 3;
    }
    else if (37566 <= sampleRate){
        rate = 4;
    }
    else if (27713 <= sampleRate){
        rate = 5;
    }
    else if (23004 <= sampleRate){
        rate = 6;
    }
    else if (18783 <= sampleRate){
        rate = 7;
    }
    else if (13856 <= sampleRate){
        rate = 8;
    }
    else if (11502 <= sampleRate){
        rate = 9;
    }
    else if (9391 <= sampleRate){
        rate = 10;
    }else{
		rate = 11;
	}
    
    LOGD("[%s   %d] type =%d ,rate = %d,channel =%d \n",__FUNCTION__,__LINE__,type,rate,channle);
    unsigned char byte1 = (type<<3 | rate>>1);
    
    unsigned char byte2 = (rate <<7 | channle <<3);
    
    pcTmp[0] = byte1;
    pcTmp[1] = byte2;
    
}

static void myMP4LogCallback(MP4LogLevel loglevel,const char*fmt,va_list ap){
	if(loglevel == MP4_LOG_ERROR){
		LOGE(fmt,ap);
	}else if(loglevel == MP4_LOG_WARNING){
		LOGD(fmt,ap);
	}else if(loglevel == MP4_LOG_INFO){
		LOGD(fmt,ap);
	}
	return;
}

static int mp4v2Create(RT_STRAM_OUT *stRtStreamOut,uint8_t *data ,int size){
    
    //从I帧开始保存数据，这样视频才会有所列图
    if ( NAL_TYPE_SPS != (getNaLType( data, size ) & 0x1F )){
        LOG_PRINT_HEX(data,0,60);
        return -1;
    }
    LOG_PRINT_HEX(data,0,60);
    
    int sps_length = 0;
    int pps_length = 0;
    int sei_length = 0;
    
    unsigned char sps[128];
    unsigned char pps[128];
    unsigned char sei[128];
    
    memset(sps,0,sizeof(sps));
    memset(pps,0,sizeof(pps));
    memset(sei,0,sizeof(sei));
    
    int ret = getNALInfo(data,size,sps,pps,sei,&sps_length,&pps_length,&sei_length);
	if(ret < 0){
		goto ERR_EXIT;
	}

	if(sps_length == 0 || pps_length == 0){
		LOGE("[%s	%d] sps_length=%d  pps_length=%d can not Parsing sps or pps from I Frame\n",__FUNCTION__,__LINE__,sps_length,pps_length);
		return -1;
	}

	 //创建mp4handler
    stRtStreamOut->stMp4FileHandle = MP4Create(stRtStreamOut->acFileName, 0);//MP4_CREATE_64BIT_DATA
    if(stRtStreamOut->stMp4FileHandle == MP4_INVALID_FILE_HANDLE){
        LOGE("[%s   %d] mp4create error filename=%s \n",__FUNCTION__,__LINE__,stRtStreamOut->acFileName);
        goto ERR_EXIT;
    }
	
    MP4SetTimeScale(stRtStreamOut->stMp4FileHandle, 90000);
    
    if(stRtStreamOut->s32Fps<=0){
        stRtStreamOut->s32Fps = 20;
        LOGE("[%s   %d] stRtStreamOut fps useing defaule 20 \n",__FUNCTION__,__LINE__);
    }
    
    stRtStreamOut->s32VideoTrackId = MP4AddH264VideoTrack(
                                                          stRtStreamOut->stMp4FileHandle,
                                                          90000,
                                                          90000/stRtStreamOut->s32Fps,
                                                          stRtStreamOut->s32Width,
                                                          stRtStreamOut->s32Height,
                                                          sps[5],
                                                          sps[6],
                                                          sps[7], 3);
    
    if(stRtStreamOut->s32VideoTrackId == MP4_INVALID_TRACK_ID){
        LOGE("[%s   %d] video track faile \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }
    
    MP4SetVideoProfileLevel(stRtStreamOut->stMp4FileHandle, 0x7F);
    
    //打印sps
    LOGD("[%s   %d] sps=",__FUNCTION__,__LINE__);
    LOG_PRINT_HEX(sps+4, 0, sps_length);
    MP4AddH264SequenceParameterSet(stRtStreamOut->stMp4FileHandle,
                                   stRtStreamOut->s32VideoTrackId,
                                   sps+4,
                                   sps_length);
    
    //打印pps
    LOGD("[%s   %d] pps=",__FUNCTION__,__LINE__);
    LOG_PRINT_HEX(pps+4, 0, pps_length);
    MP4AddH264PictureParameterSet(stRtStreamOut->stMp4FileHandle,
                                  stRtStreamOut->s32VideoTrackId,
                                  pps+4,
                                  pps_length);
    
    LOGD("[%s   %d] sei=",__FUNCTION__,__LINE__);
    LOG_PRINT_HEX(sei+4, 0, sei_length);
    
    LOGD("[%s   %d] start   \n",__FUNCTION__,__LINE__);
    
    //将音频置0
    stRtStreamOut->s32AudioTrackId = MP4_INVALID_TRACK_ID;

	stRtStreamOut->s32VideoWriteFrameCount = 0;
    stRtStreamOut->s32AudioWriteFrameCount = 0;
	
	gs_s8IsStartReadVideo = 0;

	//MP4LogSetLevel(MP4_LOG_ERROR | MP4_LOG_WARNING);
	//设计回调
	MP4SetLogCallback(myMP4LogCallback);
	
    return 0;
    
ERR_EXIT:
    
    LOGE("[%s   %d] error \n",__FUNCTION__,__LINE__);
    
    if(stRtStreamOut->stMp4FileHandle){
        MP4Close(stRtStreamOut->stMp4FileHandle, 0);
        stRtStreamOut->stMp4FileHandle = NULL;
        LOGE("[%s   %d] mp4 close \n",__FUNCTION__,__LINE__);
    }
    
    stRtStreamOut->s32VideoTrackId = MP4_INVALID_TRACK_ID;
    stRtStreamOut->s32AudioTrackId = MP4_INVALID_TRACK_ID;
    
    return -1;
}


static int mp4v2WriteVideoFrame(RT_STRAM_OUT *stRtStreamOut,int keyFrame,uint8_t *data ,int size){
    
    if(NULL == stRtStreamOut->stMp4FileHandle){
        LOGE("[%s   %d] stMp4FileHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }

	/*
	* 这里判断nal类型后5位的值，如果为0，那这帧属于错误的帧，不能保存，
	* 录制出来的有可能是B帧，直播过程不可能有b帧
	*/
	if((data[4] & 0x1F) == 0){
		LOGE("[%s   %d] NAL type is 0 \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
    int nalSize = size ;
	
    if(!keyFrame){
        
        nalSize = nalSize - 4;
        data[0] = (nalSize & 0xff000000) >> 24;
        data[1] = (nalSize & 0x00ff0000) >> 16;
        data[2] = (nalSize & 0x0000ff00) >> 8;
        data[3] = (nalSize & 0x000000ff);

		char rec = 0;
		
		stRtStreamOut->s32VideoWriteFrameCount++;
		
		if(!stRtStreamOut->s32SynTime){//如果不同步
			
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
		 	rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32VideoTrackId, data, size, MP4_INVALID_DURATION, 0, keyFrame);//MP4_INVALID_DURATION
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
		}else{
			
			long long tempvoltime=getSystemTime();
			if(stRtStreamOut->s64VideoVoltime == -1){
				stRtStreamOut->s64VideoVoltime = tempvoltime;
			}
			
			uint64_t duration = (tempvoltime-stRtStreamOut->s64VideoVoltime)*90000/1000;
			
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
			rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32VideoTrackId, data, size, duration, 0, keyFrame);//MP4_INVALID_DURATION
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
			stRtStreamOut->s64VideoVoltime = tempvoltime;
			
		}
		
		if(!rec){
			LOGE("[%s   %d] mp4 write video error\n",__FUNCTION__,__LINE__);
		}
    }else{
        
        int sps_length = 0;
        int pps_length = 0;
        int sei_length = 0;
        int i_length =0;
        
        unsigned char sps[128];
        unsigned char pps[128];
        unsigned char sei[128];
        
        
        memset(sps,0,sizeof(sps));
        memset(pps,0,sizeof(pps));
        memset(sei,0,sizeof(sei));
        
        int ret = getNALInfo(data,size,sps,pps,sei,&sps_length,&pps_length,&sei_length);
		if(ret < 0){
			return -1;
		}
		if(sps_length == 0 || pps_length == 0){
			LOGE("[%s	%d] sps_length=%d  pps_length=%d can not Parsing sps or pps from I Frame\n",__FUNCTION__,__LINE__,sps_length,pps_length);
			return -1;
		}
		
		int temp = ret;
        
        i_length = size-temp-4;

        uint8_t *newIFrame =(uint8_t*)malloc(size);
        memset(newIFrame,0,size);
        
        memcpy(newIFrame,sps,sps_length+4);
        memcpy(newIFrame+sps_length+4,pps,pps_length+4);
        int temp2 =0;
        
        if(sei_length != 0){
            memcpy(newIFrame+sps_length+4+pps_length+4,sei,sei_length+4);
            temp2 = sps_length+4 + pps_length+4 + sei_length+4;
        }else{
            temp2 = sps_length+4 + pps_length+4;
        }
        
        newIFrame[0+temp2] = (i_length & 0xff000000) >> 24;
        newIFrame[1+temp2] = (i_length & 0x00ff0000) >> 16;
        newIFrame[2+temp2] = (i_length & 0x0000ff00) >> 8;
        newIFrame[3+temp2] = (i_length & 0x000000ff);

        memcpy(newIFrame+temp2+4,data+temp+4,i_length);
        
		
		stRtStreamOut->s32VideoWriteFrameCount++;
		
		char rec = 0;
		if(!stRtStreamOut->s32SynTime){//如果不同步
		
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
	        rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32VideoTrackId, newIFrame, size, MP4_INVALID_DURATION, 0, keyFrame);
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
		}else{
			
			long long tempvoltime=getSystemTime();
			if(stRtStreamOut->s64VideoVoltime == -1){
				stRtStreamOut->s64VideoVoltime = tempvoltime;
			}

			//mp4中一般将一秒分为90000份，duration就是时间段内多少个1/90000，时间为秒，所以除以1000
			uint64_t duration = (tempvoltime-stRtStreamOut->s64VideoVoltime)*90000/1000;
			
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
			rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32VideoTrackId, newIFrame, size, duration, 0, keyFrame);//MP4_INVALID_DURATION
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
			stRtStreamOut->s64VideoVoltime = tempvoltime;
			
		}
		if(!rec){
			LOGE("[%s	 %d] mp4 write video error \n",__FUNCTION__,__LINE__);
		}
		free(newIFrame);
		
    }
    return 0;
}

static int mp4v2WriteAudioFrame(RT_STRAM_OUT *stRtStreamOut,uint8_t *data ,int size){
    //音频
#if 1
    
    //将音频的创建放到这里来是因为ios，如果创建音频，不写音频数据会出现视频播放不了（QuickTimer play）
    if(stRtStreamOut->stMp4FileHandle){
        
        if(stRtStreamOut->s32AudioTrackId == MP4_INVALID_TRACK_ID){
            if(NULL == stRtStreamOut->stRtAudioParams){
                LOGE("[%s   %d] stRtAudioParams == NULL\n",__FUNCTION__,__LINE__);
                return -1;
            }
            
            int aacObjectType = stRtStreamOut->stRtAudioParams->s32Profile + 1;//aac 类型，这里要加1,mp4v2内部Profile都是+1的
            int sampleRate = stRtStreamOut->stRtAudioParams->s32Sample_rate; //采样率
            int channle = stRtStreamOut->stRtAudioParams->s32Channel; //信道

			/*uint8_t audioType = MP4_MPEG4_AAC_LC_AUDIO_TYPE;
			if(aacObjectType == AAC_TYPE_LOW){
				audioType = MP4_MPEG4_AAC_LC_AUDIO_TYPE;
				LOGD("[%s   %d] MP4_MPEG4_AAC_LC_AUDIO_TYPE\n",__FUNCTION__,__LINE__);
			}else if(aacObjectType == AAC_TYPE_MAIN){
				audioType = MP4_MPEG4_AAC_MAIN_AUDIO_TYPE;
				LOGD("[%s   %d] MP4_MPEG4_AAC_MAIN_AUDIO_TYPE\n",__FUNCTION__,__LINE__);
			}else if(aacObjectType == AAC_TYPE_SSR){
				audioType = MP4_MPEG4_AAC_SSR_AUDIO_TYPE;
				LOGD("[%s   %d] MP4_MPEG4_AAC_SSR_AUDIO_TYPE\n",__FUNCTION__,__LINE__);
			}else if(aacObjectType == AAC_TYPE_LTP){
				audioType = MP4_MPEG4_AAC_LTP_AUDIO_TYPE;
				LOGD("[%s   %d] MP4_MPEG4_AAC_LTP_AUDIO_TYPE\n",__FUNCTION__,__LINE__);
			}*/
			
            
            //打开后ios播放不了，
            stRtStreamOut->s32AudioTrackId = MP4AddAudioTrack(stRtStreamOut->stMp4FileHandle,
                                                              sampleRate,
                                                              1024,
                                                              MP4_MPEG4_AUDIO_TYPE);
            
            if(stRtStreamOut->s32AudioTrackId == MP4_INVALID_TRACK_ID){
                LOGE("[%s   %d] audio track faile \n",__FUNCTION__,__LINE__);
                return -1;
            }
            
            
            LOGD("[%s   %d] aacObjectType =%d sampleRate =%d channle =%d\n",__FUNCTION__,__LINE__,aacObjectType,sampleRate,channle);
            
            //根据aac对象类型，采样率，声道数来获取aac配置信息
            unsigned char *pBuf = NULL;
            getAAcConfig(&pBuf, aacObjectType, sampleRate, channle);
            
            if(pBuf!=NULL){
                LOGD("[%s   %d] accConfig = ",__FUNCTION__,__LINE__);
                LOG_PRINT_HEX(pBuf, 0, 2);
                
                MP4SetAudioProfileLevel(stRtStreamOut->stMp4FileHandle, aacObjectType);
                MP4SetTrackESConfiguration(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32AudioTrackId, pBuf, 2);
                
                free(pBuf);
                
            }else{
                LOGE("[%s   %d] accConfig == NULL \n",__FUNCTION__,__LINE__);
            }
        }
    }else{
         LOGE("[%s   %d] stMp4FileHandle == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
#endif

	//这里主要是为了不让视频后面出现，图像卡，有音频的情况，有些手机播放器会因为这个原因导致视频
	//播放失败
	if(stRtStreamOut->s32AudioWriteFrameCount - stRtStreamOut->s32VideoWriteFrameCount >= 50){
		LOGD("[%s   %d] s32AudioWriteFrameCount =%d - s32VideoWriteFrameCount=%d > 50\n",
			__FUNCTION__,__LINE__,stRtStreamOut->s32AudioWriteFrameCount,stRtStreamOut->s32VideoWriteFrameCount);
		return -1;
	}
	
	stRtStreamOut->s32AudioWriteFrameCount++;
	
	static char isHaveHead = 1;
	//如果aac数据包含头
	if(data[0] ==0xff && (data[1] & 0xf0) == 0xf0){
		
		if(!isHaveHead){
			isHaveHead = 1;
			LOGD("[%s   %d] isHaveAACHead is change to = %d\n",__FUNCTION__,__LINE__,isHaveHead);
		}

		char rec = 0;

		if(!stRtStreamOut->s32SynTime){//如果不同步
			
			//写到mp4不需要头，需要去掉头
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
    		rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32AudioTrackId, &data[7], size -7, MP4_INVALID_DURATION, 0, 1);
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
		}else{
			
			long long tempvoltime = getSystemTime();
			if(stRtStreamOut->s64AudioVoltime == -1){
				stRtStreamOut->s64AudioVoltime = tempvoltime;
			}

			//音频的time_base = 1/sample_rate,即一秒分成采样率份，
			uint64_t duration = (tempvoltime-stRtStreamOut->s64AudioVoltime)*(stRtStreamOut->stRtAudioParams->s32Sample_rate)/1000;

			SDL_LockMutex(stRtStreamOut->pSDLMutex);
			rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32AudioTrackId, &data[7], size -7, duration, 0, 1);//MP4_INVALID_DURATION
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
			stRtStreamOut->s64AudioVoltime = tempvoltime;
			
		}
		if(!rec){
            LOGE("[%s    %d] mp4 write audio error \n",__FUNCTION__,__LINE__);
        }
        
	}else{
		
		if(isHaveHead){
			isHaveHead = 0;
			LOGD("[%s   %d] isHaveAACHead is change to = %d\n",__FUNCTION__,__LINE__,isHaveHead);
		}
    	char rec = 0;
		
		if(!stRtStreamOut->s32SynTime){//如果不同步
			SDL_LockMutex(stRtStreamOut->pSDLMutex);
    		rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32AudioTrackId, data, size , MP4_INVALID_DURATION, 0, 1);
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
		}else{
			
			long long tempvoltime = getSystemTime();
			if(stRtStreamOut->s64AudioVoltime == -1){
				stRtStreamOut->s64AudioVoltime = tempvoltime;
			}
			
			uint64_t duration = (tempvoltime-stRtStreamOut->s64AudioVoltime)*(stRtStreamOut->stRtAudioParams->s32Sample_rate)/1000;

			SDL_LockMutex(stRtStreamOut->pSDLMutex);
			rec = MP4WriteSample(stRtStreamOut->stMp4FileHandle, stRtStreamOut->s32AudioTrackId, data, size, duration, 0, 1);//MP4_INVALID_DURATION
			SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
			
			stRtStreamOut->s64AudioVoltime = tempvoltime;
			
		}
		if(!rec){
            LOGE("[%s    %d] mp4 write audio error \n",__FUNCTION__,__LINE__);
        }
		
	}
    return 0;
}

int rt_stream_out_init(RT_STRAM_OUT *stRtStreamOut,RT_AUDIO_TYPE audioType,int width,int height,int fps,int s32SynTime){
	
    if(NULL == stRtStreamOut){
        LOGE("[%s   %d] stRtStreamOut == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    //fps要正确设置，要不录制后的视频会出现块放或者慢放的情况
    stRtStreamOut->s32Fps = fps;
    stRtStreamOut->s32Width = width;
    stRtStreamOut->s32Height = height;
    stRtStreamOut->s32Reset = 0;
	stRtStreamOut->s32SynTime = s32SynTime;
	stRtStreamOut->s64AudioVoltime = -1;
	stRtStreamOut->s64VideoVoltime = -1;
	
	
	if(s32SynTime){
		LOGD("[%s   %d] syntime type to save mp4\n",__FUNCTION__,__LINE__);
	}
    
    if(stRtStreamOut->s32Width == 0 || stRtStreamOut->s32Height == 0){
        LOGE("[%s   %d] error width = %d ,height = %d ,fps = %d \n",__FUNCTION__,__LINE__,width,height,fps);
        return -1;
    }
    LOGD("[%s   %d] width = %d ,height = %d ,fps = %d \n",__FUNCTION__,__LINE__,width,height,fps);
    
    //存储视频的临时buf
    stRtStreamOut->pVideoBuf = (uint8_t *)malloc(RT_MAX_VIDEO_BUF_SIZE);
    if(!stRtStreamOut->pVideoBuf){
        LOGE("[%s   %d] pVideoBuf malloc faile\n",__FUNCTION__,__LINE__);
		goto ERR_EXIT;
    }
	
	//存储音频的临时buf
	stRtStreamOut->pAudioBuf = (uint8_t *)malloc(RT_MAX_AAC_FRAME_SIZE);
    if(!stRtStreamOut->pAudioBuf){
        LOGE("[%s   %d] pAudioBuf malloc faile\n",__FUNCTION__,__LINE__);
		goto ERR_EXIT;
    }

	//锁，用于同步音视频
	stRtStreamOut->pSDLMutex = SDL_CreateMutex();
    if(NULL == stRtStreamOut->pSDLMutex){
        LOGE("[%s   %d] SDL_CreateMutex error \n",__FUNCTION__,__LINE__);
        goto ERR_EXIT;
    }

	stRtStreamOut->enRtAudioType = audioType;

	//如果添加的是pcm数据，需要将pcm数据编码为aac才可以存储
	if(audioType == RT_AUDIO_TYPE_PCM){
		  
		  int sample_rate = 8000;
		  int s32Profile = FF_PROFILE_AAC_LOW;
		  int s32Channel = 1;
		  
		  if(stRtStreamOut->stRtAudioParams){
			 sample_rate = stRtStreamOut->stRtAudioParams->s32Sample_rate;
			 s32Profile = stRtStreamOut->stRtAudioParams->s32Profile;
			 s32Channel = stRtStreamOut->stRtAudioParams->s32Channel;
		  }else{
			LOGD("[%s   %d] stRtAudioParams == NULL set to default sample_rate = 8000,s32Profile = FF_PROFILE_AAC_LOW,s32Channel = 1\n",__FUNCTION__,__LINE__);
		  }

		  //查找编码器
		  //stRtStreamOut->pAudioCodec = avcodec_find_encoder(AV_CODEC_ID_AAC);
		  stRtStreamOut->pAudioCodec = avcodec_find_encoder_by_name("libfdk_aac");
		  if(NULL == stRtStreamOut->pAudioCodec){
			  LOGE("[%s   %d] avcodec_find_encoder error\n",__FUNCTION__,__LINE__);
			  goto ERR_EXIT;
		  }
		  
		  stRtStreamOut->pAudioCodecCtx = avcodec_alloc_context3(stRtStreamOut->pAudioCodec);
		  if(NULL == stRtStreamOut->pAudioCodecCtx){
			  LOGE("[%s   %d] avcodec_alloc_context3 error\n",__FUNCTION__,__LINE__);
			  goto ERR_EXIT;
		  }
		  
		  stRtStreamOut->pAudioCodecCtx->sample_fmt = AV_SAMPLE_FMT_S16;
		  stRtStreamOut->pAudioCodecCtx->sample_rate = sample_rate;

		  //检查编码器是否可用
		  if(!checkSampleFmt(stRtStreamOut->pAudioCodec,AV_SAMPLE_FMT_S16)){
			  LOGE("[%s   %d] encoder does not support sample format %s\n",__FUNCTION__,__LINE__,av_get_sample_fmt_name(stRtStreamOut->pAudioCodecCtx->sample_fmt));
			  goto ERR_EXIT;
		  }
		  
		  //单声道
		  stRtStreamOut->pAudioCodecCtx->channels = s32Channel;
		  stRtStreamOut->pAudioCodecCtx->channel_layout = av_get_default_channel_layout(s32Channel);
		  
		  stRtStreamOut->pAudioCodecCtx->codec_type = AVMEDIA_TYPE_AUDIO;
		  stRtStreamOut->pAudioCodecCtx->codec_id = AV_CODEC_ID_AAC;
		  stRtStreamOut->pAudioCodecCtx->profile = s32Profile;
		  
		  if(avcodec_open2(stRtStreamOut->pAudioCodecCtx, stRtStreamOut->pAudioCodec, NULL) < 0){
			  LOGE("[%s   %d] avcodec_open2 error\n",__FUNCTION__,__LINE__);
			  goto ERR_EXIT;
		  }

		  //根据采样率，信道等信息确认pcm要转为aac所需要的buf长度(即多长的pcm数据可以转成一帧aac，用来存储mp4)
		  stRtStreamOut->s32pcmFrameSize = av_samples_get_buffer_size(
		  NULL,
		  stRtStreamOut->pAudioCodecCtx->channels, 
		  stRtStreamOut->pAudioCodecCtx->frame_size, 
		  stRtStreamOut->pAudioCodecCtx->sample_fmt, 
		  1);
		  
		  LOGD("[%s   %d] avcodec_open2 success size =%d channels=%d sample_rate=%d  frame_size=%d\n",__FUNCTION__,__LINE__,
			  	stRtStreamOut->s32pcmFrameSize,
			  	stRtStreamOut->pAudioCodecCtx->channels,
			  	stRtStreamOut->pAudioCodecCtx->sample_rate,
			  	stRtStreamOut->pAudioCodecCtx->frame_size);
		  

		  //初始化好编码所用的avFrame,待编码pcm数据就存储在这个结构体重
		  stRtStreamOut->pPcmFrame = av_frame_alloc();
		  if(NULL == stRtStreamOut->pPcmFrame){
			  LOGE("[%s   %d] malloc pPcmFrame error\n",__FUNCTION__,__LINE__);
			  goto ERR_EXIT;
		  }
		  //要指定要对应的参数采样率，信道，格式等，要不然编码会失败
		  stRtStreamOut->pPcmFrame->sample_rate = stRtStreamOut->pAudioCodecCtx->sample_rate;
		  stRtStreamOut->pPcmFrame->format = stRtStreamOut->pAudioCodecCtx->sample_fmt;
		  stRtStreamOut->pPcmFrame->nb_samples = 1024;
		  stRtStreamOut->pPcmFrame->channels = stRtStreamOut->pAudioCodecCtx->channels;
		  
		  //初始化好存储pcm数据的buf，并且填充到pPcmFrame中
		  stRtStreamOut->pcmFrameBuf = (uint8_t *) av_malloc(stRtStreamOut->s32pcmFrameSize);
		  if(NULL == stRtStreamOut->pPcmFrame){
			  LOGE("[%s   %d] malloc pcmFrameBuf error\n",__FUNCTION__,__LINE__);
			  goto ERR_EXIT;
		  }
		  avcodec_fill_audio_frame(stRtStreamOut->pPcmFrame, 
		  	stRtStreamOut->pAudioCodecCtx->channels, 
		  	stRtStreamOut->pAudioCodecCtx->sample_fmt, 
		  	stRtStreamOut->pcmFrameBuf, 
		  	stRtStreamOut->s32pcmFrameSize, 
		  	1);

		  
	}
	
	return 0;

ERR_EXIT:
	
    if(stRtStreamOut->pVideoBuf){
        free(stRtStreamOut->pVideoBuf);
        stRtStreamOut->pVideoBuf = NULL;
    }

	if(stRtStreamOut->pAudioBuf){
        free(stRtStreamOut->pAudioBuf);
        stRtStreamOut->pAudioBuf = NULL;
    }

	if(stRtStreamOut->pSDLMutex){
		SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
        SDL_DestroyMutex(stRtStreamOut->pSDLMutex);
        stRtStreamOut->pSDLMutex = NULL;
	}
	
    if(stRtStreamOut->pcmFrameBuf){
        av_free(stRtStreamOut->pcmFrameBuf);
        stRtStreamOut->pcmFrameBuf = NULL;
    }
	
    if(stRtStreamOut->pPcmFrame){
        av_frame_free(&stRtStreamOut->pPcmFrame);
        stRtStreamOut->pPcmFrame = NULL;
    }
    
    if(stRtStreamOut->pAudioCodecCtx){
        avcodec_free_context(&stRtStreamOut->pAudioCodecCtx);
        stRtStreamOut->pAudioCodecCtx = NULL;
    }
	
    if(stRtStreamOut->stRtAudioParams){
        //free(stRtStreamOut->stRtAudioParams);
        stRtStreamOut->stRtAudioParams = NULL;
    }
    
    return -1;
}





//开始视频录制，调用改方法后不回真正的录像，真正的视频保存还是要调用write的方法
int rt_stream_out_start(RT_STRAM_OUT *stRtStreamOut,const char*filename){
    if(NULL == stRtStreamOut){
        LOGE("[%s   %d] stRtStreamOut == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    if(filename){
		memset(stRtStreamOut->acFileName, 0, sizeof(stRtStreamOut->acFileName));
        strcpy(stRtStreamOut->acFileName, filename);
    }else{
        LOGE("[%s   %d] filename == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    LOGD("[%s   %d] filename = %s \n",__FUNCTION__,__LINE__,filename);
    
    //将录像状态置为真
    stRtStreamOut->enRtVideoRecState = RT_VIDEO_REC;

	gs_s8IsWriteVideoEnd = 1;
	gs_s8IsWriteAudioEnd = 1;
    
    return 0;
    
}

//写视频数据
int rt_stream_out_write_video_h264(RT_STRAM_OUT *stRtStreamOut,AVPacket *stAVPacket){
    
    if(NULL == stAVPacket){
        LOGE("[%s   %d] NULL== stAVPacket \n",__FUNCTION__,__LINE__);
        return -1;
    }

	gs_s8IsWriteVideoEnd = 0;
	  
    //将视频数据拷贝到零时buf中
    memcpy(stRtStreamOut->pVideoBuf, stAVPacket->data, stAVPacket->size);
    int size = stAVPacket->size;
    
    if(NULL == stRtStreamOut->stMp4FileHandle){
        mp4v2Create(stRtStreamOut, stRtStreamOut->pVideoBuf, size);
    }
    
    if(stRtStreamOut->stMp4FileHandle){
      
        //如果重置
        if(stRtStreamOut->s32Reset){
            //从I帧开始保存数据
            if ( NAL_TYPE_SPS != (getNaLType(stRtStreamOut->pVideoBuf, size ) & 0x1F )){
                LOG_PRINT_HEX(stRtStreamOut->pVideoBuf,0,40);
				gs_s8IsWriteVideoEnd = 1;
                return -1;
            }
            stRtStreamOut->s32Reset = 0;
        }
		
        
        mp4v2WriteVideoFrame(stRtStreamOut,stAVPacket->flags,stRtStreamOut->pVideoBuf,size);
		
		if(!gs_s8IsStartReadVideo){
			LOGE("[%s   %d] write video frame first \n",__FUNCTION__,__LINE__);
		}
		gs_s8IsStartReadVideo = 1;
		
    }else{
    	gs_s8IsWriteVideoEnd = 1;
        LOGE("[%s   %d] stMp4FileHandle is NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    gs_s8IsWriteVideoEnd = 1;
    return 0;
}


//写音频数据
int rt_stream_out_write_audio_aac(RT_STRAM_OUT *stRtStreamOut,AVPacket *stAVPacket){
     if(NULL == stAVPacket){
        LOGE("[%s   %d] NULL== stAVPacket \n",__FUNCTION__,__LINE__);
        return -1;
    }
    gs_s8IsWriteAudioEnd = 0;
    //将视频数据拷贝到零时buf中，因为是一帧aac的数据，不需要做特色的处理
    memcpy(stRtStreamOut->pAudioBuf, stAVPacket->data, stAVPacket->size);
    int size = stAVPacket->size;
	
    if(stRtStreamOut->stMp4FileHandle){
		
		if(gs_s8IsStartReadVideo){
        	mp4v2WriteAudioFrame(stRtStreamOut, stRtStreamOut->pAudioBuf, size);
		}else{
			LOGE("[%s   %d] write audio frame faile wait write video frame first \n",__FUNCTION__,__LINE__);
		}
		
    }else{
        LOGE("[%s   %d] stMp4FileHandle is NULL \n",__FUNCTION__,__LINE__);
		gs_s8IsWriteAudioEnd = 1;
        return -1;
    }
	gs_s8IsWriteAudioEnd = 1;
    return 0;
}


int rt_stream_out_write_video_h265(RT_STRAM_OUT *stRtStreamOut,AVPacket *stAVPacket){
	
	return 0;
}

int rt_stream_out_write_audio_pcm(RT_STRAM_OUT *stRtStreamOut,AVPacket *stAVPacket){
	
	if(!stRtStreamOut->stMp4FileHandle){
		LOGE("[%s	%d] stMp4FileHandle is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	if(!gs_s8IsStartReadVideo){
		LOGE("[%s	%d] write audio frame faile wait write video frame first \n",__FUNCTION__,__LINE__);
		return -1;
	}
	if(NULL == stAVPacket){
		LOGE("[%s	%d] NULL== stAVPacket \n",__FUNCTION__,__LINE__);
		return -1;
	}
	if(NULL == stRtStreamOut->pAudioCodecCtx){
		LOGE("[%s	%d] NULL== pAudioCodecCtx \n",__FUNCTION__,__LINE__);
		return -1;
	}
	if(NULL == stRtStreamOut->pPcmFrame){
		LOGE("[%s	%d] NULL== pPcmFrame \n",__FUNCTION__,__LINE__);
		return -1;
	}
	
	int s32Rec = 0;
	
#if 1
	
	gs_s8IsWriteAudioEnd = 0;
	//将pcm数据赋值，并送去编码成aac
	memcpy(stRtStreamOut->pPcmFrame->data[0], stAVPacket->data, stAVPacket->size);
	s32Rec = avcodec_send_frame(stRtStreamOut->pAudioCodecCtx,stRtStreamOut->pPcmFrame);
	if(s32Rec != 0){
		LOGE("[%s	%d] avcodec_send_frame error \n",__FUNCTION__,__LINE__);
		LOG_PRINT_HEX(stAVPacket->data, 0, 30);
		goto ERR_EXIT;
	}
	s32Rec = avcodec_receive_packet(stRtStreamOut->pAudioCodecCtx,&stRtStreamOut->avPacket);
	if(s32Rec != 0){
		LOGE("[%s	%d] avcodec_receive_packet error \n",__FUNCTION__,__LINE__);
		LOG_PRINT_HEX(stAVPacket->data, 0, 30);
		goto ERR_EXIT;
	}
	
#else
	
	int gotPackcet;
	s32Rec = avcodec_encode_audio2(stRtStreamOut->pAudioCodecCtx, stAVPacket, stRtStreamOut->pPcmFrame, &gotPackcet);
	
#endif
	
	if(gs_s8IsStartReadVideo){
		int size = stRtStreamOut->avPacket.size;
		//写aac数据
		mp4v2WriteAudioFrame(stRtStreamOut, stRtStreamOut->avPacket.data,size);
	}else{
		LOGE("[%s	%d] write audio frame faile wait write video frame first \n",__FUNCTION__,__LINE__);
	}
	av_packet_unref(&stRtStreamOut->avPacket); 
	gs_s8IsWriteAudioEnd = 1;
	
	return 0;
		
ERR_EXIT:
	gs_s8IsWriteAudioEnd = 1;
	return -1;
}


/*
pFrame:格式可以为yuv420p,rgba,rgb24,即解码好后的数据,
srcW:源视频的宽
srcH:源视频的高
dstW:得到的图片的宽
dstH:得到的图片的高
filePath:图标保存的路径，全程
在没有特别需求的情况下srcW 跟 dstW ,srcH 跟 dstH的值是相同的
当720p截图得到1080p的时候，srcW 跟 dstW的值就要对应的设置
*/
int rt_stream_out_write_pic_jpeg(AVFrame* pFrame, int srcW, int srcH,int dstW,int dstH, const char*filePath){
	if(!pFrame || pFrame->format < 0){
		LOGE("[%s	%d]pFrame == NULL or pFrame->format < 0 \n",__FUNCTION__,__LINE__);  
		goto ERR_EXIT; 
	}
	
	AVCodec *pCodec = NULL;
    AVCodecContext *pCodecCtx = NULL;
	AVOutputFormat* fmt = NULL;
	AVStream* video_st = NULL;
	AVPacket pkt;
	av_init_packet(&pkt);
    pkt.data = NULL;    // packet data will be allocated by the encoder
    pkt.size = 0;
	AVFormatContext* pFormatCtx = NULL; 
	struct SwsContext *img_convert_ctx;
	AVFrame *pstAVFrame = NULL;
	
	pFormatCtx= avformat_alloc_context();
    fmt = av_guess_format("mjpeg", NULL, NULL);  
    pFormatCtx->oformat = fmt;
    if (avio_open(&pFormatCtx->pb,filePath, AVIO_FLAG_READ_WRITE) < 0){  
        LOGE("[%s   %d] Couldn't open output file.\n",__FUNCTION__,__LINE__);  
        goto ERR_EXIT;
    }

	video_st = avformat_new_stream(pFormatCtx, 0);  
    if (video_st==NULL){  
        goto ERR_EXIT; 
    }
	
	pCodecCtx = video_st->codec;  
    pCodecCtx->codec_id = fmt->video_codec;  
    pCodecCtx->codec_type = AVMEDIA_TYPE_VIDEO;  
    pCodecCtx->pix_fmt = AV_PIX_FMT_YUVJ420P;  
  
    pCodecCtx->width = dstW;
    pCodecCtx->height = dstH;
  
    pCodecCtx->time_base.num = 1;
    pCodecCtx->time_base.den = 25;
    av_dump_format(pFormatCtx, 0, filePath, 1);  

	pCodec = avcodec_find_encoder(pCodecCtx->codec_id);  
    if (!pCodec){  
        LOGE("[%s   %d] Codec not found.\n",__FUNCTION__,__LINE__);  
        goto ERR_EXIT; 
    }
    if (avcodec_open2(pCodecCtx, pCodec,NULL) < 0){  
        LOGE("[%s   %d] Could not open codec.\n",__FUNCTION__,__LINE__);  
        goto ERR_EXIT; 
    }


	int rec = avformat_write_header(pFormatCtx,NULL);
	if(rec <0){
		LOGE("[%s   %d] avformat_write_header error\n",__FUNCTION__,__LINE__);  
		goto ERR_EXIT; 
	}

	

	/*如果要保存的宽高跟源宽高不同，需要缩放*/
	if(dstH!=srcH || dstW !=srcW){
		
		img_convert_ctx = sws_getContext(
			srcW, 
			srcH, 
			pFrame->format, 
			dstW, 
			dstH, 
			AV_PIX_FMT_YUVJ420P, 
			SWS_BICUBIC, 
			NULL, NULL, NULL);
		
		if(img_convert_ctx == NULL){
			LOGE("[%s	%d] img_convert_ctx == NULL\n",__FUNCTION__,__LINE__);
			return -1;
		}
		
		pstAVFrame = av_frame_alloc();
		if(NULL == pstAVFrame){
			LOGE("[%s	%d] av_frame_alloc error \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT; 
		}
		
		int s32NumBytes = av_image_get_buffer_size(AV_PIX_FMT_YUVJ420P,dstW, dstH,1);
		
		uint8_t *buffer = (uint8_t *) av_malloc(s32NumBytes * sizeof(uint8_t));
		if(NULL == buffer){
			LOGE("[%s	%d] av_malloc error \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT; 
		}
		
		rec = av_image_fill_arrays(pstAVFrame->data, pstAVFrame->linesize,buffer,
							 AV_PIX_FMT_YUVJ420P,dstW,dstH,1);
		if(rec < 0){
			LOGE("[%s	%d] av_image_fill_arrays error \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT; 
		}
	
		pstAVFrame->width = srcW;
		pstAVFrame->height = srcH;
		pstAVFrame->format = AV_PIX_FMT_YUVJ420P;
		
		sws_scale(img_convert_ctx, 
			(const uint8_t* const*)pFrame->data, 
			pFrame->linesize, 0,
			srcH, pstAVFrame->data, pstAVFrame->linesize);

		int s32Rec = avcodec_send_frame(pCodecCtx,pstAVFrame);
		if(s32Rec != 0){
			LOGE("[%s	%d] avcodec_send_frame error \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT; 
		}
		
	}else{
		int s32Rec = avcodec_send_frame(pCodecCtx,pFrame);
		if(s32Rec != 0){
			LOGE("[%s	%d] avcodec_send_frame error \n",__FUNCTION__,__LINE__);
			goto ERR_EXIT; 
		}
	}
	
	av_new_packet(&pkt,pstAVFrame->width*pCodecCtx->height*3); 
	int s32Rec = avcodec_receive_packet(pCodecCtx,&pkt);
	if(s32Rec != 0){
		LOGE("[%s	%d] avcodec_receive_packet error \n",__FUNCTION__,__LINE__);
		goto ERR_EXIT;  
	}
	
	if(pkt.size == 0){
		LOGE("[%s	%d] pkt.size =%d \n",__FUNCTION__,__LINE__,pkt.size);  
		goto ERR_EXIT; 
	}
	if(pkt.data == NULL){
		LOGE("[%s	%d] pkt.data = NULL \n",__FUNCTION__,__LINE__);  
		goto ERR_EXIT; 
	}
	
	LOGD("[%s	%d] pkt.size =%d  w =%d  h= %d\n",__FUNCTION__,__LINE__,pkt.size,dstW,dstH);

	pkt.stream_index = video_st->index;  
    s32Rec = av_write_frame(pFormatCtx, &pkt);
	if(s32Rec != 0){
		LOGE("[%s	%d] av_write_frame error \n",__FUNCTION__,__LINE__);
		goto ERR_EXIT;
	}
	
 	av_packet_unref(&pkt); 
    av_write_trailer(pFormatCtx);
	if(pstAVFrame){
		av_frame_free(&pstAVFrame);
	}
	if(img_convert_ctx){
		sws_freeContext(img_convert_ctx);
	}
	
	avcodec_close(pCodecCtx);
	avio_close(pFormatCtx->pb);
    avformat_free_context(pFormatCtx);
	
    return 0;
ERR_EXIT:

	av_packet_unref(&pkt);
	
	if(img_convert_ctx){
		sws_freeContext(img_convert_ctx);
	}

	if(pstAVFrame){
		av_frame_free(&pstAVFrame);
	}

	if(pCodecCtx){
		avcodec_close(pCodecCtx);
	}

	if(pFormatCtx && pFormatCtx->pb){
		avio_close(pFormatCtx->pb);
	}

	if(pFormatCtx){
		avformat_free_context(pFormatCtx);
	}
	
	return -1;
}


//重置录像，调用该方法后，会在原来的录像视频上从i帧开始录像
//主要的用处在于，视频在录像过程中，出现视频流隔一段时间才来，为了保障后面录制的视频不出现花屏
int rt_stream_out_reset(RT_STRAM_OUT *stRtStreamOut){
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    stRtStreamOut->s32Reset = 1;
    return 0;
}


//停止录像
int rt_stream_out_stop(RT_STRAM_OUT *stRtStreamOut){
    
    if(NULL == stRtStreamOut){
        LOGE("[%s   %d] stRtStreamOut == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
	
	LOGD("[%s   %d] s32VideoWriteFrameCount=%d , s32AudioWriteFrameCount=%d\n",__FUNCTION__,__LINE__,stRtStreamOut->s32VideoWriteFrameCount,stRtStreamOut->s32AudioWriteFrameCount);

	if(stRtStreamOut->enRtVideoRecState == RT_VIDEO_REC){
		stRtStreamOut->enRtVideoRecState = RT_VIDEO_ENREC;
		SDL_Delay(30);
	}
	
	if(!gs_s8IsWriteAudioEnd || !gs_s8IsWriteVideoEnd){
		SDL_Delay(200);
		LOGD("[%s   %d] gs_s8IsWriteAudioEnd=%d  gs_s8IsWriteVideoEnd=%d\n",__FUNCTION__,__LINE__,
			gs_s8IsWriteAudioEnd,gs_s8IsWriteVideoEnd);
	}
	

    if(stRtStreamOut->stMp4FileHandle){
        MP4Close(stRtStreamOut->stMp4FileHandle, 0);
        stRtStreamOut->stMp4FileHandle = NULL;
        LOGD("[%s   %d] mp4 close \n",__FUNCTION__,__LINE__);
    }
	
	if(stRtStreamOut->pSDLMutex){
		SDL_UnlockMutex(stRtStreamOut->pSDLMutex);
        SDL_DestroyMutex(stRtStreamOut->pSDLMutex);
        stRtStreamOut->pSDLMutex = NULL;
		LOGD("[%s   %d] pSDLMutex free success \n",__FUNCTION__,__LINE__);
	}
	
    if(stRtStreamOut->pVideoBuf){
        free(stRtStreamOut->pVideoBuf);
        stRtStreamOut->pVideoBuf = NULL;
        LOGD("[%s   %d] pvideoBuf free success \n",__FUNCTION__,__LINE__);
    }

	if(stRtStreamOut->pAudioBuf){
        free(stRtStreamOut->pAudioBuf);
        stRtStreamOut->pAudioBuf = NULL;
        LOGD("[%s   %d] pAudioBuf free success \n",__FUNCTION__,__LINE__);
    }

	
	if(stRtStreamOut->pcmFrameBuf){
		
        av_free(stRtStreamOut->pcmFrameBuf);
        stRtStreamOut->pcmFrameBuf = NULL;
        LOGD("[%s   %d] pcmFrameBuf free success \n",__FUNCTION__,__LINE__);
    }
    
    if(stRtStreamOut->pPcmFrame){
        av_frame_free(&stRtStreamOut->pPcmFrame);
        stRtStreamOut->pPcmFrame = NULL;
        LOGD("[%s   %d] pPcmFrame free success \n",__FUNCTION__,__LINE__);
    }
    
    if(stRtStreamOut->pAudioCodecCtx){
        avcodec_free_context(&stRtStreamOut->pAudioCodecCtx);
        stRtStreamOut->pAudioCodecCtx = NULL;
        LOGD("[%s   %d] pAudioCodecCtx free success \n",__FUNCTION__,__LINE__);
    }
	
	av_packet_unref(&stRtStreamOut->avPacket);
    
    //这两个不需要free，因为他跟audio中的stRtAudioParams指向相同的内存
    if(stRtStreamOut->stRtAudioParams){
        stRtStreamOut->stRtAudioParams = NULL;
    }
    stRtStreamOut->s32VideoTrackId = 0;
    stRtStreamOut->s32AudioTrackId = 0;
    
    gs_s8IsStartReadVideo = 0;
    gs_s8IsWriteVideoEnd = 1;
	gs_s8IsWriteAudioEnd = 1;
    return 0;
}


