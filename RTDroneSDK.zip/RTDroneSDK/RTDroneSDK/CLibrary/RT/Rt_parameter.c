//
//  Rt_parameter.c
//  RTP2PApp
//
//  Created by 杨青远 on 2017/6/10.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#include <stdio.h>
#include "Rt_parameter.h"

//
int rt_paramster_init_get_data_forme_ffmpeg_local(RT_PLATFORM platform,RT_PARAMS *stRtParams){
    
    if(platform == RT_IOS){
        
    #if 1
        
        //使用UiIMage显示参数设置,类似于ios
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGB24;//AV_PIX_FMT_RGB24
        
    #elif 0
        
        //使用openGL显示参数设置，类似于ios
        stRtParams->s32BlockVideoDecodeData = 1;
        stRtParams->s32BlockScaleData = 0;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_YUV420P;
        
    #endif
        
    }else{
        
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
    }
    
    stRtParams->enRtOpenAudioState = RT_AUDIO_ENABLE;
    stRtParams->enRtSocketType = RT_SOCKET_NONE;
    stRtParams->avCodecID = AV_CODEC_ID_H264;
    stRtParams->enRtLiveType = RT_LIVE_TYPE_LOCAL;
    
    strcpy(stRtParams->acDid, RT_DEFAUT_UID);//这里的uid必须使用默认的uid
    
    
    LOGD("[%s   %d] \n",__FUNCTION__,__LINE__);
    
    return 0;
}

int rt_paramster_init_get_data_forme_ffmpeg_remote(RT_PLATFORM platform,RT_PARAMS *stRtParams){
    
    if(platform == RT_IOS){
        
#if 1
        
        //使用UiIMage显示参数设置,类似于ios
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGB24;//AV_PIX_FMT_RGB24
        
#elif 0
        
        //使用openGL显示参数设置，类似于ios
        stRtParams->s32BlockVideoDecodeData = 1;
        stRtParams->s32BlockScaleData = 0;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_YUV420P;
        
#endif
        
    }else{
        
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
    }
    
    stRtParams->enRtOpenAudioState = RT_AUDIO_ENABLE;
    stRtParams->enRtSocketType = RT_SOCKET_TCP;
    stRtParams->avCodecID = AV_CODEC_ID_H264;
    stRtParams->enRtLiveType = RT_LIVE_TYPE_REMOTE;
    
    strcpy(stRtParams->acDid, RT_DEFAUT_UID);//这里的uid必须使用默认的uid
    
    return 0;
}

//远程直播
int rt_paramster_init_get_data_forme_ffmpeg_remote_live(RT_PLATFORM platform,RT_PARAMS *stRtParams){
    rt_paramster_init_get_data_forme_ffmpeg_remote(platform,stRtParams);
    stRtParams->enRtLiveType = RT_LIVE_TYPE_LIVE;
    return 0;
}
    

int rt_paramster_init_get_data_forme_other(RT_PLATFORM platform,const char *did,
                                           RT_PARAMS *stRtParams){
    
    if(platform == RT_IOS){
        
#if 1
        
        //使用UiIMage显示参数设置,类似于ios
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGB24;//AV_PIX_FMT_RGB24
        
#elif 0
        
        //使用openGL显示参数设置，类似于ios
        stRtParams->s32BlockVideoDecodeData = 1;
        stRtParams->s32BlockScaleData = 0;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_YUV420P;
        
#endif
        
    }else{
        
        stRtParams->s32BlockVideoDecodeData = 0;
        stRtParams->s32BlockScaleData = 1;
        stRtParams->enAVPixelFormat = AV_PIX_FMT_RGBA;
        
    }
    
    stRtParams->enRtOpenAudioState = RT_AUDIO_ENABLE;
    stRtParams->enRtSocketType = RT_SOCKET_NONE;
    stRtParams->avCodecID = AV_CODEC_ID_H264;
    stRtParams->enRtLiveType = RT_LIVE_TYPE_LIVE;
    
    stRtParams->stRtAudioParams.s32Channel = 2;
    stRtParams->stRtAudioParams.s32Profile = FF_PROFILE_AAC_LOW;
    stRtParams->stRtAudioParams.s32Sample_rate = 16000;
    
    strcpy(stRtParams->acDid, did);//这里的uid必须使用默认的uid

    return 0;
}

#define AUDIO_INBUF_SIZE 28480
#define AUDIO_REFILL_THRESH 4096
FILE *f;

int fill_iobuffer(void *opaque, uint8_t *buf, int buf_size){
    if(!feof(f)){
        int true_size = fread(buf, 1, buf_size, f);
        LOGD("[%s   %d] true_size =%d \n",__FUNCTION__,__LINE__,true_size);
        return true_size;
    }
    return -1;
}

int testReadAAC2(){
    av_register_all();
    
    //打开文件
    
    char filename[512];
    memset(filename, 0, sizeof(filename));
    sprintf(filename, "/Users/yangqingyuan/Desktop/test.aac");
    f= fopen(filename, "rb");
    
    if(!f){
        LOGE(" could not open error\n");
        return -1;
    }
    
    
    AVFormatContext *ic = NULL;
    ic = avformat_alloc_context();
    
    unsigned char  *iobuffer = (unsigned char *) av_malloc(32768);
    AVIOContext *avio = avio_alloc_context(iobuffer, 32768, 0, NULL, fill_iobuffer, NULL, NULL);
    ic->pb = avio;
    
    if(avformat_open_input(&ic, "nothing", NULL, NULL)<0){
        LOGD("[%s   %d] avformat_open_input error \n",__FUNCTION__,__LINE__);
        return -1;
    }
    LOGD("[%s   %d] avformat_open_input success \n",__FUNCTION__,__LINE__);
    
    
    
    
    
    
    
    return 0;
}

int testReadAAC3(){
    
    
    av_register_all();
    
    AVCodec *codec;
    AVCodecContext *c = NULL;
    int len;
    FILE *f;
    uint8_t inbuf[AUDIO_INBUF_SIZE + AV_INPUT_BUFFER_PADDING_SIZE];
    AVPacket avpkt;
    AVFrame *decode_frame = NULL;
    
    av_init_packet(&avpkt);
    
    int isPrint = 0;
    
    char filename[512];
    memset(filename, 0, sizeof(filename));
    sprintf(filename, "/Users/yangqingyuan/Desktop/test.aac");
    
    
    codec = avcodec_find_decoder(AV_CODEC_ID_AAC);
    if(!codec){
        LOGE("codec not fond\n");
        return -1;
    }
    
    c = avcodec_alloc_context3(codec);
    if(!c){
        LOGE(" avcodec_alloc_context3 error\n");
        return -1;
    }

    
    if(avcodec_open2(c,codec, NULL)<0){
        LOGE(" could not open error\n");
        return -1;
    }

    f= fopen(filename, "rb");
    
    if(!f){
        LOGE(" could not open error\n");
        return -1;
    }
    
    avpkt.data = inbuf;
    avpkt.size = fread(inbuf, 1, AUDIO_INBUF_SIZE, f);
    
    while(avpkt.size>0){
        int i,ch;
        int got_frame = 0;
        
        if(!decode_frame){
            if(!(decode_frame = av_frame_alloc())){
                LOGE(" could not open error\n");
                return -1;
            }
        }

#if 1
        
        len = avcodec_decode_audio4(c, decode_frame, &got_frame, &avpkt);
        if(len<0){
            LOGE(" error while decoding\n");
            return -1;
        }
        
#else
        len = avcodec_send_packet(c,&avpkt);
        if(len != 0){
            LOGE("[%s   %d] avcodec_send_packet error \n",__FUNCTION__,__LINE__);
            return -1;
        }
        len = avcodec_receive_frame(c,decode_frame);
        if(len != 0){
            LOGE("[%s   %d] avcodec_receive_frame error \n",__FUNCTION__,__LINE__);
            return -1;
        }
#endif
        
        if(got_frame){
            LOGD("avcodec_decode_audio4 success len =%d \n",len);
            
            if(!isPrint){
                  LOGD("[%s   %d] sample_rate=%d channels=%d bit_rate=%lld profile=%d channel_layout=%lld level=%d\n",__FUNCTION__,__LINE__,c->sample_rate,c->channels,c->bit_rate,c->profile,c->channel_layout,c->level);
            }
        }
        
        avpkt.size -= len;
        avpkt.data += len;
        avpkt.pts = AV_NOPTS_VALUE;
        if(avpkt.size<AUDIO_REFILL_THRESH){
            LOGD("-------A--------\n");
            memmove(inbuf, avpkt.data, avpkt.size);
            avpkt.data = inbuf;
            len = fread(avpkt.data+avpkt.size, 1, AUDIO_INBUF_SIZE - avpkt.size, f);
            if(len >0){
                avpkt.size +=len;
            }
        }
    }

    fclose(f);
    avcodec_close(c);
    av_free(c);
    av_frame_free(&decode_frame);
    
    LOGD("[%s   %d] end \n",__FUNCTION__,__LINE__);
    
    return 0;
}
int testReadAAC(){
    
    
    AVCodecContext	*pAudioCodecCtx;
    AVCodec			*pAudioCodec;
    
    //ffmpeg注册所有
    av_register_all();
    avcodec_register_all();
    
    //解码来播放
    pAudioCodec = avcodec_find_decoder(AV_CODEC_ID_AAC);
    
    if(NULL ==pAudioCodec){
        LOGE("[%s    %d] cannot find audio \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    pAudioCodecCtx = avcodec_alloc_context3(pAudioCodec);
    
    if(NULL == pAudioCodecCtx){
        LOGE("[%s    %d] avcodec_alloc_context3  error \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    pAudioCodecCtx->codec_type = AVMEDIA_TYPE_AUDIO;
    pAudioCodecCtx->sample_rate = 44100;
    pAudioCodecCtx->profile = FF_PROFILE_AAC_LOW;
    pAudioCodecCtx->channels = 3;
    
    if(avcodec_open2(pAudioCodecCtx, pAudioCodec, NULL) < 0){
        LOGE("[%s    %d] avcodec_open2  error\n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    
    char filename[512];
    memset(filename, 0, sizeof(filename));
    
    //sprintf(filename, "/Users/yangqingyuan/Library/Developer/CoreSimulator/Devices/40F77184-EECE-4A85-B468-9347386A008C/data/Containers/Data/Application/A7857C36-2FE7-486E-BC94-465D88127170/Documents/Rec/test.aac");
    
    sprintf(filename, "/Users/yangqingyuan/Desktop/test.aac");
    
    
    FILE *fp;
    fp = fopen(filename, "rb");
    
    if(fp == NULL){
        LOGE("[%s   %d] fp == NULL \n",__FUNCTION__,__LINE__);
        return -1;
    }
    
    unsigned char buf[128];
    
    int len = 0;
    int s32Rec = 0;
    AVPacket pkt;
    while((len = fread(buf, 128, 1, fp))<128){
        
        SDL_Delay(120);
        
        av_init_packet(&pkt);
        pkt.data = buf;
        pkt.size = len;
        pkt.stream_index = AVMEDIA_TYPE_AUDIO;
        //ff f1 50 80 2c 7f fc
        AVFrame *pframe;
        pframe = av_frame_alloc();
        if(!pframe){
            LOGE("[%s   %d] av_frame_alloc faile \n",__FUNCTION__,__LINE__);
            continue;
        }
        
        
        s32Rec = avcodec_send_packet(pAudioCodecCtx,&pkt);
        if(s32Rec != 0){
            LOGE("[%s   %d] avcodec_send_packet error \n",__FUNCTION__,__LINE__);
            av_frame_free(&pframe);
            
            LOG_PRINT_HEX(pkt.data, 0, 60);
            
            continue;
        }
        s32Rec = avcodec_receive_frame(pAudioCodecCtx,pframe);
        if(s32Rec != 0){
            LOGE("[%s   %d] avcodec_receive_frame error \n",__FUNCTION__,__LINE__);
            av_frame_free(&pframe);
            continue;
        }
        
        LOGD("[%s   %d] decode success \n",__FUNCTION__,__LINE__);
        
        
    }
    
    return 0;
}


