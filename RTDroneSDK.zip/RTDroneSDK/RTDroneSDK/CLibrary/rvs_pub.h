#ifndef _RVS_PUB_H_
#define _RVS_PUB_H_

#include "rvs_protocol.h"
#include "rvs_inc.h"

#ifdef __cplusplus
 #if __cplusplus
extern "C" {
 #endif
#endif /* __cplusplus */

#define RVS_CHECK_MAGIC(a) ((a[0]|(a[1]<<8)|(a[2]<<16)|(a[3]<<24))==RVS_MAGIC)

typedef struct _RVST_SOCKET_CONFIG_
{
    RVST_SOCKET s32SocketFd;
    RVST_UINT32 u32ServerAddr;
    RVST_INT32 s32ServerPort;
    RVST_INT32 s32Timeout_sec; //��ʱʱ��(��)
    RVS_SOCKET_TYPE enSocketType;
    struct sockaddr_in stClientAddr;//udp ��Ҫʹ��
    RVS_PROTOCOL_HEADER stPacketHeader;
}RVST_SOCKET_CFG;

typedef enum RVS_ATION
{
    RVS_ACTION_NOTHIG=0,
    RVS_ATION_SNAP=1,
    RVS_ATION_REC=2,
    RVS_ATION_TRANSINFO=3,
    RVS_ATION_REBOOT=4,
    RVS_ATION_WIFI5G=5,
    RVS_ATION_POWERONOFF=6,

    RVS_ATION_BUTT
}RVS_ATION_E;

typedef enum RVS_RUN_FLAG
{
    RVS_RUN_STOP=0,
    RVS_RUN_RUNNING=1,

}RVS_RUN_FLAG_E;

typedef enum RVS_SUBSCRIBE_FLAG
{
    RVS_SUBSCRIBE_OFF=0,
    RVS_SUBSCRIBE_ON,

}RVS_SUBSCRIBE_FLAG_E;

typedef RVST_RET (*RVS_CmdProcess)(RVST_UINT16 u16Cmd, RVST_UINT8 u8SerialNum, 
    RVST_BYTE PayloadData[RVS_SOCKET_MAX_DATA_SIZE], RVST_INT32 s32PayloadLen, void *UserData);

typedef enum RVST_WORK_MODE
{
    RVST_WORK_SERVER_UART=0,
    RVST_WORK_SERVER_HWB=1,
    RVST_WORK_CLIENT_ACK,
    RVST_WORK_CLIENT_SUBSCRIBE,
}RVST_WORK_MODE_E;

typedef struct _RVS_CMD_CB_
{
    RVST_INT *RvsHandle;
    RVST_WORK_MODE_E enWorkMode;
    volatile RVS_RUN_FLAG_E *penRunningFlag;
    RVS_CmdProcess RVS_CmdCbFunc;
    void *UserData;
    RVST_UINT8 *pcRecvData;
    RVST_INT32 s32RecvDataLen;
    RVST_INT32 s32RecvDataRemain;
    RVS_PROTOCOL_HEADER stProtocolHeader;
    RVST_INT16 s16OneCmdHeaderLen;
    RVST_UINT8 u8SerialNum;
    RVST_UINT8 u8CheckSumOnOff;
}RVS_CMD_CB;

RVST_RET RVST_InitPacketHeadr(RVST_SOCKET_CFG *pstSocketCfg);

RVST_RET RVST_SetPacketHeadr(RVST_SOCKET_CFG *pstSocketCfg,RVST_UINT16 u16Cmd,
    RVST_UINT16 s16PayloadLen,RVST_UBYTE chSerialNum);

RVST_RET RVST_Packet(RVST_SOCKET_CFG *pstSocketCfg,        RVST_BYTE *pPayloadBuf,RVS_PROTOCOL_PACKET *pstPacket);

RVST_RET RVST_SendData(RVST_SOCKET_CFG *pstSocketCfg, RVS_PROTOCOL_PACKET *pstPacket);

RVST_RET RVST_RecvSocketData(RVST_SOCKET_CFG *pstSocketCfg, 
    RVST_CHAR *acRecvBuf, RVST_SSIZE *ps32RecvLen);

RVST_RET CheckCheckSum(RVST_UINT8 *pRecvBuf, RVST_INT16 s16RecvLen);
RVST_RET SetCheckSum(RVST_SOCKET_CFG *pstSocketCfg,RVST_BYTE *pPayloadBuf, RVST_INT16 s16PayloadLen) ;

RVST_RET RVST_Depacket(RVS_CMD_CB *pstCb);

#ifdef __cplusplus
 #if __cplusplus
}
 #endif
#endif /* __cplusplus */

#endif /*_RVS_PUB_H_*/

