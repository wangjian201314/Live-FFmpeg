//#include "rvs_inc.h"

#include "rvs_ipc_client.h"
#include "rvs_def.h"
RVST_RET RVST_IpcSendMsgToApp( RVST_UINT16 u16Cmd, RVST_BYTE *pPayloadBuf, RVST_UINT16 s16PayloadLen)
{
    static RVST_INT *hpRvsHandle = NULL;
    RVST_RET Ret = RVS_EFAILED;

    if(NULL == pPayloadBuf  || s16PayloadLen < 1)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    if(NULL == hpRvsHandle)
    {
        RVS_ERR_PRINT("RVST_Connect !\n"); //192.168.234.20
        Ret = RVST_Connect("192.168.0.145", RVST_IPC_MSG_PORT,RVST_CONNECT_TIMEOUT_s, &hpRvsHandle,RVS_SOCKET_UDP);
        if(RVS_SUCCESS != Ret)
        {
            RVS_ERR_PRINT("RVST_Connect err!\n");
            RVST_DisConnect(hpRvsHandle);
            hpRvsHandle = NULL;
            return Ret;
        }

    }
    
    Ret = RVST_SendCmdData(hpRvsHandle,  u16Cmd, pPayloadBuf, s16PayloadLen);
    if(RVS_SUCCESS != Ret)
    {
        RVS_ERR_PRINT("RVST_SendCmdData err!\n");
    }

    return Ret;
}


