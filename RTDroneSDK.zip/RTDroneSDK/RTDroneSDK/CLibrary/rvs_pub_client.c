#ifndef RTOS_UART_DEV
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h> 
#include <errno.h>
#endif

#include <sys/time.h>//
#include "rvs_protocol.h"
#include "rvs_pub.h"
#include "rvs_pub_client.h"

static RVST_SOCKET_CFG gs_stSocketCfg;

RVST_RET RVST_ClientOpenUdp(RVST_SOCKET_CFG *pstSocketCfg)
{
    struct sockaddr_in stServerAddr;
    RVST_SOCKET s32SocketFd;
    //RVST_RET Ret = RVS_EFAILED;


    if(NULL == pstSocketCfg)
    {
        RVS_ERR_PRINT("param err!!\n");
        return RVS_EPARA;
    }

    if ( (s32SocketFd=socket(AF_INET, SOCK_DGRAM, 0)) <0)
    {
        RVS_ERR_PRINT("socket err!\n");
        return RVS_EFAILED;
    }
    
    if(inet_addr(RVS_BIND_AND_LISTEN_PORT_ADDR) == pstSocketCfg->u32ServerAddr)
    {
        RVST_INT32 s32OptVal=1;
        // ����socketѡ����ǿ�ѡ�ģ����Ա������������������޷�������������
        setsockopt(s32SocketFd, SOL_SOCKET, SO_REUSEADDR, &s32OptVal, sizeof(RVST_INT32));
    }
    
    //RT_LLQ,�豸��app�Թ㲥����ʽ������Ϣ��ipΪ RVS_BROADCAST_ADDR Ϊ�жϱ�־
    if(inet_addr(RVS_BROADCAST_ADDR) == pstSocketCfg->u32ServerAddr)
    {
        int i=1;
    	socklen_t len = sizeof(i);
    	setsockopt(s32SocketFd,SOL_SOCKET,SO_BROADCAST,&i,len);
    }
    
    bzero(&stServerAddr,sizeof(stServerAddr));
    stServerAddr.sin_family = AF_INET;
    stServerAddr.sin_port = htons(pstSocketCfg->s32ServerPort);
    if(inet_addr(RVS_BROADCAST_ADDR) == pstSocketCfg->u32ServerAddr)
    {
        stServerAddr.sin_addr.s_addr = INADDR_BROADCAST;
    }
    else
    {
        stServerAddr.sin_addr.s_addr = pstSocketCfg->u32ServerAddr;
    }

    pstSocketCfg->s32SocketFd = s32SocketFd;
    memcpy(&(pstSocketCfg->stClientAddr),&stServerAddr,sizeof(struct sockaddr_in));

    #if 1//RVS_BIND_AND_LISTEN_PORT_ADDRΪ��־���󶨣������̶��˿�
    if(inet_addr(RVS_BIND_AND_LISTEN_PORT_ADDR) == pstSocketCfg->u32ServerAddr)
    {
        stServerAddr.sin_addr.s_addr = htonl (INADDR_ANY);
        RVST_RET Ret;
        Ret = bind(s32SocketFd, (struct sockaddr *)&stServerAddr, sizeof(struct sockaddr));
        if(RVS_EFAILED == Ret)
        {
            RVS_ERR_PRINT("Bind()error.");
            //goto EXIT_ERR;
        }
    }
    #endif

    return RVS_SUCCESS;
}

RVST_RET RVST_ClientOpenTcp(RVST_SOCKET_CFG *pstSocketCfg)
{
    struct sockaddr_in stServerSockAddr;
    RVST_SOCKET s32RetSocketFd = RVST_INVALID_SOCKET;
    struct timeval stTimeout;
    fd_set stFdSet;
	socklen_t OptLen = sizeof(RVST_RET);
    RVST_RET Ret = RVS_EFAILED;
    RVST_RET Error = -1;
    RVST_INT32 S32Flag;

    if(NULL == pstSocketCfg)
    {
        RVS_ERR_PRINT("param err!!\n");
        return RVS_EPARA;
    }

    bzero(&stServerSockAddr,sizeof(stServerSockAddr));
    stServerSockAddr.sin_family = AF_INET;
    stServerSockAddr.sin_addr.s_addr = pstSocketCfg->u32ServerAddr;
    stServerSockAddr.sin_port = htons(pstSocketCfg->s32ServerPort);
    
    if ((s32RetSocketFd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        RVS_ERR_PRINT("socket err!\n");
        return RVS_EFAILED;
    }
    
    S32Flag = fcntl(s32RetSocketFd, F_GETFL, 0);
    fcntl(s32RetSocketFd, F_SETFL, S32Flag | O_NONBLOCK); //����Ϊ������ģʽ

    if (connect(s32RetSocketFd, (struct sockaddr *)&stServerSockAddr, sizeof(struct sockaddr)) < 0)
    {
        //�ȴ���ʱ
        if(pstSocketCfg->s32Timeout_sec > 0)
        {
            stTimeout.tv_sec = pstSocketCfg->s32Timeout_sec;
            stTimeout.tv_usec = 0;
            FD_ZERO(&stFdSet);
            FD_SET(s32RetSocketFd, &stFdSet);

            Ret = select(s32RetSocketFd+1, NULL, &stFdSet, NULL, &stTimeout);
            RVS_ERR_PRINT("select Ret{%d}!\n",Ret);
            if( Ret > 0)
            {
                #if 1 //TODOû������ʱ������������������
                getsockopt(s32RetSocketFd, SOL_SOCKET, SO_ERROR, (void *)&Error, &OptLen);
                {
                    if(Error != 0)
                    {
                        RVS_ERR_PRINT("getsockopt err!\n");
                        goto ERR_EXIT;
                    }
                }
                RVS_ERR_PRINT("getsockopt {%d}!\n",Error);
                #endif
            }
            else 
            {
                RVS_ERR_PRINT("select err!\n");
                goto ERR_EXIT;
            }
        }
        else 
        {
            RVS_ERR_PRINT("connect err!\n");
            goto ERR_EXIT;
        }
    }
    
    S32Flag  = fcntl(s32RetSocketFd,F_GETFL,0);
    fcntl(s32RetSocketFd,F_SETFL,S32Flag&~O_NONBLOCK);    //���ó�����ģʽ��

    #if 0
    Ret = bind(s32RetSocketFd, ((struct sockaddr *)&stServerSockAddr), sizeof(struct sockaddr_in));
    if (-1 == Ret) 
    {
        RVS_ERR_PRINT("bind() error\n");
        //goto ERR_EXIT;
    }
    #endif

    pstSocketCfg->s32SocketFd = s32RetSocketFd;

    return RVS_SUCCESS;
    
ERR_EXIT:
    
    close( s32RetSocketFd );
    return RVS_EFAILED;
    
}

RVST_RET RVST_Connect(RVST_CHAR* pcServerAddr, RVST_INT s32Port,
    RVST_INT s32Timeout, RVST_INT **hppRvsHandle, RVS_SOCKET_TYPE SocketType)
{

    RVST_RET s32GetHostRet = RVS_EFAILED;
	RVST_UINT32 s32NetAddr = 0;

    if(
        #ifndef RTOS_UART_DEV //rtos��socket�Ǵ�0��ʼ��
        (0 < gs_stSocketCfg.s32SocketFd) || 
        #endif
        (NULL != *hppRvsHandle))
    {
        RVS_ERR_PRINT("There is already connected!![%d:%p]\n",
            gs_stSocketCfg.s32SocketFd,*hppRvsHandle);
        return RVS_EPARA;
    }
    
    #ifndef RTOS_UART_DEV
    /*���ȸ���host name��ipv4��ַ��ȡhosttent*/
    struct hostent *pstHostent = (struct hostent *)gethostbyname(pcServerAddr);
    if (NULL != pstHostent)
    {
        s32GetHostRet = RVS_SUCCESS;
    }
    /*����ȡ���ɹ����ٸ���ip addr��ȡhostent*/
    else
    {
        s32NetAddr = inet_addr(pcServerAddr);
        /*��ʮ���Ƶ�ip��ַ���Ϸ������»�ȡ��Ӧ�������ֽ�������*/
        if(INADDR_NONE == s32NetAddr)
        {
            s32GetHostRet = RVS_EFAILED;
        }
        else
        {
            pstHostent = (struct hostent *)gethostbyaddr((const RVST_CHAR *) &s32NetAddr,
                        sizeof(RVST_UINT32), PF_INET);
            if (pstHostent)
            {
                s32GetHostRet = RVS_SUCCESS;
            }
        }
    }
    #else
    s32GetHostRet = RVS_SUCCESS;
    #endif
    
    if (RVS_SUCCESS == s32GetHostRet)
    {      
        #ifndef RTOS_UART_DEV
        gs_stSocketCfg.u32ServerAddr = *((RVST_UINT32 *)pstHostent->h_addr);
        #else
        gs_stSocketCfg.u32ServerAddr = inet_addr(pcServerAddr);
        #endif
        gs_stSocketCfg.s32ServerPort = s32Port;
        gs_stSocketCfg.s32Timeout_sec = s32Timeout;
        gs_stSocketCfg.enSocketType = SocketType;
        if(RVS_SOCKET_TCP == gs_stSocketCfg.enSocketType)
        {
            s32GetHostRet = RVST_ClientOpenTcp(&gs_stSocketCfg);
        }
        else
        {
            s32GetHostRet = RVST_ClientOpenUdp(&gs_stSocketCfg);
        }
        if(RVS_SUCCESS == s32GetHostRet)
        {
            RVST_InitPacketHeadr(&gs_stSocketCfg);
            *hppRvsHandle = (RVST_INT *)&gs_stSocketCfg;
        }
    }
    
    return s32GetHostRet;

}


RVST_RET RVST_DisConnect(RVST_INT *pRvsHandle)
{
    RVST_SOCKET_CFG *pstSocketCfg = NULL;

    if(NULL == pRvsHandle)
    {
        RVS_ERR_PRINT("There is no connected!!\n");
        return RVS_EPARA;
    }
    pstSocketCfg = (RVST_SOCKET_CFG *)(pRvsHandle);

    if(pstSocketCfg->s32SocketFd >= 0)
    {
        //close( pstSocketCfg->s32SocketFd);
        shutdown(pstSocketCfg->s32SocketFd, SHUT_RDWR);
    }
    pstSocketCfg->s32SocketFd = -1;
    pstSocketCfg->s32Timeout_sec = 0;
    pstSocketCfg->s32ServerPort = 0;
    pstSocketCfg->u32ServerAddr = 0;
    pstSocketCfg->enSocketType = RVS_SOCKET_END;

    pRvsHandle = NULL;

    return RVS_SUCCESS;
}

RVST_RET RVST_SendCmdData(RVST_INT *RvstHandle, RVST_UINT16 u16Cmd, 
    RVST_BYTE *pPayloadBuf, RVST_UINT16 s16PayloadLen)
{
    RVST_SOCKET_CFG *pstSocketCfg = (RVST_SOCKET_CFG *)RvstHandle;
    RVS_PROTOCOL_PACKET stSendPack;
    RVST_RET Ret = RVS_EFAILED;
    
    if(NULL == RvstHandle || NULL == pPayloadBuf  || s16PayloadLen < 1)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    memset(&stSendPack,0,sizeof(RVS_PROTOCOL_PACKET));

    Ret = RVST_SetPacketHeadr(pstSocketCfg,u16Cmd,s16PayloadLen,
        (pstSocketCfg->stPacketHeader.RVSH_SN+1));
    if(RVS_SUCCESS != Ret)
    {
        RVS_ERR_PRINT("RVST_SetPacketHeadr err!\n");
    }

    Ret = SetCheckSum(pstSocketCfg,pPayloadBuf,s16PayloadLen);
    if(RVS_SUCCESS != Ret)
    {
        RVS_ERR_PRINT("SetCheckSum err!\n");
        return Ret;
    }


    Ret = RVST_Packet(pstSocketCfg,pPayloadBuf,&stSendPack);
    if(RVS_SUCCESS != Ret)
    {
        RVS_ERR_PRINT("RVST_Packet err!\n");
        return Ret;
    }

    Ret = RVST_SendData(pstSocketCfg, &stSendPack);
    if(RVS_SUCCESS != Ret)
    {
        RVS_ERR_PRINT("RVST_SendData err!\n");
        return Ret;
    }

    return Ret;
}


