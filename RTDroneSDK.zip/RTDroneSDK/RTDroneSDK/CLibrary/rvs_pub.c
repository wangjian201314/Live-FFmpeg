#if RTOS_UART_DEV
#include <FreeRTOS.h>
#include <task.h>
#include <bsp.h>
#include <string.h>
#include <nonstdlib.h>
#include <queue.h>
#include <semphr.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/types.h>
#include <bits/alltypes.h>
#include <lwip/sockets.h>
#else
#include <fcntl.h> 
#include <errno.h>
#endif

#include <sys/time.h>//
#include "rvs_def.h"
#include "rvs_protocol.h"
#include "rvs_pub.h"

RVST_RET SetCheckSum(RVST_SOCKET_CFG *pstSocketCfg,RVST_BYTE *pPayloadBuf, RVST_INT16 s16PayloadLen) 
{ 
    register RVST_UINT32 CheckSum = 0;
    RVST_INT16 s16Count = 0;
    RVST_UINT8 *pHeader = NULL;

    if(NULL == pstSocketCfg || NULL == pPayloadBuf)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    //�ۼ�PayloadBuf��ֵ
    while( s16PayloadLen > s16Count )
    {
        CheckSum += *(pPayloadBuf+s16Count);
        s16Count ++;
    }

    //�ۼ�Э��ͷ��ֵ
    pHeader = (RVST_UINT8 *)&(pstSocketCfg->stPacketHeader);
    s16Count = sizeof(RVS_PROTOCOL_HEADER);
    while( 0 < s16Count )
    {
        CheckSum += *(pHeader++);
        s16Count --;
    }

    //RVS_INFO_PRINT("CheckSum[%x]\n",CheckSum);
    while (CheckSum>>8) 
    {
        CheckSum = (CheckSum & 0xff) + (CheckSum >> 8); 
    }
    pstSocketCfg->stPacketHeader.RVSH_CHECKSUM  = ~CheckSum; 
    //RVS_INFO_PRINT("CheckSum[%x]\n",~CheckSum);


    return RVS_SUCCESS;
}

RVST_RET CheckCheckSum(RVST_UINT8 *pRecvBuf, RVST_INT16 s16RecvLen) 
{
    RVST_INT16 s16Count = 0;
    register RVST_UINT32 CheckSum = 0;

    if(NULL == pRecvBuf)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    //�ۼ�PayloadBuf��ֵ
    while( s16RecvLen > s16Count )
    {
        CheckSum += *(pRecvBuf+s16Count);
        s16Count ++;
    }

    //RVS_INFO_PRINT("CheckSum[%x]\n",CheckSum);
    //��������ּӵ���λ
    while (CheckSum>>8) 
    {
        CheckSum = (CheckSum & 0xff) + (CheckSum >> 8); 
    }
    //RVS_INFO_PRINT("CheckSum[%x]\n",(~(CheckSum | 0xffffff00)));

    if(0 == (~(CheckSum | 0xffffff00)))
    {
        return RVS_SUCCESS;
    }
    else
    {
        return RVS_EFAILED;
    }

}

RVST_RET RVST_DestoryPacket( RVS_PROTOCOL_PACKET *pstPacket)
{
    if(NULL != pstPacket->RVSD_Buf)
    {
        free(pstPacket->RVSD_Buf);
        pstPacket->RVSD_Buf = NULL;
        pstPacket->RVSD_Total_Len = 0;
    }
    return RVS_SUCCESS;
}

RVST_RET RVST_InitPacketHeadr(RVST_SOCKET_CFG *pstSocketCfg)
{
    if(NULL == pstSocketCfg)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }
    //���ħ������
    pstSocketCfg->stPacketHeader.RVSH_Magic = RVS_MAGIC;
    //�ܳ���
    pstSocketCfg->stPacketHeader.RVSH_Length = 0;
    //�汾��
    pstSocketCfg->stPacketHeader.RVSH_Ver = 0x01;
    //���к�
    pstSocketCfg->stPacketHeader.RVSH_SN = 0;
    //������
    pstSocketCfg->stPacketHeader.RVSH_CMD = 0;
    //����������չ
    pstSocketCfg->stPacketHeader.RVSH_CHECKSUM = 0;
    pstSocketCfg->stPacketHeader.RVSH_RESV2 = 0;

    return RVS_SUCCESS;
}

RVST_RET RVST_SetPacketHeadr(RVST_SOCKET_CFG *pstSocketCfg,RVST_UINT16 u16Cmd,
    RVST_UINT16 s16PayloadLen,RVST_UBYTE chSerialNum)
{
    if(NULL == pstSocketCfg)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    pstSocketCfg->stPacketHeader.RVSH_Length = s16PayloadLen+sizeof(RVS_PROTOCOL_HEADER);
    pstSocketCfg->stPacketHeader.RVSH_SN = chSerialNum;
    pstSocketCfg->stPacketHeader.RVSH_CMD = u16Cmd;
    pstSocketCfg->stPacketHeader.RVSH_CHECKSUM= 0;
    return RVS_SUCCESS;
}

//_payload_len, �ܳ���
RVST_RET RVST_Packet(RVST_SOCKET_CFG *pstSocketCfg,        RVST_BYTE *pPayloadBuf,RVS_PROTOCOL_PACKET *pstPacket)
{
       
    if((NULL == pPayloadBuf) || (NULL == pstPacket) || (NULL == pstSocketCfg))
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    RVST_DestoryPacket(pstPacket);
    
    pstPacket->RVSD_Total_Len = pstSocketCfg->stPacketHeader.RVSH_Length;
    pstPacket->RVSD_Buf = malloc(pstPacket->RVSD_Total_Len);
    if(NULL == pstPacket->RVSD_Buf)
    {
        RVS_ERR_PRINT("malloc err!\n");
        return RVS_EFAILED;
    }

    memcpy(pstPacket->RVSD_Buf,&(pstSocketCfg->stPacketHeader),sizeof(RVS_PROTOCOL_HEADER));
    memcpy((pstPacket->RVSD_Buf+sizeof(RVS_PROTOCOL_HEADER)),pPayloadBuf,
        (pstPacket->RVSD_Total_Len - sizeof(RVS_PROTOCOL_HEADER)));

    return RVS_SUCCESS;
}

RVST_RET RVST_PacketProtocolHeader(RVS_PROTOCOL_HEADER *stProtocolHeader,RVST_CHAR *RcvData)
{
    RVST_CHAR *pcStart = NULL;
    if(NULL == stProtocolHeader || NULL == RcvData)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }
/*
    RVST_INT32    RVSH_Magic;
    
    RVST_UINT16   RVSH_Length;
    RVST_UBYTE    RVSH_Ver;
    RVST_UBYTE    RVSH_SN;
    
    RVST_UINT16   RVSH_CMD;
    RVST_UINT8    RVSH_CHECKSUM;//8ΪУ���
    RVST_UINT8    RVSH_RESV2;
*/
    pcStart = RcvData;
    memcpy(&(stProtocolHeader->RVSH_Magic),pcStart,sizeof(RVST_INT32));
    pcStart += sizeof(RVST_INT32);
    memcpy(&(stProtocolHeader->RVSH_Length),pcStart,sizeof(RVST_UINT16));
    pcStart += sizeof(RVST_UINT16);
    memcpy(&(stProtocolHeader->RVSH_Ver),pcStart,sizeof(RVST_UBYTE));
    pcStart += sizeof(RVST_UBYTE);
    memcpy(&(stProtocolHeader->RVSH_SN),pcStart,sizeof(RVST_UBYTE));
    pcStart += sizeof(RVST_UBYTE);
    memcpy(&(stProtocolHeader->RVSH_CMD),pcStart,sizeof(RVST_UINT16));
    pcStart += sizeof(RVST_UINT16);
    memcpy(&(stProtocolHeader->RVSH_CHECKSUM),pcStart,sizeof(RVST_UINT8));
    pcStart += sizeof(RVST_UINT8);
    memcpy(&(stProtocolHeader->RVSH_RESV2),RcvData,sizeof(RVST_UINT8));
    return RVS_SUCCESS;
    
}

RVST_RET RVST_Depacket(RVS_CMD_CB *pstCb)
{
    RVST_UINT8 *pcOneCmdData = NULL;
    RVST_UINT8 *pcInDataNext = NULL;
    RVST_UINT8 *pcSerialData = NULL;
    RVST_INT16 s16OneCmdDataLen = 0;
    RVST_INT16 s16OneCmdPayloadLen = 0;
    RVST_INT32 s32InDataLenRemain = 0;
    RVST_RET Ret = RVS_EFAILED;
    RVST_UINT8 u8SerialNumLast = 0;
    
    if(NULL == pstCb)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }
    
    pcInDataNext = pcOneCmdData = pstCb->pcRecvData;
    s32InDataLenRemain = pstCb->s32RecvDataLen;
    
    for(;s32InDataLenRemain > 0;)
    {
        pcOneCmdData = pcInDataNext;

        //���ħ������
        if(!RVS_CHECK_MAGIC(pcOneCmdData))
        {
            RVS_INFO_PRINT("MAGIC err!\n");
          #ifdef DEBUG
            RVS_DATA_PRINT(pcOneCmdData,4);
          #endif
            pcInDataNext ++;
            s32InDataLenRemain --;
            
            if(s32InDataLenRemain >= pstCb->s16OneCmdHeaderLen )
            {
                RVS_INFO_PRINT("RVS_CHECK_MAGIC err!s32InDataLenRemain:%d\n",s32InDataLenRemain);
                continue;
            }
            else
            {
                RVS_ERR_PRINT("RVS_CHECK_MAGIC err!s32InDataLenRemain:%d\n",s32InDataLenRemain);
                goto ERR_EXIT;
            }
            
        }

        //����ͷ��Ϣ
        //TODO 32λ��64λ����
        //memcpy(&stProtocolHeader,pcOneCmdData,s16OneCmdHeaderLen);
        RVST_PacketProtocolHeader(&(pstCb->stProtocolHeader),pcOneCmdData);
        
        s16OneCmdDataLen =  pstCb->stProtocolHeader.RVSH_Length;//RVS_GET_RCV_DATA_LEN(pcOneCmdData);
        //RVS_INFO_PRINT("s16OneCmdDataLen:%d\n",s16OneCmdDataLen);
        //���У���
        if(pstCb->u8CheckSumOnOff
            && (RVS_SUCCESS != CheckCheckSum((RVST_UINT8 *)pcOneCmdData, s16OneCmdDataLen)))
        {
            RVS_ERR_PRINT("CheckCheckSum err!\n");
            //pcInDataNext ++;
            s32InDataLenRemain --;
            //continue;
            Ret = RVS_ECHECKSUM;
            RVS_INFO_PRINT("s32InDataLenRemain:%d\n",s32InDataLenRemain);
            goto ERR_EXIT;
        }

        //����һ�ν��տ�����2�����ϵİ�

        //���ճ��Ȳ���
        if(s16OneCmdDataLen > s32InDataLenRemain)
        {
            RVS_ERR_PRINT("rev loss some data!\n");
            //s32InDataLenRemain --;
            Ret = RVS_EINVALIDDATA;
            RVS_INFO_PRINT("s32InDataLenRemain:%d\n",s32InDataLenRemain);
            goto ERR_EXIT;
        }
        //������1�����ϵĳ���
        else if(s16OneCmdDataLen <= s32InDataLenRemain)
        {
            //�ƶ��α굽��һ����
            s32InDataLenRemain -= s16OneCmdDataLen;
            pcInDataNext += s16OneCmdDataLen;
        }
        //��ͷ����
        else if(s16OneCmdDataLen < 0)
        {
            RVS_ERR_PRINT("s16OneCmdDataLen wrong!\n");
            s32InDataLenRemain --;
            Ret = RVS_EINVALIDDATA;
            RVS_INFO_PRINT("s32InDataLenRemain:%d\n",s32InDataLenRemain);
            goto ERR_EXIT;
        }

        //���кż��
        u8SerialNumLast =  pstCb->stProtocolHeader.RVSH_SN;//RVS_GET_RCV_DATA_SN(pcOneCmdData);
        if(( pstCb->u8SerialNum + 1) != u8SerialNumLast)
        {
            RVS_ERR_PRINT("some packet is droped!SerialNum[%d]\n", pstCb->u8SerialNum);
        }
         pstCb->u8SerialNum = u8SerialNumLast;

        //�ص�������������
        s16OneCmdPayloadLen = s16OneCmdDataLen -  pstCb->s16OneCmdHeaderLen;
        pcSerialData = pcOneCmdData +  pstCb->s16OneCmdHeaderLen;
        if(NULL != pstCb->RVS_CmdCbFunc)
        {
            Ret = pstCb->RVS_CmdCbFunc( pstCb->stProtocolHeader.RVSH_CMD, u8SerialNumLast,
                pcSerialData,s16OneCmdPayloadLen, (void *)(pstCb->RvsHandle));
            if(RVS_SUCCESS != Ret)
            {
                RVS_ERR_PRINT("pstCb->RVS_CmdCbFunc err!\n");
                goto ERR_EXIT;
            }
        }
        #if 0
        if(s32InDataLenRemain <  pstCb->s16OneCmdHeaderLen)
        {
            RVS_ERR_PRINT("data enough!s32InDataLenRemain[%d]\n",s32InDataLenRemain);
            goto ERR_EXIT;
        }
        #endif  
    }

   return RVS_SUCCESS;

ERR_EXIT:
    //��ʣ������ݷ���
    pstCb->s32RecvDataRemain = s32InDataLenRemain;
    return Ret;
   
}



//len, pBuf���ܳ���
RVST_RET RVST_SendData(RVST_SOCKET_CFG *pstSocketCfg, RVS_PROTOCOL_PACKET *pstPacket)
{
    RVST_INT32 s32Ret = 0;
    RVST_UINT32 u32RemSize =0;
    RVST_SSIZE s32Size    = 0;
    RVST_CHAR *ps8BufferPos = NULL;
    fd_set WriteFdSet;
    struct timeval stTimeoutVal;  /* Timeout value */
    //RVST_INT32 s32Errno = 0;
    
    if(NULL == pstSocketCfg || NULL == pstPacket  || 0 > pstSocketCfg->s32SocketFd)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    memset(&stTimeoutVal,0,sizeof(struct timeval));

    u32RemSize = pstPacket->RVSD_Total_Len;
    ps8BufferPos = pstPacket->RVSD_Buf;
    while(u32RemSize > 0)
    {
        FD_ZERO(&WriteFdSet);
        FD_SET(pstSocketCfg->s32SocketFd, &WriteFdSet);
        stTimeoutVal.tv_sec = 0;
        stTimeoutVal.tv_usec = 500;
        /*judge if it can send */
        s32Ret = select(pstSocketCfg->s32SocketFd + 1, NULL, &WriteFdSet, NULL, &stTimeoutVal);
        if (s32Ret > 0 )
        {
            if( FD_ISSET(pstSocketCfg->s32SocketFd, &WriteFdSet))
            {
                //s32Size = sendto(s32SendSock, ps8BufferPos, u32RemSize, 0);
                s32Size = sendto(pstSocketCfg->s32SocketFd, ps8BufferPos,u32RemSize, 0,
                    (struct sockaddr *)&(pstSocketCfg->stClientAddr) ,sizeof(struct sockaddr));
                if (s32Size < 0)
                {
                    RVS_ERR_PRINT("send err!\n");
                    goto ERR_EXIT;
                }

                u32RemSize -= s32Size;
                ps8BufferPos += s32Size;
            }
            else
            {
                RVS_ERR_PRINT("FD_ISSET err!\n");
                goto ERR_EXIT;
            }
        }
        /*select found over time or error happend*/
        else if( s32Ret == 0 )
        {
            RVS_ERR_PRINT("select err!\n");
            goto ERR_EXIT;
        }
        else if( s32Ret < 0 )
        {
            RVS_ERR_PRINT("select err!\n");
            goto ERR_EXIT;
        }
    }
    return RVS_SUCCESS;

ERR_EXIT:
    RVST_DestoryPacket(pstPacket);
    return RVS_EFAILED;
}

RVST_RET RVST_RecvSocketData(RVST_SOCKET_CFG *pstSocketCfg, 
    RVST_CHAR *acRecvBuf, RVST_SSIZE *ps32RecvLen)
{
#if 1
    struct sockaddr_in stClientAddr;
    socklen_t AddrLen = sizeof(struct sockaddr_in);
    RVST_SOCKET s32SockFd = pstSocketCfg->s32SocketFd;

    if(NULL == pstSocketCfg || NULL == acRecvBuf || NULL == ps32RecvLen)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }

    //�ͻ���
    *ps32RecvLen = recvfrom(s32SockFd,acRecvBuf,RVS_SOCKET_MAX_DATA_SIZE,
                0,(struct sockaddr*)&stClientAddr,&AddrLen);
    if (*ps32RecvLen <= 0)
    {
        RVS_ERR_PRINT("recvfrom() error\n");
        goto ERR_EXIT;
    }
#else
    struct sockaddr_in stClientAddr;
    fd_set stRecvFdSet;
    struct timeval stTimeVal;
    socklen_t AddrLen = sizeof(struct sockaddr_in);
    RVST_SOCKET s32SockFd = pstSocketCfg->s32SocketFd;
    RVST_INT32 s32TimeOutCount = 0;
    RVST_RET s32Ret;
    #define RVST_RECV_SOCKET_DATA_TIMEOUT_s (2)
    #define RVST_RECV_SOCKET_DATA_TIMEOUT_ms (0)

    if(NULL == pstSocketCfg || NULL == acRecvBuf || NULL == ps32RecvLen)
    {
        RVS_ERR_PRINT("param err!\n");
        return RVS_EPARA;
    }
        
    for(;;)
    {
        FD_ZERO(&stRecvFdSet);
        FD_SET(s32SockFd, &stRecvFdSet);
        stTimeVal.tv_sec = pstSocketCfg->s32Timeout_sec;
        stTimeVal.tv_usec = RVST_RECV_SOCKET_DATA_TIMEOUT_ms*1000;

        s32Ret = select(s32SockFd + 1, &stRecvFdSet, NULL, NULL, &stTimeVal);
        if (s32Ret > 0 )
        {
            if( FD_ISSET(s32SockFd, &stRecvFdSet))
            {
                *ps32RecvLen = recvfrom(s32SockFd,acRecvBuf,RVS_SOCKET_MAX_DATA_SIZE,
                            0,(struct sockaddr*)&stClientAddr,&AddrLen);
                if (*ps32RecvLen < 0)
                {
                    RVS_ERR_PRINT("recvfrom() error\n");
                    goto ERR_EXIT;
                }
                else if(0 == *ps32RecvLen)
                {
                    continue;
                }

                break;
            }
            else
            {
                RVS_ERR_PRINT("recv data from s32SockFd %d error: fd not in fd set\r\n",s32SockFd);
                goto ERR_EXIT;
            }
        }
        /*select found over time or error happend*/
        else if( s32Ret == 0 )
        {
            RVS_ERR_PRINT("Recv error: select overtime %d.%ds\n",
                    pstSocketCfg->s32Timeout_sec,RVST_RECV_SOCKET_DATA_TIMEOUT_ms);
            
            s32TimeOutCount ++;
            if(s32TimeOutCount > 2)
            {
                RVS_INFO_PRINT("s32TimeOutCount(%d)\n",s32TimeOutCount);
                goto ERR_EXIT;
            }
            
            continue;
        }
        else if( s32Ret < 0 )
        {
            RVS_ERR_PRINT("Recv s32SockFd[%d]error[%x]!\n",s32SockFd,errno);
            goto ERR_EXIT;
        }
   }     
#endif

    //������udpʱֻ������һ�ͻ��˵�����
    if(RVS_SOCKET_UDP == pstSocketCfg->enSocketType)
    {
        if(0 == pstSocketCfg->stClientAddr.sin_addr.s_addr )
        {
             RVS_ERR_PRINT("ip:%s:%d\n",inet_ntoa(stClientAddr.sin_addr),
                stClientAddr.sin_addr.s_addr);
            memcpy(&(pstSocketCfg->stClientAddr),&stClientAddr,AddrLen);
        }
        else if(strcmp(inet_ntoa(pstSocketCfg->stClientAddr.sin_addr),inet_ntoa(stClientAddr.sin_addr)))
        {
            *ps32RecvLen = 0;
            RVS_ERR_PRINT("drop [%s:%s:%d:%d]'s data!\n",
                inet_ntoa(stClientAddr.sin_addr),inet_ntoa(pstSocketCfg->stClientAddr.sin_addr),
                stClientAddr.sin_addr.s_addr,pstSocketCfg->stClientAddr.sin_addr.s_addr);
        } 
    }

    return RVS_SUCCESS;

ERR_EXIT:
    
    return RVS_EFAILED;
}


