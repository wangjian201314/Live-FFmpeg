
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Rt_drone_cmd_sonix.h"
#include "Rt_app_log.h"
#include "cJSON.h"


//����
int DeviceCommand_Sonix_NvramResetToDefault(char *aszJSON){
	
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "nvramresettodefault");
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	//���ͳɹ���񶼽���Ϣ�ص���jni
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;

}



//����osd��״̬
int DeviceCommand_Sonix_SetOSDOnOff(char *aszJSON, int osd)
{
	
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setosdonoff");
	cJSON_AddNumberToObject(pRoot, "osd", osd);
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	//���ͳɹ���񶼽���Ϣ�ص���jni
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_GetOSDStatus(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getosdstatus");
	
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0	
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_GetRecordCapability(char *aszJSON){

	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getrecordcapability");
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
    return 0;
}


/* void DeviceCommand_Sonix_StreamVideo
( jstring, int, int, char *);*/


int DeviceCommand_Sonix_SetGSensor(char *aszJSON, int sensitivity){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setgsensorparameter");
	cJSON_AddNumberToObject(pRoot, "sensitivity", sensitivity);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_SetPowerFrequency(char *aszJSON, int frequency){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setpowerfrequency");
	cJSON_AddNumberToObject(pRoot, "frequency", frequency);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


/* void DeviceCommand_Sonix_SetVideoParameters
( int, int, int, int, int, int, int, int, int, int, int, int, int);
*/

int DeviceCommand_Sonix_SetVideoParameters(char *aszJSON,long bitrate, int fps, int resolution){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setvideoparameters");
	cJSON_AddNumberToObject(pRoot, "bitrate", bitrate);
	cJSON_AddNumberToObject(pRoot, "fps", fps);
	cJSON_AddNumberToObject(pRoot, "resolution", resolution);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}


	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


/* void DeviceCommand_Sonix_SetRecordParameters
( int, int, int, int, int, int, int, int, int, int);
*/

int DeviceCommand_Sonix_SetRecordParameters(char *aszJSON, long bitrate, int fps, int resolution){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setrecordparameters");
	cJSON_AddNumberToObject(pRoot, "bitrate", bitrate);
	cJSON_AddNumberToObject(pRoot, "fps", fps);
	cJSON_AddNumberToObject(pRoot, "resolution", resolution);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_SetWiFiParameters(char *aszJSON, int channel,const char *pssid,const char *ppwd){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setwifiparameters");
	cJSON_AddNumberToObject(pRoot, "channel", channel);
	cJSON_AddStringToObject(pRoot, "ssid", pssid);
	cJSON_AddStringToObject(pRoot, "pwd", ppwd);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_SetRecordLength(char *aszJSON, int minutes){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setrecordlength");
	cJSON_AddNumberToObject(pRoot, "minutes", minutes);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_SetRecordAudioStatus(char *aszJSON, int level){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setrecordaudiostatus");
	cJSON_AddNumberToObject(pRoot, "level", level);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif

	return 0;
}


int DeviceCommand_Sonix_SetLoopRecordStatus(char *aszJSON, int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setlooprecordstatus");
	cJSON_AddNumberToObject(pRoot, "status", status);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}



int DeviceCommand_Sonix_SendFWBin(char *aszJSON, int fileSize){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "sendfwbin");
	cJSON_AddNumberToObject(pRoot, "fileSize", fileSize);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}


	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}

int DeviceCommand_Sonix_upgradeFW(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "upgradefw");
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_setWifi( char *aszJSON,int channel,const char *ssid,const char *pwd){
	
    return 0;
}

int DeviceCommand_Sonix_SetChannel(char *aszJSON, int channel){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setchannel");
	cJSON_AddNumberToObject(pRoot, "channel", channel);
	
	memset(aszJSON, 0, sizeof(cJSON));
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif

	
	return 0;
}


int DeviceCommand_Sonix_SetPWD(char *aszJSON,const char * ppwd){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setpwd");
	cJSON_AddStringToObject(pRoot, "pwd", ppwd);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_SetWDR(char *aszJSON,int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setwdr");
	cJSON_AddNumberToObject(pRoot, "status", status);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_SetMIRROR(char *aszJSON, int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setmirror");
	cJSON_AddNumberToObject(pRoot, "status", status);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif

	return 0;
}


int DeviceCommand_Sonix_SetFLIP(char *aszJSON, int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

    
	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setflip");
	cJSON_AddNumberToObject(pRoot, "status", status);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	LOGD("sonixDeviceCommandIpInfo.isDebug=%d",sonixDeviceCommandIpInfo.isDebug);
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif

	return 0;	
}


int DeviceCommand_Sonix_GetSDSpace(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getsdspace");
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_SetSDFormat(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setsdformat");
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_SetRecordStatus(char *aszJSON, int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "setrecordstatus");
	cJSON_AddNumberToObject(pRoot, "status", status);
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_TakePicture(char *aszJSON, int num){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "takepicture");

	if(num!=-1){
		cJSON_AddNumberToObject(pRoot, "pic_num", num);
	}


	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


/* void DeviceCommand_Sonix_TakePicture
();*/


int DeviceCommand_Sonix_SyncTime(char *aszJSON, int year, int month, int day, int hour, int min, int sec,const char *timezone){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "synctime");
	cJSON_AddNumberToObject(pRoot, "year", year);
	cJSON_AddNumberToObject(pRoot, "month", month);
	cJSON_AddNumberToObject(pRoot, "day", day);
	cJSON_AddNumberToObject(pRoot, "hour", hour);
	cJSON_AddNumberToObject(pRoot, "min", min);
	cJSON_AddNumberToObject(pRoot, "sec", sec);
	cJSON_AddStringToObject(pRoot, "timezone", timezone);
	
	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_GetTime(char *aszJSON, int status){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "gettime");
	cJSON_AddNumberToObject(pRoot, "status", status);

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}

int DeviceCommand_Sonix_GetBatteryStatus(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getbatterystatus");

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_GetVideoList(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getvideolist");

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}

int DeviceCommand_Sonix_DownloadFile(char *aszJSON,const char *pfilename, int pos, int filetype, int tag){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "downloadfile");
	cJSON_AddStringToObject(pRoot, "filename", pfilename);
	cJSON_AddNumberToObject(pRoot, "pos", pos);
	cJSON_AddNumberToObject(pRoot, "filetype", filetype);

	if(tag!=-1){
		cJSON_AddNumberToObject(pRoot, "tag", tag);
	}
	
	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
    

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


/* void DeviceCommand_Sonix_DownloadFile
( char *, int, int);*/


int DeviceCommand_Sonix_DownloadFileFinish(char *aszJSON,const char *pfilename,int filetype, int tag){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "downloadfilefinish");
	cJSON_AddStringToObject(pRoot, "filename", pfilename);
	cJSON_AddNumberToObject(pRoot, "filetype", filetype);

	if(tag!=-1){
		cJSON_AddNumberToObject(pRoot, "tag", tag);
	}
	
	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


/* void DeviceCommand_Sonix_DownloadFileFinish
( char *, int);*/


int DeviceCommand_Sonix_GetIndexFile(char *aszJSON, int type){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getindexfile");
	cJSON_AddNumberToObject(pRoot, "list", type);

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}

int DeviceCommand_Sonix_DeleteFile(char *aszJSON,const char *pfilename, int filetype){
	
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "deletefile");
	cJSON_AddStringToObject(pRoot, "filename", pfilename);
	cJSON_AddNumberToObject(pRoot, "filetype", filetype);

	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}


int DeviceCommand_Sonix_StreamVideo(char *aszJSON,const char *pfilename, int mode, int filetype,const char *mask){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "streamvideo");
	cJSON_AddStringToObject(pRoot, "filename", pfilename);
	cJSON_AddNumberToObject(pRoot, "live", mode);
	cJSON_AddNumberToObject(pRoot, "filetype", filetype);

	if(mask){
		cJSON_AddStringToObject(pRoot, "mask", mask);
	}

	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}



int DeviceCommand_Sonix_StreamVideoFinish(char *aszJSON,const char *pfilename,const char *pmask){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "streamvideofinish");
	cJSON_AddStringToObject(pRoot, "filename",pfilename);

	if(pmask){
		cJSON_AddStringToObject(pRoot, "mask", pmask);
	}
	
	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif

	return 0;
}


/* void DeviceCommand_Sonix_StreamVideoFinish
( char *);*/

/*void DeviceCommand_Sonix_SendFontFile(char *show){
}*/


int DeviceCommand_Sonix_SendFontFile(char *aszJSON,int *show,int length, int size){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "sendfontfile");
	cJSON_AddNumberToObject(pRoot, "fileSize",size);

	cJSON* jsonArray=cJSON_CreateArray();

	int i=0;
	for(i=0;i<length;i++){
		cJSON* pRoot = cJSON_CreateObject();
		cJSON_AddNumberToObject(pRoot, "unicode",show[i]);
		cJSON_AddItemToArray(jsonArray, pRoot);
	}

	cJSON_AddItemToObject(pRoot,"showString", jsonArray);
	
	//char aszJSON[1024];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;	
}


int DeviceCommand_Sonix_GetDeviceParameter(char *aszJSON){

	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	
	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getdeviceparameter");
	
	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}


int DeviceCommand_Sonix_GetRTSPURL(char *aszJSON,const char *pfilename){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getrtspurl");
	cJSON_AddStringToObject(pRoot, "filename", pfilename);
	
	//char aszJSON[256];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	
	return 0;
}



int DeviceCommand_Sonix_GetVideoStatus(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getvideostatus");

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
    
	return 0;
}


int DeviceCommand_Sonix_GetRecordStatus(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s	%d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}

	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "getrecordstatus");

	//char aszJSON[128];
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);
	
	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}

	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	if(result<0){
		rt_send_json_disconnect(&sonixDeviceCommandIpInfo.socket);
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_FAILE);
	}else{
		RT_NotifyCallBack(1, JNI_NOTIFY_SOCKET_SEND_DATA_SUCC);
	}
	#endif
	return 0;
}



int DeviceCommand_Sonix_getHeartBeatByte(char *aszJSON){
	if(NULL == aszJSON){
		LOGE("[%s   %d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "heartbeat");
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	#endif
	return 0;
}



int DeviceCommand_Sonix_StreamCheck(char *aszJSON,long long val1,long long val2,char *customerID){
	if(NULL == aszJSON){
		LOGE("[%s   %d] aszJSON is NULL \n",__FUNCTION__,__LINE__);
		return -1;
	}
	cJSON* pRoot = cJSON_CreateObject();
	cJSON_AddStringToObject(pRoot, "type", "streamcheck");

	//У����ļ���
	long long rec = 0;
	
	while (val1>>8) 
	{
		val1= (val1 & 0xff) + (val1 >> 8);
		rec += val1;
	}
	
	while (val2>>8) 
	{
	   	val2 = (val2 & 0xff) + (val2 >> 8);
		rec += val2;
	}
	
	char temp[64];
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%lld",rec);
	cJSON_AddStringToObject(pRoot, "val", temp);
	
	cJSON_AddStringToObject(pRoot, "customer_id", customerID);
	
	
	
	strcpy(aszJSON, cJSON_Print(pRoot));
	cJSON_Delete(pRoot);

	#if 0
	if(sonixDeviceCommandIpInfo.isDebug){
		LOGD("aszJSON=%s",aszJSON);
	}
	
	int result=rt_send_json_send(sonixDeviceCommandIpInfo.socket, aszJSON);
	#endif
	return 0;
}

