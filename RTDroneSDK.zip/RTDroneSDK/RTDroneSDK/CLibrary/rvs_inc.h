#ifndef __RVS_INC_H__
#define __RVS_INC_H__

//RVS meas Real Video/Audio Streming
#if RTOS_UART_DEV
#include <FreeRTOS.h>
#include <task.h>
#include <bsp.h>
#include <string.h>
#include <nonstdlib.h>
#include <queue.h>
#include <semphr.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/types.h>
#include <bits/alltypes.h>
#include <lwip/sockets.h>
#else
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <netdb.h>
#endif


#ifdef __cplusplus
 #if __cplusplus
extern "C" {
 #endif
#endif /* __cplusplus */


    
#ifdef __cplusplus
 #if __cplusplus
}
 #endif
#endif /* __cplusplus */


#endif
