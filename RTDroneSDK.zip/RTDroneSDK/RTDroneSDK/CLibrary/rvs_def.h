#ifndef __RVS_DEF_H__
#define __RVS_DEF_H__

//RVS meas Real Video/Audio Streming
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef __cplusplus
 #if __cplusplus
extern "C" {
 #endif
#endif /* __cplusplus */


#if defined(ANDROID) //�����android ƽ̨
    #include <jni.h>
    #include <android/log.h>
    #define TAG "smarpCam"
  #ifdef DEBUG
    #define RVS_INFO_PRINT(...)  __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
  #else
    #define RVS_INFO_PRINT(...)
  #endif
    #define RVS_ERR_PRINT(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
	#define RVS_DATA_PRINT(data,len)

#elif defined(__APPLE__)
    //#include "TargetConditionals.h"
    //#if TARGET_IPHONE_SIMULATOR
         // iOS Simulator
    //#elif TARGET_OS_IPHONE
        // iOS device
    //#elif TARGET_OS_MAC
        // Other kinds of Mac OS
    //#else
    //#   error "Unknown Apple platform"
    //#endif
  #ifdef DEBUG
    #define RVS_INFO_PRINT printf
  #else
    #define RVS_INFO_PRINT printf
  #endif
    #define RVS_ERR_PRINT printf
#define RVS_DATA_PRINT(data,len) \
do\
{\
printf("\n");\
int i=0;\
for(i=0;i<len;i++)\
printf("%02x ",data[i]);\
printf("\n");\
}while(0)

    
#elif defined(RTOS_UART_DEV) //sonix free rtos
   #ifdef DEBUG
    #define RVS_INFO_PRINT      print_msg("\033[0;32m [%s:%d] \033[0m",__FUNCTION__,__LINE__);print_msg
    #define RVS_DATA_PRINT(data,len) \
    do\
    {\
        print_msg("\n");\
        int i=0;\
        for(i=0;i<len;i++)\
           print_msg("%02x ",data[i]);\
        print_msg("\n");\
    }while(0)

   #else
    #define RVS_INFO_PRINT(fmt, arg...)  
    #define RVS_DATA_PRINT(data,len)
   #endif
    #define RVS_ERR_PRINT       print_msg("\033[0;31m [%s:%d] \033[0m",__FUNCTION__,__LINE__);print_msg

    //rvs configuration
    #define RVS_MODULS "RVS"
    #define RVS_MODE "rvs_mode"
    //hwb button configuration
    #define RVS_HWB_ACTION_TRIGER_LEVEL "rvs_hwb_act_triger_level"
    #define RVS_HWB_DEV_NUM "rvs_hwb_dev_num"
#if 0
    #define RVS_HWB_ACTION1 "rvs_hwb_action1"
    #define RVS_HWB_ACTION2 "rvs_hwb_action2"
    #define RVS_HWB_ACTION3 "rvs_hwb_action3"
    #define RVS_HWB_ACTION1_START_MS "rvs_hwb_action1_start_ms"
    #define RVS_HWB_ACTION2_START_MS "rvs_hwb_action2_start_ms"
    #define RVS_HWB_ACTION3_START_MS "rvs_hwb_action3_start_ms"
    #define RVS_HWB_DEV "rvs_hwb_dev"
    #define RVS_HWB_DEV_PIN "rvs_hwb_dev_pin"
#else

    #define RVS_HWB_ACTION1 "rvs_hwb%01d_act1"
    #define RVS_HWB_ACTION2 "rvs_hwb%01d_act2"
    #define RVS_HWB_ACTION3 "rvs_hwb%01d_act3"
    //rt_llq,����nvram�Ŀռ䲻�㣬��action��action type�����úϲ�Ϊһ��������
    #define RVS_HWB_ACTION_bits 0
    #define RVS_HWB_ACTION_TYPE_bits 8
    #define RVS_HWB_GET_ACTION(a) ((a>>RVS_HWB_ACTION_bits)&0xff)
    #define RVS_HWB_GET_ACTION_TYPE(a) ((a>>RVS_HWB_ACTION_TYPE_bits)&0xff)
    /*
    #define RVS_HWB_ACTION1_TYPE "rvs_hwb%01d_act1_t"
    #define RVS_HWB_ACTION2_TYPE "rvs_hwb%01d_act2_t"
    #define RVS_HWB_ACTION3_TYPE "rvs_hwb%01d_act3_t"
    */
    #define RVS_HWB_ACTION1_START_MS "rvs_hwb%01d_act1_ms"
    #define RVS_HWB_ACTION2_START_MS "rvs_hwb%01d_act2_ms"
    #define RVS_HWB_ACTION3_START_MS "rvs_hwb%01d_act3_ms"
    #define RVS_HWB_DEV "rvs_hwb%01d_dev"
    #define RVS_HWB_DEV_PIN "rvs_hwb%01d_dev_pin"

#endif
    //uart2 configuration
    #define RVS_UART2_BAUD "rvs_uart2_baud"
    #define RVS_UART2_STOP_BITS "rvs_uart2_stop_bits"
    #define RVS_UART2_DATA_BITS "rvs_uart2_data_bits"
    #define RVS_UART2_PARITY "rvs_uart2_parity"
              
#elif defined(__linux__) //gk,hs
    // linux
  #ifdef DEBUG
    #define RVS_INFO_PRINT      printf("\033[0;32m [%s:%d] \033[0m",__FUNCTION__,__LINE__);printf
    #define RVS_DATA_PRINT(data,len) \
    do\
    {\
        printf("\n");\
        int i=0;\
        for(i=0;i<len;i++)\
           printf("%02x ",data[i]);\
        printf("\n");\
    }while(0)

  #else
    #define RVS_INFO_PRINT(fmt, arg...)  
    #define RVS_DATA_PRINT(data,len)
  #endif
    #define RVS_ERR_PRINT       printf("\033[0;31m [%s:%d] \033[0m",__FUNCTION__,__LINE__);printf

#elif defined(_POSIX_VERSION)
    // POSIX
  #ifdef DEBUG
    #define RVS_INFO_PRINT      printf("\033[0;32m [%s:%d] \033[0m",__FUNCTION__,__LINE__);printf
  #else
    #define RVS_INFO_PRINT(fmt, arg...) 
  #endif
    #define RVS_ERR_PRINT       printf("\033[0;31m [%s:%d] \033[0m",__FUNCTION__,__LINE__);printf

#else
#   error "Unknown compiler"
#endif

#define RVS_SOCKET_MAX_DATA_SIZE 512
#define RVS_UART_RECV_TIMEOUT_ms (1*1000)


#define RVS_SUCCESS (0)
#define RVS_EFAILED (-1)

#define RVST_FLYCTRL_PORT 9001
#define RVST_IPC_MSG_PORT 8001

#define RVST_CONNECT_TIMEOUT_s 2

#define RVST_INVALID_SOCKET (-1)

typedef int             RVST_INT;
typedef unsigned int    RVST_UINT;
typedef int             RVST_INT32;
typedef unsigned int    RVST_UINT32;
    
#ifndef RTOS_UART_DEV
typedef ssize_t          RVST_SSIZE;
#else
typedef RVST_INT32       RVST_SSIZE;
#endif

typedef short           RVST_INT16;
typedef unsigned short  RVST_UINT16;

typedef unsigned char   RVST_BYTE;
typedef unsigned char   RVST_UBYTE;
typedef unsigned char   RVST_UINT8;
typedef char            RVST_INT8;
typedef char            RVST_CHAR;

typedef int             RVST_RET;
typedef int             RVST_SOCKET;

#ifndef NULL
#ifdef __cplusplus
#define NULL 0L
#else
#define NULL ((void*)0)
#endif
#endif

#define RVS_CMD_RESP_FLAG           0x8000
#define RVS_CMD_MAKE_RESP(cmd)      (cmd | RVS_CMD_RESP_FLAG)

#define RVS_CMD_FLYCTRL             0x00E0
#define RVS_CMD_FLYCTRL_RESP        RVS_CMD_MAKE_RESP(RVS_CMD_FLYCTRL)

#define RVS_CMD_IO_TO_APP_MSG         0x00F0 //ipcʹ��IO��app������Ϣ
#define RVS_CMD_IO_TO_APP_MSG_RESP    RVS_CMD_MAKE_RESP(RVS_CMD_IO_TO_APP_MSG)

#define RVS_CMD_UART_TO_APP_MSG       0x00D0 //ipcʹ�ô�����app������Ϣ
#define RVS_CMD_UART_TO_APP_MSG_RESP  RVS_CMD_MAKE_RESP(RVS_CMD_UART_TO_APP_MSG)

#define RVS_CMD_RESTART_UART          0x00C0 //���³�ʼ������
#define RVS_CMD_RESTART_UART_RESP     RVS_CMD_MAKE_RESP(RVS_CMD_RESTART_UART)

#define RVS_CMD_SUBSCRIBE             0x00B0 //APP����,���Ͷ������ݸ�APP
#define RVS_CMD_SUBSCRIBE_RESP        RVS_CMD_MAKE_RESP(RVS_CMD_SUBSCRIBE)

#define RVS_CMD_UNSUBSCRIBE           0x00A0 //APP������,�����Ͷ������ݸ�APP
#define RVS_CMD_UNSUBSCRIBE_RESP      RVS_CMD_MAKE_RESP(RVS_CMD_UNSUBSCRIBE)

#define RVS_CMD_MODE_SWITCH           0x0090 //ѡ�����ģʽ��������(UART/IO),buf������(UART��IO),����������������
#define RVS_CMD_MODE_SWITCH_RESP      RVS_CMD_MAKE_RESP(RVS_CMD_MODE_SWITCH)

    
//RVSDrone
#define RVS_CMD_SNAP        (0x0011)
#define RVS_CMD_REC         (0x0012)
#define RVS_CMD_TRANSINFO   (0x00A1)

enum RVS_ERROR
{
    RVS_EPARA   = 1,
    RVS_ENOTSUPPORT = 2, 
    RVS_EIO = 3, 
    RVS_ESN = 4,
    RVS_ECHECKSUM = 5,
    RVS_EINVALIDDATA = 6,
    RVS_EEND,
};

typedef enum 
{
    RVS_SOCKET_TCP   = 1,
    RVS_SOCKET_UDP = 2, 

    RVS_SOCKET_END,
}RVS_SOCKET_TYPE;


    
#ifdef __cplusplus
 #if __cplusplus
}
 #endif
#endif /* __cplusplus */


#endif
