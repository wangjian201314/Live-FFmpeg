/******************************************************************************
File Name     : rvs_ipc_client.h
Description   : 
******************************************************************************/
#ifndef RVS_IPC_CLIENT_H
#define RVS_IPC_CLIENT_H

#include "rvs_pub_client.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */

RVST_RET RVST_IpcSendMsgToApp( RVST_UINT16 u16Cmd, RVST_BYTE *pPayloadBuf, RVST_UINT16 s16PayloadLen);

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#endif/*RVS_IPC_CLIENT_H*/

