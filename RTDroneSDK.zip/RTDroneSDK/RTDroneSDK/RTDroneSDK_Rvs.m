//
//  RTDroneSDK_Rvs.m
//  RTDroneSDK
//
//  Created by 杨青远 on 2017/12/21.
//  Copyright © 2017年 杨青远. All rights reserved.
//

#import "RTDroneSDK_Rvs.h"
#import "rvs_client.h"
#import "rvs_pub_client.h"
#import "Rt_app_log.h"
#import "hi_type.h"

@implementation RTDroneSDK_Rvs

@synthesize delegate;

static RVST_INT *hpRvsHandle = NULL;
static RVST_INT *ps32SubscribeHandle = NULL;
static RTDroneSDK_Rvs *rtDroneSDK_Rvs;


static void AckCbFunc(RVST_UINT16 u16Cmd, RVST_UINT8 u8SerialNum,
                      RVST_BYTE AckData[RVS_SOCKET_MAX_DATA_SIZE], RVST_SSIZE s32RecvLen, void *UserData)
{
    
    static RVST_UINT8 u8SerialNumTmp = 0;
    
    if((NULL == AckData) || (s32RecvLen < 1))
    {
        //RVS_ERR_PRINT("AckCbFunc param err!\n");
        return ;
    }
    
    switch(u16Cmd)
    {
        case RVS_CMD_FLYCTRL_RESP:
        {
            
            if(u8SerialNumTmp != u8SerialNum)
            {
            }
            u8SerialNumTmp = u8SerialNum;
            break;
        }
        case RVS_CMD_IO_TO_APP_MSG:
        {
            
            break;
        }
        case RVS_CMD_UART_TO_APP_MSG:
        {
            
            break;
        }
            
        case RVS_CMD_SNAP:
        {
            if([[rtDroneSDK_Rvs delegate] respondsToSelector:@selector(RTSDKRvs_MsgCallBack:andData:)]){
                [[rtDroneSDK_Rvs delegate] RTSDKRvs_MsgCallBack:RT_DRONE_RVS_MES_REC andData:AckData];
            }
            break;
        }
        case RVS_CMD_REC:
        {
            if([[rtDroneSDK_Rvs delegate] respondsToSelector:@selector(RTSDKRvs_MsgCallBack:andData:)]){
                [[rtDroneSDK_Rvs delegate] RTSDKRvs_MsgCallBack: RT_DRONE_RVS_MES_REC andData:AckData];
            }
            break;
        }
        case RVS_CMD_TRANSINFO:
        {
            if([[rtDroneSDK_Rvs delegate] respondsToSelector:@selector(RTSDKRvs_MsgCallBack:andData:)]){
                [[rtDroneSDK_Rvs delegate] RTSDKRvs_MsgCallBack:RT_DRONE_RVS_MSG_TRANSINFO andData:AckData];
            }
            break;
        }
        default:
        {
            RVS_ERR_PRINT("[SDK_Rvs] unknowed CMD[%x]Data[%s] !\n",u16Cmd,AckData);
        }
            
    }
}


-(instancetype) init{
    rtDroneSDK_Rvs = self;
    return self;
}

//链接
-(int)RTSDKRvs_connect:(char *)ip andPort:(int)port{
    
    if(hpRvsHandle != NULL){
        LOGE("[SDK_Rvs] there is already connected\n");
        return HI_SUCCESS;
    }
    
    int rvs_timeOut = 2;
    RVS_SOCKET_TYPE socket_type;
    socket_type = RVS_SOCKET_UDP;
    
    RVST_RET ret = RVST_Connect(ip,port,rvs_timeOut,&hpRvsHandle,socket_type);
    if(RVS_EFAILED == ret){
        LOGE("[SDK_Rvs] connect err! \n");
        RVST_DisConnect(hpRvsHandle);
        hpRvsHandle = NULL;
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}


//链接成功后开始发送飞控指令，比如说前后左右的油门置
-(int)RTSDKRvs_SendUAVData:(unsigned char *)data andLength:(int)length{
    if(hpRvsHandle == NULL){
        LOGE("[SDK_Rvs] hpRvsHandle == NULL\n");
        return -1;
    }
    
    RVST_UBYTE pczPayload[1024];
    memset(pczPayload, 0, sizeof(pczPayload));
    int i = 0;
    for(i= 0 ; i<length ;i++)
    {
        pczPayload[i] = data[i] & 0xff;
    }
    
    RVST_RET ret = RVST_SendCmdData(hpRvsHandle, RVS_CMD_FLYCTRL, pczPayload, length);
    
    LOG_PRINT_HEX(data, 0, length);
    
    if(RVS_SUCCESS != ret){
        LOGE("[SDK_Rvs] RVST_SendCmdData err\n");
        RVST_DisConnect(hpRvsHandle);
        hpRvsHandle = NULL;
        return HI_FAILURE;
    }
    
    return 0;
}



//断掉链接
-(int)RTSDKRvs_DisConnect{
    if(hpRvsHandle == NULL){
        LOGE("[SDK_Rvs] hpRvsHandle == NULL\n");
        return -1;
    }
    
    RVST_RET ret = RVST_DisConnect(hpRvsHandle);
    hpRvsHandle = NULL;
    if(RVS_SUCCESS == ret){
        LOGD("[SDK_Rvs] disconnect ok \n");
        return HI_SUCCESS;
    }else{
        LOGD("[SDK_Rvs] disconnect faile \n");
        return HI_FAILURE;
    }
    return 0;
}



//要接收设备端的数据，必须要创建订阅线程，这个动作不需要RTSDKRvs_connect
//可以单独运行，手柄按键拍照，录像，透传数据，就会在这里回调
-(int)RTSDKRvs_CreateSubscribeDataThread{
    if(ps32SubscribeHandle != NULL){
        LOGE("[SDK_Rvs] Already CreateSubscribeDataThread please check \n");
        return HI_FAILURE;
    }
    
    RVST_RET ret = RVST_CreatSubscribeDataThread(&ps32SubscribeHandle,  AckCbFunc, "");
    
    if(ret == RVS_EPARA){
        RVST_DestoryRecvSubscribeDataThread(ps32SubscribeHandle);
        ps32SubscribeHandle = NULL;
    }
    
    return 0;
}



//创建订阅线程后，要记得关闭，以免内存泄露
-(int)RTSDKRvs_DestorySubscribeDataThread{
    if(ps32SubscribeHandle != NULL){
        RVST_DestoryRecvSubscribeDataThread(ps32SubscribeHandle);
        ps32SubscribeHandle = NULL;
        LOGD("[SDK_Rvs] DestorySubscribeDataThread OK \n");
    }
    return 0;
}



//订阅，主要针对透传数据，其他数据不需要订阅，比如手柄按键拍照，录像相应
//这个订阅必须要connect
-(int)RTSDKRvs_Subscribe:(int) state{
    if(hpRvsHandle == NULL){
        LOGE("[SDK_Rvs] hpRvsHandle == NULL\n");
        return HI_FAILURE;
    }
    RVST_RET ret = HI_SUCCESS;
    
    if(state ==1){
        ret = RVST_SendCmdData(hpRvsHandle, RVS_CMD_SUBSCRIBE, "Subscribe", strlen("Subscribe"));
    }else{
         ret = RVST_SendCmdData(hpRvsHandle, RVS_CMD_SUBSCRIBE, "unSubscribe", strlen("unSubscribe"));
    }
    
    if(RVS_SUCCESS == ret){
        LOGE("[SDK_Rvs] Subscribe success \n");
        return HI_FAILURE;
    }else{
        LOGE("[SDK_Rvs] Subscribe faile \n");
        return HI_FAILURE;
    }
    
    return ret;
}
@end
